<?php
/* Template Name: Elementor Full Width */
get_header();
?>

<div class="container-fluid p-0">
    <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
</div>

<?php get_footer(); ?>
