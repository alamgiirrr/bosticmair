<?php
namespace Hybrid;

class Enqueue {
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'assets']);
    }

    public function assets() {
        wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/bootstrap/css/bootstrap.min.css', [], '5.3');
        wp_enqueue_style('main-css', get_template_directory_uri() . '/assets/css/main.css', ['bootstrap'], '1.0');
        wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/bootstrap/js/bootstrap.bundle.min.js', [], '5.3', true);
        wp_enqueue_script('main-js', get_template_directory_uri() . '/assets/js/main.js', ['jquery'], '1.0', true);
    }
}
