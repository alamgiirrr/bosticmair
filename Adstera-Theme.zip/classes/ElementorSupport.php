<?php
namespace Hybrid;

class ElementorSupport {
    public function __construct() {
        add_action('init', [$this, 'elementor_compat']);
    }

    public function elementor_compat() {
        add_theme_support('elementor');
    }
}
