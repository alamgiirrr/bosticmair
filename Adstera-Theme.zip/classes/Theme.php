<?php
namespace Hybrid;

class Theme {
    public function __construct() {
        add_action('after_setup_theme', [$this, 'setup']);
    }

    public function setup() {
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('menus');
        add_theme_support('elementor-pro-theme-builder');
    }
}
