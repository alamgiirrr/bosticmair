<footer class="bg-dark text-white text-center py-3 mt-5">
   
</footer>

<?php wp_footer(); ?>
</body>
</html>
