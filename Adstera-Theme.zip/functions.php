<?php
if (!defined('ABSPATH')) exit;

require_once get_template_directory() . '/classes/Theme.php';
require_once get_template_directory() . '/classes/Enqueue.php';
require_once get_template_directory() . '/classes/ElementorSupport.php';

new \Hybrid\Theme();
new \Hybrid\Enqueue();
new \Hybrid\ElementorSupport();
