(async function () {
    function hash(str) {
        return crypto.subtle.digest("SHA-256", new TextEncoder().encode(str))
            .then(buf => Array.from(new Uint8Array(buf))
            .map(x => x.toString(16).padStart(2,'0'))
            .join(''));
    }

    let fp = [
        navigator.userAgent,
        navigator.language,
        screen.width + "x" + screen.height,
        navigator.platform,
        navigator.hardwareConcurrency,
        navigator.deviceMemory || "",
        Intl.DateTimeFormat().resolvedOptions().timeZone
    ].join("|");

    const deviceHash = await hash(fp);

    document.cookie = "earn_device_id=" + deviceHash + "; path=/; max-age=" + (3600 * 24 * 365);
})();
