<?php
/*
Plugin Name: Alamgir Security
Description: Advanced Login Security with Complete Device Fingerprint, Cookie Device ID, Multi-Account Detection, Auto-Blocking, Login History, Filters, CSV Export, Block Logs.
Version: 3.0.0
Author: Earn System
*/

if (!defined('ABSPATH')) exit;

global $wpdb;

/* ============================================================
   DATABASE TABLE CONSTANTS
   ============================================================ */
define('EARN_LOGIN_LOG_TABLE', $wpdb->prefix . 'earn_login_logs');
define('EARN_BLOCK_LIST', $wpdb->prefix . 'earn_block_list');
define('EARN_BLOCK_LOGS', $wpdb->prefix . 'earn_block_logs');


/* ============================================================
   ACTIVATION: CREATE ALL TABLES
   ============================================================ */
register_activation_hook(__FILE__, function () {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset = $wpdb->get_charset_collate();

    /* LOGIN LOG TABLE */
    dbDelta("CREATE TABLE " . EARN_LOGIN_LOG_TABLE . " (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        username VARCHAR(60) NOT NULL,
        ip_address VARCHAR(50),
        ip_type VARCHAR(50),
        country VARCHAR(100),
        city VARCHAR(100),
        device_hash VARCHAR(64),
        user_agent TEXT,
        platform VARCHAR(100),
        browser VARCHAR(100),
        login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY user_id (user_id),
        KEY ip_address (ip_address),
        KEY device_hash (device_hash),
        KEY login_time (login_time)
    ) $charset;");

    /* BLOCK LIST TABLE */
    dbDelta("CREATE TABLE " . EARN_BLOCK_LIST . " (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        device_hash VARCHAR(64),
        ip_address VARCHAR(50),
        reason VARCHAR(255),
        blocked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(20) DEFAULT 'blocked',
        KEY device_hash (device_hash),
        KEY ip_address (ip_address)
    ) $charset;");

    /* BLOCK LOGS TABLE */
    dbDelta("CREATE TABLE " . EARN_BLOCK_LOGS . " (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT,
        ip_address VARCHAR(50),
        device_hash VARCHAR(64),
        message TEXT,
        logged_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY user_id (user_id),
        KEY device_hash (device_hash)
    ) $charset;");
});



/* ============================================================
   ENQUEUE FINGERPRINT JS (CLIENT-SIDE)
   ============================================================ */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script(
        'earn-device-fingerprint',
        plugin_dir_url(__FILE__) . 'assets/fingerprint.js',
        [],
        null,
        true
    );
});


/* ============================================================
   HELPER: GET REAL USER IP
   ============================================================ */
function earn_get_user_ip() {
    foreach ([
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_REAL_IP',
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'REMOTE_ADDR'
    ] as $key) {
        if (!empty($_SERVER[$key])) {
            return sanitize_text_field(explode(',', $_SERVER[$key])[0]);
        }
    }
    return 'UNKNOWN';
}


/* ============================================================
   SERVER-SIDE FINGERPRINT
   ============================================================ */
function earn_get_server_fingerprint() {
    return hash(
        'sha256',
        ($_SERVER['HTTP_USER_AGENT'] ?? '') .
        ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '') .
        ($_SERVER['HTTP_SEC_CH_UA'] ?? '') .
        ($_SERVER['HTTP_SEC_CH_UA_MOBILE'] ?? '') .
        ($_SERVER['HTTP_SEC_CH_UA_PLATFORM'] ?? '')
    );
}


/* ============================================================
   COOKIE DEVICE ID (JS FINGERPRINT)
   ============================================================ */
function earn_get_cookie_device_id() {
    return isset($_COOKIE['earn_device_id'])
        ? sanitize_text_field($_COOKIE['earn_device_id'])
        : '';
}


/* ============================================================
   FINAL COMBINED DEVICE HASH (STRONGEST)
   ============================================================ */
function earn_get_final_device_hash() {
    return hash(
        'sha256',
        earn_get_server_fingerprint() . earn_get_cookie_device_id()
    );
}


/* ============================================================
   GEO + IP TYPE LOOKUP (with cache)
   ============================================================ */
function earn_geo_lookup($ip) {
    $cache = get_transient('earn_geo_' . md5($ip));
    if ($cache) return $cache;

    $data = [
        'country' => 'Unknown',
        'city'    => 'Unknown',
        'ip_type' => 'ISP'
    ];

    $res = wp_remote_get("http://ip-api.com/json/{$ip}?fields=status,country,city,isp,org,as");
    if (!is_wp_error($res)) {
        $body = json_decode(wp_remote_retrieve_body($res), true);

        if (($body['status'] ?? '') === 'success') {
            $data['country'] = $body['country'] ?? 'Unknown';
            $data['city']    = $body['city'] ?? 'Unknown';

            $org = strtolower(($body['isp'] ?? '') . ($body['org'] ?? '') . ($body['as'] ?? ''));

            if (preg_match('/vpn|proxy|cloud|hosting|amazon|google|azure|digitalocean/', $org)) {
                $data['ip_type'] = 'Datacenter / VPN';
            } elseif (preg_match('/mobile|cellular|lte|3g|4g|5g/', $org)) {
                $data['ip_type'] = 'Mobile';
            }
        }
    }

    set_transient('earn_geo_' . md5($ip), $data, DAY_IN_SECONDS);
    return $data;
}

/* ============================================================
   LOGIN HOOK — TRACK LOGIN + AUTO BLOCK + MULTI ACCOUNT CHECK
   ============================================================ */
add_action('wp_login', function ($user_login, $user) {
    global $wpdb;

    $ip  = earn_get_user_ip();
    $geo = earn_geo_lookup($ip);

    /* Create final advanced device hash */
    $final_hash = earn_get_final_device_hash();


    /* ============================================================
       AUTO-BLOCK CHECK: If device or IP already blocked → stop login
       ============================================================ */
    $blocked = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM " . EARN_BLOCK_LIST . " 
             WHERE (device_hash=%s OR ip_address=%s) 
             AND status='blocked'",
            $final_hash,
            $ip
        )
    );

    if ($blocked) {
        $wpdb->insert(EARN_BLOCK_LOGS, [
            'user_id'     => $user->ID,
            'ip_address'  => $ip,
            'device_hash' => $final_hash,
            'message'     => 'Blocked login attempt (device already blocked)'
        ]);

        wp_logout();
        wp_die("Your device has been blocked for security reasons.");
    }


    /* ============================================================
       MULTI-ACCOUNT DETECTOR:
       Same device used by different users → Auto Block
       ============================================================ */
    $multi = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM " . EARN_LOGIN_LOG_TABLE . "
             WHERE device_hash=%s AND user_id != %d",
            $final_hash,
            $user->ID
        )
    );

    if ($multi > 0 && !user_can($user->ID, 'administrator')) {


        /* Block the device */
        $wpdb->insert(EARN_BLOCK_LIST, [
            'device_hash' => $final_hash,
            'ip_address'  => $ip,
            'reason'      => 'Multi-account detected'
        ]);

        /* Add block log */
        $wpdb->insert(EARN_BLOCK_LOGS, [
            'user_id'     => $user->ID,
            'ip_address'  => $ip,
            'device_hash' => $final_hash,
            'message'     => 'Auto Blocked (Multi-account activity)'
        ]);

        wp_logout();
        wp_die("Your device has been blocked due to multi-account usage.");
    }


    /* ============================================================
       PLATFORM / BROWSER DETECT
       ============================================================ */
    $agent = sanitize_textarea_field($_SERVER['HTTP_USER_AGENT'] ?? '');

    $platform = 'Unknown';
    if (preg_match('/windows/i', $agent))      $platform = 'Windows';
    elseif (preg_match('/android/i', $agent))  $platform = 'Android';
    elseif (preg_match('/iphone|ipad/i', $agent)) $platform = 'iOS';
    elseif (preg_match('/mac/i', $agent))      $platform = 'MacOS';

    $browser = 'Unknown';
    if (preg_match('/chrome/i', $agent))       $browser = 'Chrome';
    elseif (preg_match('/firefox/i', $agent))  $browser = 'Firefox';
    elseif (preg_match('/safari/i', $agent))   $browser = 'Safari';


    /* ============================================================
       INSERT LOGIN LOG (IMPORTANT)
       ============================================================ */
    $wpdb->insert(EARN_LOGIN_LOG_TABLE, [
        'user_id'     => $user->ID,
        'username'    => $user_login,
        'ip_address'  => $ip,
        'ip_type'     => $geo['ip_type'],
        'country'     => $geo['country'],
        'city'        => $geo['city'],
        'device_hash' => $final_hash,
        'user_agent'  => $agent,
        'platform'    => $platform,
        'browser'     => $browser,
        'login_time'  => current_time('mysql')
    ]);
}, 10, 2);



/* ============================================================
   AUTO DELETE OLD LOGS (60 days)
   ============================================================ */
add_action('earn_login_cleanup', function () {
    global $wpdb;

    $wpdb->query("
        DELETE FROM " . EARN_LOGIN_LOG_TABLE . "
        WHERE login_time < DATE_SUB(NOW(), INTERVAL 60 DAY)
    ");
});

if (!wp_next_scheduled('earn_login_cleanup')) {
    wp_schedule_event(time(), 'daily', 'earn_login_cleanup');
}

/* ============================================================
   ADMIN MENU
   ============================================================ */
add_action('admin_menu', function () {

    /* Login History Page */
    add_menu_page(
        'Login History',
        'Login History',
        'manage_options',
        'earn-login-history',
        'earn_login_history_page',
        'dashicons-visibility',
        26
    );

    /* Blocked Devices Page */
    add_menu_page(
        'Security Blocks',
        'Security Blocks',
        'manage_options',
        'earn-security-blocks',
        'earn_security_blocks_page',
        'dashicons-shield'
    );

    /* Block Logs Page */
    add_menu_page(
        'Block Logs',
        'Block Logs',
        'manage_options',
        'earn-block-logs',
        'earn_block_logs_page',
        'dashicons-list-view'
    );
});



/* ============================================================
   LOGIN HISTORY PAGE (Full Original + Extended)
   ============================================================ */
function earn_login_history_page() {
    global $wpdb;

    /* Filters */
    $ip_filter     = sanitize_text_field($_GET['ip'] ?? '');
    $device_filter = sanitize_text_field($_GET['device'] ?? '');

    $where  = [];
    $params = [];

    if ($ip_filter) {
        $where[]  = "ip_address = %s";
        $params[] = $ip_filter;
    }
    if ($device_filter) {
        $where[]  = "device_hash LIKE %s";
        $params[] = '%' . $wpdb->esc_like($device_filter) . '%';
    }

    $sql = "SELECT * FROM " . EARN_LOGIN_LOG_TABLE;

    if ($where) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }

    $sql .= " ORDER BY login_time DESC LIMIT 500";

    $logs = $params
        ? $wpdb->get_results($wpdb->prepare($sql, $params))
        : $wpdb->get_results($sql);

/* Count device usage by different users */
$device_user_map = [];

foreach ($logs as $l) {
    $device_user_map[$l->device_hash][$l->user_id] = true;
}

/* Check if a device is used by more than one unique user */
function is_multi_user_device($hash, $map) {
    return isset($map[$hash]) && count($map[$hash]) > 1;
}

    ?>
    <div class="wrap">
        <h1>Login History</h1>

        <!-- FILTER FORM -->
        <form method="get" style="margin-bottom:15px;">
            <input type="hidden" name="page" value="earn-login-history">
            <input type="text" name="ip" placeholder="Filter by IP"
                   value="<?php echo esc_attr($ip_filter); ?>">
            <input type="text" name="device" placeholder="Filter by Device Hash"
                   value="<?php echo esc_attr($device_filter); ?>">
            <button class="button">Filter</button>

            <a class="button button-primary" href="?page=earn-login-history&earn_export_csv=1">
                Export CSV
            </a>
        </form>

        <button class="button" id="bulk-delete">Bulk Delete</button>
        <span id="bulk-loader" style="display:none;">Deleting...</span>

        <table class="widefat striped">
            <thead>
            <tr>
                <th><input type="checkbox" id="check-all"></th>
                <th>User</th>
                <th>IP</th>
                <th>IP Type</th>
                <th>Country</th>
                <th>City</th>
                <th>Device</th>
                <th>Platform</th>
                <th>Browser</th>
                <th>Login Time</th>
                <th>Action</th>
            </tr>
            </thead>

            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr id="row-<?php echo $log->id; ?>"
                    style="<?php echo is_multi_user_device($log->device_hash, $device_user_map)
    ? 'background:#ffe5e5;'
    : ''; ?>">


                    <td><input type="checkbox" class="row-check" value="<?php echo $log->id; ?>"></td>

                    <td><?php echo esc_html($log->username); ?></td>
                    <td><?php echo esc_html($log->ip_address); ?></td>
                    <td><?php echo esc_html($log->ip_type); ?></td>
                    <td><?php echo esc_html($log->country); ?></td>
                    <td><?php echo esc_html($log->city); ?></td>

                    <td><code><?php echo esc_html(substr($log->device_hash, 0, 18)); ?>…</code></td>

                    <td><?php echo esc_html($log->platform); ?></td>
                    <td><?php echo esc_html($log->browser); ?></td>

                    <td><?php echo esc_html($log->login_time); ?></td>

                    <td>
                        <button class="button delete-log"
                                data-id="<?php echo $log->id; ?>">Delete</button>
                        <span class="loader" style="display:none;">...</span>
                    </td>

                </tr>
            <?php endforeach; ?>
            </tbody>

        </table>

        <p><strong style="color:red;">Red row</strong> = Same device used by multiple accounts.</p>

    </div>

    <!-- AJAX SCRIPT -->
    <script>
        jQuery(function($){

            $('#check-all').on('change', function () {
                $('.row-check').prop('checked', this.checked);
            });

            $('.delete-log').on('click', function () {
                if (!confirm('Delete this log?')) return;

                let btn  = $(this);
                let row  = $('#row-' + btn.data('id'));
                let load = btn.next('.loader');

                btn.hide();
                load.show();

                $.post(ajaxurl, {
                    action: 'earn_delete_log',
                    id: btn.data('id')
                }, function () {
                    row.fadeOut(200, function(){ $(this).remove(); });
                });
            });

            $('#bulk-delete').on('click', function () {
                let ids = $('.row-check:checked').map(function () {
                    return this.value;
                }).get();

                if (!ids.length || !confirm('Delete selected logs?')) return;

                $('#bulk-loader').show();

                $.post(ajaxurl, {
                    action: 'earn_bulk_delete',
                    ids: ids
                }, function () {
                    ids.forEach(id => $('#row-' + id).fadeOut(150));
                    $('#bulk-loader').hide();
                });
            });

        });
    </script>

    <?php
}



/* ============================================================
   AJAX DELETE HANDLERS
   ============================================================ */
add_action('wp_ajax_earn_delete_log', function () {
    global $wpdb;

    if (!current_user_can('manage_options')) wp_die();

    $wpdb->delete(EARN_LOGIN_LOG_TABLE, ['id' => intval($_POST['id'])]);

    wp_die('ok');
});


add_action('wp_ajax_earn_bulk_delete', function () {
    global $wpdb;

    if (!current_user_can('manage_options')) wp_die();

    $ids = array_map('intval', $_POST['ids'] ?? []);

    if ($ids) {
        $wpdb->query("
            DELETE FROM " . EARN_LOGIN_LOG_TABLE . "
            WHERE id IN (" . implode(',', $ids) . ")
        ");
    }

    wp_die('ok');
});



/* ============================================================
   SECURITY BLOCKS PAGE
   ============================================================ */
function earn_security_blocks_page() {
    global $wpdb;

    /* Unblock action */
    if (isset($_GET['unblock'])) {
        $wpdb->update(EARN_BLOCK_LIST,
            ['status' => 'unblocked'],
            ['id' => intval($_GET['unblock'])]
        );
    }

    $rows = $wpdb->get_results("SELECT * FROM " . EARN_BLOCK_LIST . " ORDER BY blocked_at DESC");

    echo "<div class='wrap'><h1>Blocked Devices</h1>
    <table class='wp-list-table widefat striped'>
    <tr>
        <th>ID</th>
        <th>Device Hash</th>
        <th>IP Address</th>
        <th>Reason</th>
        <th>Blocked At</th>
        <th>Status</th>
        <th>Action</th>
    </tr>";

    foreach ($rows as $r) {
        echo "<tr>
            <td>{$r->id}</td>
            <td><code>{$r->device_hash}</code></td>
            <td>{$r->ip_address}</td>
            <td>{$r->reason}</td>
            <td>{$r->blocked_at}</td>
            <td>{$r->status}</td>
            <td><a class='button' href='?page=earn-security-blocks&unblock={$r->id}'>
                Unblock
            </a></td>
        </tr>";
    }

    echo "</table></div>";
}



/* ============================================================
   BLOCK LOGS PAGE
   ============================================================ */
function earn_block_logs_page() {
    global $wpdb;

    $logs = $wpdb->get_results("
        SELECT * FROM " . EARN_BLOCK_LOGS . " 
        ORDER BY logged_at DESC 
        LIMIT 500
    ");

    echo "<div class='wrap'><h1>Auto Block Logs</h1>
    <table class='wp-list-table widefat striped'>
    <tr>
        <th>ID</th>
        <th>User ID</th>
        <th>IP</th>
        <th>Device Hash</th>
        <th>Message</th>
        <th>Time</th>
    </tr>";

    foreach ($logs as $l) {
        echo "<tr>
            <td>{$l->id}</td>
            <td>{$l->user_id}</td>
            <td>{$l->ip_address}</td>
            <td><code>{$l->device_hash}</code></td>
            <td>{$l->message}</td>
            <td>{$l->logged_at}</td>
        </tr>";
    }

    echo "</table></div>";
}

