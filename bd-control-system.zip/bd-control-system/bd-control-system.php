<?php
/**
 * Plugin Name: BD Control System
 * Description: Restrict wp-admin, hide admin bar, force BD timezone for all users.
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------
| 1. BLOCK wp-admin FOR NON-ADMINS
|--------------------------------------------------------------
*/
add_action('admin_init', function () {
    if (!current_user_can('administrator') && !wp_doing_ajax()) {
        wp_redirect(home_url());
        exit;
    }
});

/*
|--------------------------------------------------------------
| 2. HIDE ADMIN BAR FOR NON-ADMINS
|--------------------------------------------------------------
*/
add_filter('show_admin_bar', function ($show) {
    return current_user_can('administrator') ? $show : false;
});

/*
|--------------------------------------------------------------
| 3. FORCE BD TIMEZONE FOR ALL USERS
|--------------------------------------------------------------
*/
function bdcs_force_bd_timezone($user_id)
{
    update_user_meta($user_id, 'timezone_string', 'Asia/Dhaka');
}
add_action('user_register', 'bdcs_force_bd_timezone');

// Force existing users on login
add_action('wp_login', function ($user_login, $user) {
    update_user_meta($user->ID, 'timezone_string', 'Asia/Dhaka');
}, 10, 2);

/*
|--------------------------------------------------------------
| 4. DISABLE TIMEZONE FIELD IN PROFILE
|--------------------------------------------------------------
*/
add_action('show_user_profile', 'bdcs_disable_timezone_field');
add_action('edit_user_profile', 'bdcs_disable_timezone_field');

function bdcs_disable_timezone_field($user)
{
    ?>
    <style>
        tr.user-timezone-wrap { display: none !important; }
    </style>
    <input type="hidden" name="timezone_string" value="Asia/Dhaka">
    <?php
}

add_action('personal_options_update', 'bdcs_save_timezone_prevent');
add_action('edit_user_profile_update', 'bdcs_save_timezone_prevent');

function bdcs_save_timezone_prevent($user_id)
{
    update_user_meta($user_id, 'timezone_string', 'Asia/Dhaka');
}
?>