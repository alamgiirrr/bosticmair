<?php
/*
Plugin Name: User Ban Manager Premium
Description: Ban Manager with Material UI, Stats, AJAX, Modal (v10.1 – Clean, No Dark Mode)
Version: 10.1
Author: You
*/

if (!defined('ABSPATH')) exit;

/* -------------------- REAL IP -------------------- */
function ubm_get_real_ip() {
    foreach ([
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_REAL_IP',
        'REMOTE_ADDR'
    ] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = explode(',', $_SERVER[$k])[0];
            return filter_var(trim($ip), FILTER_VALIDATE_IP) ? $ip : $_SERVER['REMOTE_ADDR'];
        }
    }
    return $_SERVER['REMOTE_ADDR'];
}

/* -------------------- DB TABLE -------------------- */
register_activation_hook(__FILE__, function () {
    global $wpdb;
    $table = $wpdb->prefix . "ubm_bans";

    $sql = "CREATE TABLE $table (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        username VARCHAR(191),
        email VARCHAR(191),
        ip VARCHAR(60),
        reason TEXT,
        status TINYINT(1) DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX(user_id), INDEX(ip), INDEX(status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    require_once ABSPATH . "wp-admin/includes/upgrade.php";
    dbDelta($sql);
});

/* -------------------- ADMIN MENU -------------------- */
add_action("admin_menu", function () {
    add_menu_page(
        "User Ban Manager", "User Ban Manager",
        "manage_options", "ubm-premium",
        "ubm_admin_page",
        "dashicons-shield-alt", 80
    );
});

/* -------------------- PAGE LOADER -------------------- */
function ubm_admin_page() {
    if (!current_user_can("manage_options")) wp_die("Access denied");

    global $wpdb;
    $table = $wpdb->prefix . "ubm_bans";

    /* FIX: Clean user list array */
    $users = [];
    foreach (get_users() as $u) {
        $users[] = [
            "ID"    => $u->ID,
            "user_login" => $u->user_login,
            "user_email" => $u->user_email,
            "roles" => $u->roles
        ];
    }

    $banned = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");

    $GLOBALS['UBM'] = [
        "nonce" => wp_create_nonce("ubm_nonce"),
        "wp_users" => $users,
        "banned" => $banned,
        "total"  => count($users),
        "banned_n" => count($banned),
        "active" => count($users) - count($banned)
    ];

    echo '<div id="ubm-wrapper"></div>';
}

/* -------------------- ADMIN PROTECT -------------------- */
function ubm_is_admin_user($id) {
    $u = get_userdata($id);
    return ($u && in_array("administrator", $u->roles));
}

/* -------------------- AJAX SECURITY -------------------- */
function ubm_ajax_secure() {
    if (!current_user_can("manage_options")) wp_send_json_error("Unauthorized");
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], "ubm_nonce"))
        wp_send_json_error("Invalid nonce");
}

/* -------------------- BAN AJAX -------------------- */
add_action("wp_ajax_ubm_ban_user", function () {
    ubm_ajax_secure();
    global $wpdb;

    $uid = intval($_POST['id']);
    $reason = sanitize_text_field($_POST['reason']);

    if ($uid <= 0) wp_send_json_error("Invalid");
    if (ubm_is_admin_user($uid)) wp_send_json_error("Cannot ban admin");

    $u = get_user_by("id", $uid);
    if (!$u) wp_send_json_error("Not found");

    $table = $wpdb->prefix . "ubm_bans";

    $wpdb->delete($table, ["user_id" => $uid]);
    $wpdb->insert($table, [
        "user_id"  => $uid,
        "username" => $u->user_login,
        "email"    => $u->user_email,
        "ip"       => ubm_get_real_ip(),
        "reason"   => $reason,
        "status"   => 1
    ]);

    wp_send_json_success();
});

/* -------------------- UNBAN AJAX -------------------- */
add_action("wp_ajax_ubm_unban_user", function () {
    ubm_ajax_secure();
    global $wpdb;

    $uid = intval($_POST['id']);
    if ($uid <= 0) wp_send_json_error("Invalid");

    $wpdb->delete($wpdb->prefix . "ubm_bans", ["user_id" => $uid]);

    wp_send_json_success();
});

/* -------------------- FRONTEND BAN BLOCK -------------------- */
add_action("init", function () {
    if (is_admin()) return;

    global $wpdb;
    $table = $wpdb->prefix . "ubm_bans";

    $u = wp_get_current_user();
    $ip = ubm_get_real_ip();

    if ($u->exists()) {
        $ban = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id=%d AND status=1", $u->ID
        ));
    } else {
        $ban = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE ip=%s AND status=1", $ip
        ));
    }

    if ($ban) {
        wp_die("❌ আপনি BANNED!<br><br>কারণ: " . esc_html($ban->reason));
    }
});

/* -------------------- MATERIAL UI -------------------- */
add_action("admin_footer", function () {

if (!isset($_GET['page']) || $_GET['page'] !== "ubm-premium") return;

$data = $GLOBALS['UBM'];
?>

<style>
/* Clean Material Dashboard */
#ubm-wrapper{max-width:1250px;margin:25px auto;font-family:Inter,sans-serif;}
.ubm-title{font-size:30px;font-weight:700;margin-bottom:25px;}

.ubm-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-bottom:35px;}
.ubm-card{padding:28px;border-radius:16px;color:white;box-shadow:0 8px 25px rgba(0,0,0,0.15);position:relative;overflow:hidden;}
.ubm-bg-blue{background:linear-gradient(135deg,#4c7fff,#2656ff);}
.ubm-bg-green{background:linear-gradient(135deg,#31cc6b,#0ea94b);}
.ubm-bg-red{background:linear-gradient(135deg,#ff4e6a,#d91b3a);}
.ubm-card::after{content:"";position:absolute;width:130px;height:130px;border-radius:50%;top:-40px;right:-40px;background:rgba(255,255,255,0.15);}

.section-title{font-size:22px;font-weight:600;margin:30px 0 15px;}

.ubm-table-wrap{background:white;padding:20px;border-radius:14px;box-shadow:0 6px 18px rgba(0,0,0,0.12);margin-bottom:30px;}
.ubm-search{width:100%;padding:10px;border-radius:8px;border:1px solid #bbb;margin-bottom:12px;}
.ubm-table{width:100%;border-collapse:collapse;}
.ubm-table thead tr{background:linear-gradient(135deg,#6a5acd,#836fff);color:white;}
.ubm-table th,.ubm-table td{padding:12px;border-bottom:1px solid #eee;}
.ubm-table tbody tr:hover{background:rgba(106,90,205,0.08);}

.ubm-btn{padding:6px 10px;font-size:13px;border-radius:6px;border:none;font-weight:600;cursor:pointer;}
.ubm-btn-ban{background:#ff4e6a;color:white;}
.ubm-btn-unban{background:#28c76f;color:white;}

.ubm-pagination{margin-top:12px;display:flex;gap:7px;}
.ubm-page-btn{padding:7px 11px;background:#eee;border-radius:6px;cursor:pointer;font-size:13px;}
.ubm-page-btn.active{background:#6a5acd;color:white;}

#ubm-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.45);display:none;justify-content:center;align-items:center;z-index:100000;}
#ubm-modal{width:420px;background:white;padding:26px;border-radius:14px;}
#ubm-modal textarea{width:100%;height:110px;padding:12px;border-radius:10px;border:1px solid #ccc;}
.ubm-modal-btn{width:100%;margin-top:10px;padding:12px;border:none;border-radius:8px;font-weight:600;cursor:pointer;}
.ubm-modal-confirm{background:#6a5acd;color:white;}
.ubm-modal-cancel{background:#ccc;}
</style>

<script>
const UBM = {
  nonce: "<?= $data['nonce'];?>",
  wp_users: <?= json_encode($data['wp_users']);?>,
  banned: <?= json_encode($data['banned']);?>,
};

/* ----------- INIT HTML ---------- */
document.getElementById("ubm-wrapper").innerHTML = `
 <div class="ubm-title">User Ban Manager (Premium v10.1)</div>

 <div class="ubm-stats">
   <div class="ubm-card ubm-bg-blue">
     <h2 id="cnt-total">0</h2><p>Total Users</p>
   </div>
   <div class="ubm-card ubm-bg-green">
     <h2 id="cnt-active">0</h2><p>Active Users</p>
   </div>
   <div class="ubm-card ubm-bg-red">
     <h2 id="cnt-banned">0</h2><p>Banned Users</p>
   </div>
 </div>

 <div class="section-title">WordPress Users</div>
 <div id="ubm-users-table"></div>

 <div class="section-title">Banned Users</div>
 <div id="ubm-banned-table"></div>
`;

function animate(id,start,end,dur){
 let el=document.getElementById(id);let t=null;
 function s(ts){if(!t)t=ts;let p=Math.min((ts-t)/dur,1);
   el.textContent=Math.floor(p*(end-start)+start);
   if(p<1)requestAnimationFrame(s);}
 requestAnimationFrame(s);
}

animate("cnt-total",0,<?= $data["total"]?>,800);
animate("cnt-active",0,<?= $data["active"]?>,800);
animate("cnt-banned",0,<?= $data["banned_n"]?>,800);

/* ----------- USERS TABLE ---------- */
function renderUsers(){
let html=`
<div class="ubm-table-wrap">
 <input class="ubm-search" placeholder="Search..." data-table="wp-users">
 <table class="ubm-table" id="wp-users">
 <thead><tr><th>ID</th><th>User</th><th>Email</th><th>Role</th><th>Status</th><th>Action</th></tr></thead><tbody>
`;

UBM.wp_users.forEach(u=>{
 let ban=UBM.banned.find(b=>b.user_id==u.ID);

 html+=`
 <tr>
  <td>${u.ID}</td>
  <td>${u.user_login}</td>
  <td>${u.user_email}</td>
  <td>${u.roles.join(",")}</td>
  <td>${ban?`<span style='color:#ff4e6a'>BANNED</span>`:`<span style='color:#28c76f'>OK</span>`}</td>
  <td>${
    u.roles.includes("administrator")
      ? `<span style='opacity:.5'>Admin</span>`
      : ban
        ? `<button class="ubm-btn ubm-btn-unban" data-id="${u.ID}">Unban</button>`
        : `<button class="ubm-btn ubm-btn-ban" data-id="${u.ID}">Ban</button>`
  }</td>
 </tr>`;
});

html+=`</tbody></table><div class="ubm-pagination" id="pg-users"></div></div>`;

document.getElementById("ubm-users-table").innerHTML=html;
paginate("wp-users","pg-users",10);
}

/* ----------- BANNED TABLE ---------- */
function renderBanned(){
let html=`
<div class="ubm-table-wrap">
 <input class="ubm-search" placeholder="Search..." data-table="banned-users">
 <table class="ubm-table" id="banned-users">
 <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>IP</th><th>Reason</th><th>Action</th></tr></thead><tbody>
`;

UBM.banned.forEach(b=>{
 html+=`
 <tr>
  <td>${b.user_id}</td>
  <td>${b.username}</td>
  <td>${b.email}</td>
  <td>${b.ip}</td>
  <td>${b.reason}</td>
  <td><button class="ubm-btn ubm-btn-unban" data-id="${b.user_id}">Unban</button></td>
 </tr>`;
});

html+=`</tbody></table><div class="ubm-pagination" id="pg-banned"></div></div>`;

document.getElementById("ubm-banned-table").innerHTML=html;
paginate("banned-users","pg-banned",10);
}

/* ----------- PAGINATION ---------- */
function paginate(id,pager,limit){
 const rows=document.querySelectorAll(`#${id} tbody tr`);
 const total=rows.length;
 const pages=Math.ceil(total/limit);
 const box=document.getElementById(pager);
 box.innerHTML="";

 for(let i=1;i<=pages;i++){
   let b=document.createElement("div");
   b.className="ubm-page-btn";
   b.textContent=i;
   b.onclick=()=>{
     [...box.children].forEach(x=>x.classList.remove("active"));
     b.classList.add("active");
     rows.forEach((r,idx)=>{ r.style.display=(idx>=(i-1)*limit&&idx<i*limit)?"":"none"; });
   };
   box.appendChild(b);
 }
 if(box.children[0]) box.children[0].click();
}

/* ----------- SEARCH ---------- */
document.addEventListener("input",e=>{
 if(e.target.classList.contains("ubm-search")){
   let id=e.target.dataset.table;
   let term=e.target.value.toLowerCase();
   document.querySelectorAll(`#${id} tbody tr`).forEach(r=>{
     r.style.display=r.textContent.toLowerCase().includes(term)?"":"none";
   });
 }
});

/* ----------- BAN / UNBAN AJAX ---------- */
let banId=null;

document.addEventListener("click",e=>{

 /* Ban */
 if(e.target.classList.contains("ubm-btn-ban")){
   banId=e.target.dataset.id;
   document.getElementById("ubm-modal-bg").style.display="flex";
 }

 /* Cancel */
 if(e.target.id==="ubm-modal-cancel"){
   document.getElementById("ubm-modal-bg").style.display="none";
 }

 /* Confirm */
 if(e.target.id==="ubm-modal-confirm"){
   jQuery.post(ajaxurl,{
     action:"ubm_ban_user",
     id:banId,
     reason:document.getElementById("ubm-modal-reason").value,
     nonce:UBM.nonce
   },()=>location.reload());
 }

 /* Unban */
 if(e.target.classList.contains("ubm-btn-unban")){
   jQuery.post(ajaxurl,{
     action:"ubm_unban_user",
     id:e.target.dataset.id,
     nonce:UBM.nonce
   },()=>location.reload());
 }

});

renderUsers();
renderBanned();
</script>

<div id="ubm-modal-bg">
  <div id="ubm-modal">
    <h3>Ban User</h3>
    <textarea id="ubm-modal-reason" placeholder="Reason..."></textarea>
    <button class="ubm-modal-btn ubm-modal-confirm" id="ubm-modal-confirm">Confirm Ban</button>
    <button class="ubm-modal-btn ubm-modal-cancel" id="ubm-modal-cancel">Cancel</button>
  </div>
</div>

<?php }); ?>
