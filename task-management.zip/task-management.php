<?php
/*
Plugin Name: Task Manager Pro
Version: 2.0
Author: Alamgir
*/

if (!defined('ABSPATH')) exit;

/* LOAD FILES EARLY */
add_action('plugins_loaded', function () {
    require_once plugin_dir_path(__FILE__) . 'custom-post.php';
    require_once plugin_dir_path(__FILE__) . 'links.php';
    require_once plugin_dir_path(__FILE__) . 'direct-links.php';

});


/*
|--------------------------------------------------------------------------
| CUSTOM POST TABLE (tm_posts) CREATE / UPDATE TABLES
|--------------------------------------------------------------------------
*/

register_activation_hook(__FILE__, 'tm_activate_all_tables');
function tm_activate_all_tables(){
    global $wpdb;

    $t1 = $wpdb->prefix . "tm_direct_links";
    $t2 = $wpdb->prefix . "tm_direct_links_settings";

    $charset = $wpdb->get_charset_collate();

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    /*
    |--------------------------------------------------------------------------
    | TASK TABLE
    |--------------------------------------------------------------------------
    */
    $table1 = $wpdb->prefix . "taskmgr_list";
    $sql1 = "CREATE TABLE $table1 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255),
        link TEXT,
        reading INT DEFAULT 0,
        rules TEXT,
        shortcode VARCHAR(255),
        status TINYINT(1) DEFAULT 1
    ) $charset;";
    dbDelta($sql1);


    /*
    |--------------------------------------------------------------------------
    | CUSTOM POST TABLE (tm_posts)
    |--------------------------------------------------------------------------
    */
    $table2 = $wpdb->prefix . "tm_posts";
    $sql2 = "CREATE TABLE $table2 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content LONGTEXT NOT NULL,
        reading_time VARCHAR(50),
        shortcode VARCHAR(255)
    ) $charset;";
    dbDelta($sql2);


    /*
    |--------------------------------------------------------------------------
    | CHEAT LOG TABLE (tm_cheat_logs) + INDEXES
    |--------------------------------------------------------------------------
    */
    $table3 = $wpdb->prefix . "tm_cheat_logs";
    $sql3 = "CREATE TABLE $table3 (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) DEFAULT 0,
        post_id BIGINT(20) DEFAULT 0,
        type VARCHAR(50) NOT NULL,
        details TEXT,
        ip_address VARCHAR(100),
        browser TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_user_id (user_id),
        KEY idx_post_id (post_id),
        KEY idx_type (type),
        KEY idx_created_at (created_at)
    ) $charset;";
    dbDelta($sql3);


    // TABLE 1 – Direct Links
    $sql1 = "CREATE TABLE IF NOT EXISTS $t1 (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        link TEXT NOT NULL,
        spend_time INT NOT NULL,
        task_rule VARCHAR(255) NOT NULL,
        code LONGTEXT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;";
    dbDelta($sql1);

    // TABLE 2 – Shortcode Settings
    $sql2 = "CREATE TABLE IF NOT EXISTS $t2 (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        shortcode LONGTEXT NULL,
        PRIMARY KEY(id)
    ) $charset;";
    dbDelta($sql2);

    // Insert default shortcode only if no setting exists
    if (!$wpdb->get_var("SELECT COUNT(*) FROM $t2")) {
        $wpdb->insert($t2, [
            'shortcode' => '[finish_button_here]'   // আপনি পরে এডিট করতে পারবেন
        ]);
    }
}



/*  
|--------------------------------------------------------------------------
| SAFE INDEX AUTO FIX (ADD IF MISSING)
|--------------------------------------------------------------------------
*/
add_action('admin_init', function () {
    global $wpdb;
    $table = $wpdb->prefix . "tm_cheat_logs";

    // Fetch current indexes
    $indexes = $wpdb->get_results("SHOW INDEX FROM $table", ARRAY_A);
    $existing = wp_list_pluck($indexes, 'Key_name');

    // Helper
    $check = function($name, $query) use ($existing, $wpdb) {
        if (!in_array($name, $existing)) {
            $wpdb->query($query);
        }
    };

    // Add index if missing
    $check('idx_user_id',     "ALTER TABLE $table ADD INDEX idx_user_id (user_id)");
    $check('idx_post_id',     "ALTER TABLE $table ADD INDEX idx_post_id (post_id)");
    $check('idx_type',        "ALTER TABLE $table ADD INDEX idx_type (type)");
    $check('idx_created_at',  "ALTER TABLE $table ADD INDEX idx_created_at (created_at)");
});


 
/*
|--------------------------------------------------------------------------
| HTML Allow
|--------------------------------------------------------------------------
*/
add_filter('wp_kses_allowed_html', function ($tags, $context) {

    // Make custom plugin editor behave like WP post editor
    if ($context === 'post' || $context === 'data' || $context === 'admin') {

        // <form>
        $tags['form'] = [
            'action' => true,
            'method' => true,
            'class' => true,
            'id'    => true
        ];

        // <input>
        $tags['input'] = [
            'type'        => true,
            'name'        => true,
            'id'          => true,
            'value'       => true,
            'class'       => true,
            'placeholder' => true,
        ];

        // <label>
        $tags['label'] = [
            'for'   => true,
            'class' => true
        ];

        // <button>
        $tags['button'] = [
            'type'  => true,
            'class' => true
        ];
    }

    return $tags;

}, 10, 2);



/* MENU SYSTEM */
add_action('admin_menu','tm_admin_menu');
function tm_admin_menu(){

    // MAIN MENU
    add_menu_page(
        'Task Management',
        'Task Management',
        'manage_options',
        'taskmgr-main',
        'taskmgr_links_page',
        'dashicons-list-view'
    );

    // SUBMENU: Task Management (same page)
    add_submenu_page(
        'taskmgr-main',
        'Task Management',
        'Task Management',
        'manage_options',
        'taskmgr-main',
        'taskmgr_links_page'
    );

    // ✔ EXISTING SUBMENU: Links (unchanged)
    add_submenu_page(
        'taskmgr-main',
        'Links',
        'Links',
        'manage_options',
        'taskmgr-links',
        'taskmgr_links_page'
    );

    // ⭐ NEW SUBMENU: Direct Links (added below Links)
    add_submenu_page(
        'taskmgr-main',
        'Direct Links',         // Page Title
        'Direct Links',         // Submenu Label
        'manage_options',
        'taskmgr-direct-links', // Unique slug
        'tm_direct_links_page'  // NEW callback in direct-links.php
    );

    // SUBMENU: Custom Post
    add_submenu_page(
        'taskmgr-main',
        'Custom Post',
        'Custom Post',
        'manage_options',
        'custom-post',
        'tm_post_list_page'
    );
}




/*
|--------------------------------------------------------------------------
| UNINSTALL — CLEAN UP
|--------------------------------------------------------------------------
*/
register_uninstall_hook(__FILE__, 'taskmgr_uninstall');
function taskmgr_uninstall()
{
    global $wpdb;

    // delete old table
    $table1 = $wpdb->prefix . "taskmgr_list";
    $wpdb->query("DROP TABLE IF EXISTS $table1");

    // delete custom post table
    $table2 = $wpdb->prefix . "tm_posts";
    $wpdb->query("DROP TABLE IF EXISTS $table2");
}


/*
|--------------------------------------------------------------------------
| Allow css code
|--------------------------------------------------------------------------
*/

add_filter('wp_kses_allowed_html', function ($tags, $context) {

    if ($context === 'post' || $context === 'data' || $context === 'admin') {

        // Allow <style>
        $tags['style'] = [
            'type'  => true,
            'media' => true
        ];

        // Allow forms
        $tags['form'] = [
            'action' => true,
            'method' => true,
            'class'  => true,
            'id'     => true
        ];

        // Allow input
        $tags['input'] = [
            'type'        => true,
            'name'        => true,
            'id'          => true,
            'value'       => true,
            'class'       => true,
            'placeholder' => true,
        ];

        // Allow label
        $tags['label'] = [
            'for'   => true,
            'class' => true
        ];

        // Allow button
        $tags['button'] = [
            'type'  => true,
            'class' => true
        ];
    }

    return $tags;

}, 10, 2);

/*
|--------------------------------------------------------------------------
| Allow JS code
|--------------------------------------------------------------------------
*/
add_filter('wp_kses_allowed_html', function ($tags, $context) {

    if ($context === 'post' || $context === 'data' || $context === 'admin') {

        // Allow <script>
        $tags['script'] = [
            'type' => true,
            'src'  => true,
            'async'=> true,
            'defer'=> true,
        ];
    }

    return $tags;
}, 10, 2);

/*
|--------------------------------------------------------------------------
| TinyMCE Editor Buttons
|--------------------------------------------------------------------------
*/

add_filter('mce_buttons', function($buttons) {
    // First row Extra Buttons
    $buttons[] = 'fontselect';
    $buttons[] = 'fontsizeselect';
    $buttons[] = 'styleselect';
    $buttons[] = 'hr';
    $buttons[] = 'cut';
    $buttons[] = 'copy';
    $buttons[] = 'paste';
    $buttons[] = 'backcolor';
    return $buttons;
});

add_filter('mce_buttons_2', function($buttons) {
    // Second row Extra buttons
    $buttons[] = 'subscript';
    $buttons[] = 'superscript';
    $buttons[] = 'outdent';
    $buttons[] = 'indent';
    $buttons[] = 'visualaid';
    $buttons[] = 'charmap';
    $buttons[] = 'anchor';
    return $buttons;
});


/*
|--------------------------------------------------------------------------
|  PrismJS Load
|--------------------------------------------------------------------------
*/

function tm_load_prism_assets() {
    // CSS
    wp_enqueue_style('prism-css', 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism.min.css');

    // JS
    wp_enqueue_script('prism-js', 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js', [], null, true);
    wp_enqueue_script('prism-js-autoloader', 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/autoloader/prism-autoloader.min.js', [], null, true);
}
add_action('wp_enqueue_scripts', 'tm_load_prism_assets');
add_action('admin_enqueue_scripts', 'tm_load_prism_assets');

