<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| ADMIN PAGE UI (ADD + EDIT + DELETE)
|--------------------------------------------------------------------------
*/
function tm_post_list_page() {
    global $wpdb;
    $table = $wpdb->prefix . "tm_posts";


    /* DELETE */
if (isset($_GET['delete'], $_GET['_wpnonce'])) {

    if (!wp_verify_nonce($_GET['_wpnonce'], "tm_delete_post")) {
        wp_die("Security check failed!");
    }

    $id = intval($_GET['delete']);
    $wpdb->delete($table, ["id" => $id]);

    echo '<div class="updated"><p><strong>Deleted!</strong></p></div>';
}

    /* EDIT */
    $edit = null;
    if (isset($_GET['edit'])) {
        $id = intval($_GET['edit']);
        $edit = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM $table WHERE id=%d", $id)
);

    }

/* SAVE / UPDATE */
if (!empty($_POST['tm_title'])) {

    // SECURITY CHECK (Optional)
    if (isset($_POST['tm_post_nonce']) &&
        ! wp_verify_nonce($_POST['tm_post_nonce'], 'tm_post_save_action')) {
        wp_die("Security check failed!");
    }

    $data = [
        "title"        => sanitize_text_field( wp_unslash($_POST["tm_title"]) ),
        "content"      => wp_kses_post( wp_unslash($_POST["tm_content"]) ),
        "reading_time" => sanitize_text_field( wp_unslash($_POST["tm_reading"]) ),
        "shortcode"    => sanitize_text_field( wp_unslash($_POST["tm_shortcode"]) )
    ];

    if (!empty($_POST['tm_id'])) {

        // UPDATE
        $wpdb->update(
            $table,
            $data,
            ["id" => intval($_POST["tm_id"])]
        );

        echo '<div class="updated"><p><strong>Updated Successfully!</strong></p></div>';

    } else {

        // INSERT
        $wpdb->insert($table, $data);

        echo '<div class="updated"><p><strong>Saved Successfully!</strong></p></div>';
    }
}

?>


<div class="wrap">
        <h2><?php echo $edit ? "Edit Custom Post" : "Add Custom Post"; ?></h2>

        <form method="post" style="margin-top:20px;">
            <input type="hidden" name="tm_id" value="<?php echo $edit->id ?? ''; ?>">

            <label><strong>Title:</strong></label><br>
            <input type="text" name="tm_title" style="width:100%" required
                value="<?php echo esc_attr($edit->title ?? ''); ?>"><br><br>

            <label><strong>Content (HTML/CSS/JS allowed):</strong></label><br>
           <?php
$content_value = $edit->content ?? '';

wp_editor(
    $content_value,
    'tm_content',
    [
        'textarea_name' => 'tm_content',
        'media_buttons' => true,
        'teeny'         => false,
        'textarea_rows' => 15,
        'drag_drop_upload' => true
    ]
          );
         ?>
          <br><br>

            <label><strong>Reading Time:</strong></label><br>
            <input type="text" name="tm_reading" style="width:200px"
                value="<?php echo esc_attr($edit->reading_time ?? ''); ?>"><br><br>

            <label><strong>External Shortcode:</strong></label><br>
            <input type="text" name="tm_shortcode" style="width:100%"
                value="<?php echo esc_attr($edit->shortcode ?? ''); ?>"><br><br>

            <button class="button button-primary"><?php echo $edit ? "Update" : "Save"; ?></button>
        </form>

        <hr>

        <h2>Saved Posts</h2>

        <table class="widefat">
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Reading</th>
                <th>Shortcode</th>
                <th>Actions</th>
            </tr>

            <?php

            $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");
foreach ($rows as $r) {

    $nonce = wp_create_nonce("tm_delete_post");

    echo "<tr>
            <td>$r->id</td>
            <td>$r->title</td>
            <td>$r->reading_time</td>
            <td>$r->shortcode</td>
            <td style='white-space:nowrap'>
                <a class='button' href='?page=custom-post&edit={$r->id}'>Edit</a>

                <a class='button' 
                   href='?page=custom-post&delete={$r->id}&_wpnonce={$nonce}'
                   onclick='return confirm(\"Are you sure?\")'>
                   Delete
                </a>
            </td>
          </tr>";
}

             
            ?>
        </table>
    </div>

<?php
}

/*
|--------------------------------------------------------------------------
| UNIVERSAL SHORTCODE: SINGLE + LOOP COMBINED + MODAL BEAUTIFUL UI
|--------------------------------------------------------------------------
*/
function tm_universal_post_shortcode($atts) {
    global $wpdb;
    $table = $wpdb->prefix . "tm_posts";

    $id = isset($atts['id']) ? intval($atts['id']) : 0;

    // If single post mode
    if ($id > 0) {
        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE id=%d", $id
        ));
    } 
    // If loop (all posts) mode
    else {
        $posts = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");
    }

    if (!$posts) {
        return "<p>No posts found.</p>";
    }

    ob_start();

    foreach ($posts as $p):

        $external = do_shortcode($p->shortcode);
        ?>

        <div class="tm-card">

            <h2 class="tm-title"><?php echo esc_html($p->title); ?></h2>

            <p class="tm-reading">⏱ <?php echo esc_html($p->reading_time); ?></p>

            <div class="tm-content">
                <?php echo apply_filters('the_content', $p->content); ?>
            </div>

            <button class="tm-btn tm-open" data-id="<?php echo $p->id; ?>">Open</button>
        </div>

        <!-- MODAL -->
        <div id="tmModal_<?php echo $p->id; ?>" class="tm-modal">
            <div class="tm-modal-content">
                <span class="tm-close" data-id="<?php echo $p->id; ?>">&times;</span>
                <?php echo $external; ?>
            </div>
        </div>

    <?php endforeach; ?>

    <style>
        .tm-card{
            border:1px solid #ddd;
            padding:20px;
            border-radius:10px;
            margin:20px 0;
            background:#fafafa;
            box-shadow:0 3px 10px rgba(0,0,0,.1);
        }
        .tm-title{ margin:0 0 10px 0; font-size:22px; }
        .tm-reading{ color:#444; margin-bottom:15px; }
        .tm-btn{
            background:#2271b1;
            color:#fff;
            padding:10px 20px;
            border-radius:5px;
            cursor:pointer;
            border:none;
            font-size:16px;
        }
        .tm-btn:hover{ background:#135e96; }

        .tm-modal{
            display:none;
            position:fixed;
            top:0;left:0;
            width:100%;height:100%;
            background:rgba(0,0,0,.6);
            justify-content:center;
            align-items:center;
            z-index:99999;
        }
        .tm-modal-content{
            background:#fff;
            padding:25px;
            border-radius:10px;
            width:400px;
            max-width:95%;
            box-shadow:0 0 20px rgba(0,0,0,.3);
            animation: fadeIn .3s ease;
        }
        .tm-close{
            float:right;
            font-size:24px;
            cursor:pointer;
        }

        @keyframes fadeIn{
            from {opacity:0; transform:scale(.9);}
            to {opacity:1; transform:scale(1);}
        }
    </style>

    <script>
    document.addEventListener("click", function(e){

        /* Open Modal */
        if (e.target.classList.contains("tm-open")) {
            const id = e.target.dataset.id;
            document.getElementById("tmModal_" + id).style.display = "flex";
        }

        /* Close Modal */
        if (e.target.classList.contains("tm-close")) {
            const id = e.target.dataset.id;
            document.getElementById("tmModal_" + id).style.display = "none";
        }

    });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode("tm_post", "tm_universal_post_shortcode");



/*
|--------------------------------------------------------------------------
| GLOBAL REWARD SHORTCODE SETTINGS PAGE
|--------------------------------------------------------------------------
*/
add_action('admin_menu', function() {
    add_submenu_page(
        'taskmgr-main',
        'Reward Settings',
        'Reward Settings',
        'manage_options',
        'tm-reward-settings',
        'tm_reward_settings_page'
    );
});



function tm_reward_settings_page() {

    /* ================================
       SAVE FORM DATA
    ================================= */
    if (isset($_POST['tm_reward_shortcode'])) {

        // Save speed level
        if (isset($_POST['tm_speed_level'])) {
            update_option('tm_speed_level', intval($_POST['tm_speed_level']), 'no');
        }

        // Save shortcode
        $shortcode = wp_unslash($_POST['tm_reward_shortcode']);
        update_option('tm_reward_shortcode', $shortcode, 'no');

        echo '<div class="updated"><p><strong>Reward shortcode updated!</strong></p></div>';
    }

    // Load saved values
    $speed_level = get_option('tm_speed_level', 150);
    $saved = get_option('tm_reward_shortcode');
    ?>

    <div class="wrap">
        <h2>Global Reward Shortcode</h2>

        <form method="post">

            <!-- ================= Shortcode Input ================= -->
            <label><strong>Reward Shortcode:</strong></label><br>
            <input type="text"
                name="tm_reward_shortcode"
                style="width:100%; padding:8px; font-size:16px;"
                value="<?php echo esc_attr($saved); ?>"
                placeholder='[Alamgir id="1"]'
            ><br><br>


            <!-- ================= Scroll Speed Slider ================= -->
            <label><strong>Scroll Speed Control:</strong></label><br>

            <input type="range"
                name="tm_speed_level"
                min="50" max="600" step="10"
                value="<?php echo $speed_level; ?>"
                oninput="document.getElementById('tm_speed_value').innerText = this.value"
            >

            <p>
                Current Speed:
                <strong id="tm_speed_value"><?php echo $speed_level; ?></strong> px/sec
            </p>

            <br><br>

            <button class="button button-primary">Save</button>

        </form>
    </div>

    <?php
}

if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| FRONTEND SHORTCODE: SEQUENTIAL READING WITH ANTI-CHEAT + DOUBLE PROGRESS BAR
|--------------------------------------------------------------------------
*/
add_shortcode("tm_progress", function () {
    global $wpdb;

    $table = $wpdb->prefix . "tm_posts";
    $posts = $wpdb->get_results("SELECT * FROM $table ORDER BY id ASC");

    if (!$posts) return "<p>No posts found.</p>";

    // Load reward shortcode
    $reward_sc = get_option("tm_reward_shortcode");

    ob_start();
?>

<!------------------------  PREMIUM CSS  ------------------------>
<style>
/* TYPOGRAPHY & LAYOUT */
.tm-container{
    max-width: 800px;
    margin: 35px auto;
    padding: 10px 20px;
    font-family: "Segoe UI", Roboto, sans-serif;
    line-height: 1.7;
    color: #333;
}

/* FADE-IN ANIMATION */
.tm-post-box{
    display: none;
    opacity: 0;
    transform: translateY(15px);
    transition: all .45s ease;
    background: #fff;
    padding: 28px;
    border-radius: 12px;
    box-shadow: 0 4px 18px rgba(0,0,0,.08);
}
.tm-post-box.active{
    display: block;
    opacity: 1;
    transform: translateY(0px);
}

/* BUTTON */
.tm-next-btn{
    padding: 12px 28px;
    font-size: 17px;
    background: #2271b1;
    border: none;
    color: #fff;
    border-radius: 6px;
    margin-top: 16px;
    cursor: pointer;
}
.tm-next-btn:disabled{
    opacity: .4;
    cursor: not-allowed;
}

/* PROGRESS BAR – SCROLL */
#tm-scroll-bar{
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: #ddd;
    z-index: 99999;
}
#tm-scroll-fill{
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, #ff4444, #ff8800, #ffee00, #22cc22);
    transition: width .2s linear;
}

/* Prevent Overlap with WP Admin Bar */
body.admin-bar #tm-scroll-bar {
    top: 32px !important;
}

body.admin-bar #tm-timer-bar {
    top: 36px !important;
}

/* Support for mobile notch (iPhone safe area) */
#tm-scroll-bar,
#tm-timer-bar {
    padding-top: env(safe-area-inset-top);
}


/* PROGRESS BAR – TIMER */
#tm-timer-bar{
    position: fixed;
    top: 4px;
    left: 0;
    width: 100%;
    height: 4px;
    background: #ccc;
    z-index: 99999;
}
#tm-timer-fill{
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, red, orange, yellow, lightgreen, green);
    transition: width .3s ease;
}



/* CIRCULAR TIMER */
.tm-circle-wrapper{
    display: flex;
    justify-content: center;
    margin: 20px 0;
}
.tm-circle{
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 10px solid red; /* RED at start */
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 26px;
    font-weight: bold;
    color: #333;
    transition: border-color .3s linear; /* Smooth change */
}


</style>


<!------------------------  PROGRESS BARS  ------------------------>
<div id="tm-scroll-bar"><div id="tm-scroll-fill"></div></div>
<div id="tm-timer-bar"><div id="tm-timer-fill"></div></div>

<div class="tm-container">

<?php foreach ($posts as $i => $p): ?>
    <div class="tm-post-box" id="tm-post-<?php echo $i; ?>">
        <h2><?php echo esc_html($p->title); ?></h2>

        <div><?php echo wp_kses_post($p->content); ?></div>

        <div class="tm-circle-wrapper">
            <div class="tm-circle">
                <span id="tm-timer-<?php echo $i; ?>"></span>
            </div>
        </div>

        <button class="tm-next-btn" id="tm-next-<?php echo $i; ?>" disabled>Next</button>
    </div>
<?php endforeach; ?>

<div class="tm-post-box" id="tm-final">
    <h2>Completed!</h2>
    <p>You have finished all posts.</p>
    <div><?php echo do_shortcode($reward_sc); ?></div>
</div>

</div> <!-- /container -->


<!------------------------  JAVASCRIPT LOGIC  ------------------------>
<script>

let maxScrollSpeed = <?php echo get_option('tm_speed_level', 150); ?>;
let totalPosts = <?php echo count($posts); ?>;
let current = 0;

let readingTimes = [
    <?php foreach ($posts as $p) echo intval($p->reading_time) . ","; ?>
];

let timer = 0;
let interval = null;
let scrollPercent = 0;
let activeTab = true;
let forceScrollAllowed = false;
let autoScrollDone = [];



/* LOCK PREVIOUS POST (NO BACKSTEP) */

/* SHOW POST WITH FADE-IN */
function showPost(i){
    document.querySelectorAll('.tm-post-box').forEach(b => b.classList.remove('active'));
    document.getElementById("tm-post-" + i)?.classList.add('active');
}

/* SHOW FINAL */
function showFinal(){
    document.querySelectorAll('.tm-post-box').forEach(b => b.classList.remove('active'));
    document.getElementById("tm-final").classList.add('active');
}

/* TIMER BAR */
function updateTimerBar(){
    let total = readingTimes[current];
    let done = total - timer;
    let percent = (done / total) * 100;
    document.getElementById("tm-timer-fill").style.width = percent + "%";
}

/* ←← EXACTLY এই লাইনের নিচে ফাংশনটা বসবে */

function updateCircleColor() {
    let total = readingTimes[current];
    let left = timer;
    let percent = 1 - (left / total);

    let color = "red";

    if (percent > 0.25) color = "#ff6600";
    if (percent > 0.50) color = "#ffcc00";
    if (percent > 0.75) color = "#66cc33";
    if (percent >= 1)   color = "green";

    let circle = document.querySelector("#tm-post-" + current + " .tm-circle");
    if (circle) circle.style.borderColor = color;
}


/* SCROLL BAR + DOUBLE SCROLL LOGIC */

/* ========== SCROLL SPEED TRACKER ========== */

/* =========================
   SCROLL SPEED LIMITER
   Based on backend slider
   ========================= */

let scrollLock = false;  

window.addEventListener("wheel", function(e) {

    e.preventDefault();  // default fast scrolling বন্ধ

    if (scrollLock) return;

    scrollLock = true;

    let direction = (e.deltaY > 0) ? 1 : -1;

    // Backend speed → smooth scroll amount
    let step = Math.max(10, Math.min(maxScrollSpeed, 200));  
    // step = 10 → খুব slow
    // step = 200 → fast-ish but controlled

    window.scrollBy({
        top: direction * step,
        behavior: 'smooth'
    });

    // Backend speed → speed time delay
    let delay = Math.max(50, 300 - maxScrollSpeed);

    setTimeout(() => {
        scrollLock = false;
    }, delay);

}, { passive:false });


let lastScrollTop = 0;
let lastScrollTime = Date.now();
let scrollSpeed = 0;

window.addEventListener("scroll", () => {
    let now = Date.now();
    let diffTime = now - lastScrollTime;

    let st = window.scrollY;
    let diffScroll = Math.abs(st - lastScrollTop);

    scrollSpeed = (diffScroll / diffTime) * 1000;  // px/sec

    lastScrollTop = st;
    lastScrollTime = now;
});


window.addEventListener("scroll", () => {

    // Total scrollable area
    const full = document.body.scrollHeight - window.innerHeight;
    const pos  = window.scrollY;

    // Current scroll percent
    scrollPercent = ((pos / full) * 100);

    // Dynamic scroll threshold
    window.dynamicScroll = full < 800 ? 10 : 90;

    // Update scroll bar
    document.getElementById("tm-scroll-fill").style.width = scrollPercent + "%";

});


/* VISIBILITY CHECK */
document.addEventListener("visibilitychange", () => {
    activeTab = !document.hidden;
    if (!activeTab) pauseTimer();
});



/* ============================================
   CONFIG: Auto scroll point = 2/3 (≈ 66.6%)
   ============================================ */
let timerPausedManually = false;

/* STOP TIMER SAFELY */
function pauseTimer() {
    clearInterval(interval);
    timerPausedManually = true;
}

/* RESUME TIMER SAFELY */
function resumeTimer(){
    if (!timerPausedManually) return;
    timerPausedManually = false;
    startTimer();
}


/* LISTEN FOR USER SCROLL (Resume logic) */
window.addEventListener("scroll", function () {

    // user must scroll down at least a bit
    if (window.scrollY > 50 && timerPausedManually) {
        resumeTimer();
    }

    // update scrollPercent
    const full = document.body.scrollHeight - window.innerHeight;
    const pos  = window.scrollY;
    scrollPercent = (pos/full)*100;
});


/* START TIMER */

function startTimer() {

    timer = readingTimes[current];
    document.getElementById("tm-timer-" + current).textContent = timer;

    let total = readingTimes[current];
    let threshold = Math.floor(total * (2/3));   // 66%

    interval = setInterval(() => {

        /* TIMER CAN ONLY TICK IF:
           - user did required scroll
           - not paused
        */
        if (
            timer > 0 &&
            activeTab &&
            !timerPausedManually
        ) {

            timer--;
            document.getElementById("tm-timer-" + current).textContent = timer;
            updateTimerBar();
            updateCircleColor();

            /* AUTO SCROLL TRIGGER */
            if (!autoScrollDone[current] && timer === threshold) {

                autoScrollDone[current] = true;

                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                });

                // pause immediately after auto-scroll
                pauseTimer();
            }
        }


        /* TIMER FINISHED */
        if (timer <= 0) {

            clearInterval(interval);
            timer = 0;

            document.getElementById("tm-next-" + current).disabled = false;

            // full green
            document.getElementById("tm-timer-fill").style.width = "100%";
        }

    }, 1000);
}

/* NEXT ACTION */
document.querySelectorAll('.tm-next-btn').forEach((btn, i) => {
    btn.addEventListener("click", () => goNext());
});

/* AUTO NEXT SYSTEM */
function goNext(){
    current++;
    if (current >= totalPosts){
        showFinal();
        return;
    }

    showPost(current);

    // Reset scroll + bar + auto flags
    window.scrollTo(0,0);
    resetBars();

    autoScrollDone[current] = false;

    // VERY IMPORTANT:
    // New post will not start timer until user scrolls
    timerPausedManually = true;
}

function resetBars(){
    document.getElementById("tm-timer-fill").style.width = "0%";
    scrollPercent = 0;
    document.getElementById("tm-scroll-fill").style.width = "0%";

    /* ←← THIS WILL RESET THE CIRCLE TO RED */
    let circle = document.querySelector("#tm-post-" + current + " .tm-circle");
    if (circle) circle.style.borderColor = "red";

    autoScrollDone[current] = false;

}


/* INIT FIRST */
showPost(0);
startTimer();


/* AJAX URL for WordPress */
var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";

function reportCheat(type, details){
    fetch(ajaxurl, {
        method: "POST",
        headers: {"Content-Type":"application/x-www-form-urlencoded"},
        body: `action=tm_log_cheat&type=${type}&details=${details}&post=${current}`
    });
}


/* TAB SWITCH CHEAT */
document.addEventListener("visibilitychange", ()=>{
    if(document.hidden){
        reportCheat("tab-switch", "User switched tab during reading");
    }
});

/* WINDOW RESIZE CHEAT */
window.addEventListener("resize", ()=>{
    reportCheat("resize", "User resized the window while reading");
});

</script>
<?php
return ob_get_clean();
});
?>
<?php



/*
|--------------------------------------------------------------------------  
| 2) AJAX – CHEAT LOGGING HANDLER
|--------------------------------------------------------------------------  
*/
add_action("wp_ajax_tm_log_cheat", "tm_log_cheat");
add_action("wp_ajax_nopriv_tm_log_cheat", "tm_log_cheat");

function tm_log_cheat() {
    global $wpdb;
    $table = $wpdb->prefix . "tm_cheat_logs";

    $wpdb->insert($table, [
        "user_id"    => get_current_user_id(),
        "post_id"    => intval($_POST["post"]),
        "type"       => sanitize_text_field($_POST["type"]),
        "details"    => sanitize_text_field($_POST["details"]),
        "ip_address" => sanitize_text_field($_SERVER['REMOTE_ADDR']),
        "browser"    => sanitize_text_field($_SERVER['HTTP_USER_AGENT']),
        "created_at" => current_time('mysql')
    ]);

    wp_send_json_success("logged");
}



/*
|--------------------------------------------------------------------------  
| 4) ADMIN MENU – CHEAT LOGS + ANALYTICS
|--------------------------------------------------------------------------  
*/
add_action('admin_menu', function () {

    add_submenu_page(
        'taskmgr-main',
        'Cheat Logs',
        'Cheat Logs',
        'manage_options',
        'tm-cheat-logs',
        'tm_cheat_log_page'
    );

    add_submenu_page(
        'taskmgr-main',
        'Analytics Dashboard',
        'Analytics',
        'manage_options',
        'tm-analytics',
        'tm_analytics_page'
    );
});


/*
|--------------------------------------------------------------------------  
| 5) CHEAT LOG PAGE (MODERN UI)
|--------------------------------------------------------------------------  

*/

function tm_cheat_log_page() {
    global $wpdb;
    $table = $wpdb->prefix . "tm_cheat_logs";

    /* ===============================
       DELETE SELECTED
       =============================== */
        if (isset($_POST['tm_delete_selected']) && !empty($_POST['ids'])) {

        $ids = array_map('intval', $_POST['ids']);
        $wpdb->query("DELETE FROM $table WHERE id IN (" . implode(',', $ids) . ")");
        echo '<div class="updated"><p><strong>Selected logs deleted!</strong></p></div>';
    }

    /* ===============================
       DELETE ALL
       =============================== */
        if (isset($_POST['tm_delete_all'])) {

        $wpdb->query("TRUNCATE TABLE $table");
        echo '<div class="updated"><p><strong>All logs deleted!</strong></p></div>';
    }

    /* ===============================
       FILTERS
       =============================== */

    $filter_user = isset($_GET['f_user']) ? intval($_GET['f_user']) : 0;
    $filter_type = isset($_GET['f_type']) ? sanitize_text_field($_GET['f_type']) : '';

    // build SQL dynamically
    $where = "WHERE 1=1";

    if ($filter_user > 0) {
        $where .= $wpdb->prepare(" AND user_id = %d", $filter_user);
        $where .= $wpdb->prepare(" AND type = %s", $filter_type);


    }

    if (!empty($filter_type)) {
        $where .= $wpdb->prepare(" AND type = %s", $filter_type);
    }

    $logs = $wpdb->get_results("SELECT * FROM $table $where ORDER BY id DESC LIMIT 500");

    /* Load user list for dropdown */
    $users = $wpdb->get_results("SELECT DISTINCT user_id FROM $table WHERE user_id > 0");
    
    /* Load cheat types dynamically */
    $types = $wpdb->get_col("SELECT DISTINCT type FROM $table ORDER BY type ASC");
?>
<div class="wrap">
    <h1 style="margin-bottom:20px;">🔥 Cheat Detection Logs</h1>

    <!-- FILTER FORM -->
    <form method="get" style="margin-bottom:15px; display:flex; gap:15px;">
        <input type="hidden" name="page" value="tm-cheat-logs">

        <!-- USER FILTER -->
        <select name="f_user" style="padding:6px 10px;">
            <option value="0">All Users</option>
            <?php foreach ($users as $u):
                $userdata = get_user_by('id', $u->user_id);
                if ($userdata): ?>
                    <option value="<?php echo $u->user_id; ?>" <?php selected($filter_user, $u->user_id); ?>>
                        <?php echo $userdata->user_login; ?>
                    </option>
                <?php endif;
            endforeach; ?>
        </select>

        <!-- TYPE FILTER -->
        <select name="f_type" style="padding:6px 10px;">
            <option value="">All Types</option>
            <?php foreach ($types as $t): ?>
                <option value="<?php echo esc_attr($t); ?>" <?php selected($filter_type, $t); ?>>
                    <?php echo ucfirst($t); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="button button-primary">Filter</button>
    </form>

<!-- DELETE BUTTONS -->
<form method="post">

    <button name="tm_delete_selected" class="button button-primary" style="margin-bottom:10px;">
        Delete Selected
    </button>

    <button name="tm_delete_all" class="button button-danger" 
        style="margin-bottom:10px;background:#d63638;color:#fff;">
        Delete All Logs
    </button>

    <div style="background:#fff; padding:20px; border-radius:10px; box-shadow:0 4px 15px rgba(0,0,0,.1);">

        <table class="wp-list-table widefat striped">
            <thead>
                <tr>
                    <th><input type="checkbox" id="tm_select_all"></th>
                    <th>User</th>
                    <th>Post</th>
                    <th>Type</th>
                    <th>Details</th>
                    <th>IP</th>
                    <th>Browser</th>
                    <th>Date</th>
                </tr>
            </thead>

            <tbody>
            <?php foreach ($logs as $r): ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?php echo $r->id; ?>"></td>

                    <td><?php echo get_user_by('id', $r->user_id)->user_login ?? "Guest"; ?></td>
                    <td><?php echo $r->post_id; ?></td>
                    <td><strong><?php echo ucfirst($r->type); ?></strong></td>
                    <td><?php echo esc_html($r->details); ?></td>
                    <td><?php echo $r->ip_address; ?></td>
                    <td><?php echo substr($r->browser, 0, 40); ?>...</td>
                    <td><?php echo $r->created_at; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

    </div>
</form>

<script>
document.getElementById("tm_select_all").addEventListener("change", function(){
    let checks = document.querySelectorAll("input[name='ids[]']");
    checks.forEach(c => c.checked = this.checked);
});
</script>

<?php
}

/*
|--------------------------------------------------------------------------  
| 6) ANALYTICS DASHBOARD (CHART.JS INCLUDED)
|--------------------------------------------------------------------------  
*/
function tm_analytics_page() {
    global $wpdb;

    $table_posts = $wpdb->prefix . "tm_posts";
    $table_cheat = $wpdb->prefix . "tm_cheat_logs";

    $post_count   = $wpdb->get_var("SELECT COUNT(*) FROM $table_posts");
    $cheat_count  = $wpdb->get_var("SELECT COUNT(*) FROM $table_cheat");

    // cheat type counts
    $scroll  = $wpdb->get_var("SELECT COUNT(*) FROM $table_cheat WHERE type='scroll'");
    $tab     = $wpdb->get_var("SELECT COUNT(*) FROM $table_cheat WHERE type='tab-switch'");
    $resize  = $wpdb->get_var("SELECT COUNT(*) FROM $table_cheat WHERE type='resize'");
    $speed   = $wpdb->get_var("SELECT COUNT(*) FROM $table_cheat WHERE type='speed'");
?>

<div class="wrap">
    <h1 style="margin-bottom:20px;">📊 Analytics Dashboard</h1>

    <div style="display:flex; gap:20px; margin-bottom:30px;">

        <div style="flex:1;background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 18px rgba(0,0,0,.1);">
            <h2>Total Posts</h2>
            <h1><?php echo $post_count; ?></h1>
        </div>

        <div style="flex:1;background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 18px rgba(0,0,0,.1);">
            <h2>Total Cheats Logged</h2>
            <h1><?php echo $cheat_count; ?></h1>
        </div>

    </div>

    <div style="background:#fff;padding:20px;border-radius:12px;box-shadow:0 4px 18px rgba(0,0,0,.1);">
        <h2>Cheat Types Breakdown</h2>

        <canvas id="tmCheatChart" style="max-width:600px;"></canvas>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
        new Chart(document.getElementById("tmCheatChart"),{
            type:"bar",
            data:{
                labels:["Scroll","Tab Switch","Resize","Speed"],
                datasets:[{
                    label:"Cheat Attempts",
                    data:[<?php echo "$scroll,$tab,$resize,$speed"; ?>],
                }]
            }
        });
        </script>
    </div>

</div>

<?php
}


