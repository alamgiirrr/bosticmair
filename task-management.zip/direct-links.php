<?php
if (!defined('ABSPATH')) exit;

/* --------------------------------------------------------------------------
| PAGE UI + CRUD + SHORTCODE SAVE
--------------------------------------------------------------------------- */
function tm_direct_links_page() {
    global $wpdb;
    $table = $wpdb->prefix . "tm_direct_links";
    $settings = $wpdb->prefix . "tm_direct_links_settings";

    /* ---------- SAVE SHORTCODE ---------- */
    if (isset($_POST['tm_save_shortcode'])) {
        $shortcode = trim($_POST['shortcode']);
        $wpdb->update($settings, ['shortcode' => $shortcode], ['id' => 1]);
        echo '<div class="updated"><p>Shortcode Saved!</p></div>';
    }

    /* ---------- DELETE ---------- */
    if (isset($_GET['delete'])) {
        $wpdb->delete($table, ['id' => intval($_GET['delete'])]);
        echo '<div class="updated"><p>Deleted!</p></div>';
    }

    /* ---------- SAVE / UPDATE LINK ---------- */
    if (isset($_POST['tm_save_direct_link'])) {
        $data = [
            'name'       => sanitize_text_field($_POST['name']),
            'link'       => $_POST['link'],               // NO sanitize (your requirement)
            'spend_time' => intval($_POST['spend_time']),
            'task_rule'  => sanitize_text_field($_POST['task_rule']),
            'code'       => $_POST['code']                // FULL RAW HTML+CSS+JS
        ];

        if (!empty($_POST['id'])) {
            $wpdb->update($table, $data, ['id' => intval($_POST['id'])]);
            echo '<div class="updated"><p>Updated!</p></div>';
        } else {
            $wpdb->insert($table, $data);
            echo '<div class="updated"><p>Created!</p></div>';
        }
    }

    $edit = null;
    if (isset($_GET['edit'])) {
        $edit = $wpdb->get_row("SELECT * FROM $table WHERE id=" . intval($_GET['edit']));
    }

    $sc = $wpdb->get_var("SELECT shortcode FROM $settings WHERE id=1");
?>

<div class="wrap">
    <h1>Direct Links</h1>

    <!-- FORM -->
    <form method="post">
        <input type="hidden" name="id" value="<?php echo $edit->id ?? ''; ?>">

        <table class="form-table">
            <tr><th>Name</th>
                <td><input type="text" name="name" value="<?php echo $edit->name ?? '' ?>" class="regular-text"></td>
            </tr>

            <tr><th>Link</th>
                <td><input type="text" name="link" value="<?php echo $edit->link ?? '' ?>" class="regular-text"></td>
            </tr>

            <tr><th>Spend Time (sec)</th>
                <td><input type="number" name="spend_time" value="<?php echo $edit->spend_time ?? '' ?>"></td>
            </tr>

            <tr><th>Task Rule</th>
                <td><input type="text" name="task_rule" value="<?php echo $edit->task_rule ?? '' ?>" class="regular-text"></td>
            </tr>

            <tr><th>HTML + CSS + JS (raw)</th>
                <td><textarea name="code" rows="12" style="width:100%;"><?php echo $edit->code ?? '' ?></textarea></td>
            </tr>
        </table>

        <p><button class="button button-primary" name="tm_save_direct_link">Save</button></p>
    </form>

    <hr>

    <!-- TABLE -->
    <h2>All Links</h2>

    <table class="widefat striped">
        <thead><tr>
            <th>ID</th><th>Name</th><th>Spend</th><th>Task</th><th>Action</th>
        </tr></thead>
        <tbody>
        <?php
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY id ASC");
        if ($rows):
            foreach ($rows as $r):
        ?>
            <tr>
                <td><?php echo $r->id ?></td>
                <td><?php echo $r->name ?></td>
                <td><?php echo $r->spend_time ?>s</td>
                <td><?php echo $r->task_rule ?></td>
                <td>
                    <a href="?page=taskmgr-direct-links&edit=<?php echo $r->id ?>" class="button">Edit</a>
                    <a href="?page=taskmgr-direct-links&delete=<?php echo $r->id ?>" class="button" onclick="return confirm('Delete?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>

    <hr>

    <!-- SHORTCODE INPUT + SAVE -->
    <h2>Finish Button Shortcode</h2>
    <form method="post">
        <input type="text" name="shortcode" class="regular-text" value="<?php echo esc_attr($sc); ?>" style="width:50%;">
        <button class="button button-secondary" name="tm_save_shortcode">Save Shortcode</button>
    </form>

</div>

<?php }

/* --------------------------------------------------------------------------
| SHORTCODE RUNNER: SHOW LINKS ONE BY ONE
--------------------------------------------------------------------------- */
add_shortcode('direct_links_runner', 'tm_direct_links_runner');
function tm_direct_links_runner() {
    global $wpdb;
    $table = $wpdb->prefix . "tm_direct_links";
    $settings = $wpdb->prefix . "tm_direct_links_settings";

    $links = $wpdb->get_results("SELECT * FROM $table ORDER BY id ASC");
    $finish_sc = $wpdb->get_var("SELECT shortcode FROM $settings WHERE id=1");

    ob_start(); ?>

    <div id="tm-runner-box"></div>

    <script>
    let links = <?php echo json_encode($links); ?>;
    let i = 0;

    function showNext() {
        if (i >= links.length) {
            document.getElementById('tm-runner-box').innerHTML = `<?php echo do_shortcode($finish_sc); ?>`;
            return;
        }

        let L = links[i];

        document.getElementById("tm-runner-box").innerHTML = `
            <h3>${L.name}</h3>
            <iframe src="${L.link}" style="width:100%;height:400px;"></iframe>
            <div>${L.code}</div>
            <p>Wait ${L.spend_time} seconds...</p>
        `;

        setTimeout(() => { i++; showNext(); }, L.spend_time * 1000);
    }

    showNext();
    </script>

    <?php
    return ob_get_clean();
}