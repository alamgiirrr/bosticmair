<?php
if (!defined('ABSPATH')) exit;

function taskmgr_links_page() {

    global $wpdb;
    $table = $wpdb->prefix . "taskmgr_list";

    /*
    |--------------------------------------------------------------------------
    | DELETE WITH NONCE
    |--------------------------------------------------------------------------
    */
    if (isset($_GET['delete'], $_GET['_wpnonce'])) {
        $id = intval($_GET['delete']);

        if (wp_verify_nonce($_GET['_wpnonce'], 'taskmgr_delete_' . $id)) {
            $wpdb->delete($table, ['id' => $id]);
            echo '<div class="updated"><p>Task Deleted Successfully.</p></div>';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | INSERT NEW TASK
    |--------------------------------------------------------------------------
    */
    if (isset($_POST['task_save']) && empty($_POST['edit_id'])) {

        $wpdb->insert($table, [
            'title'     => sanitize_text_field($_POST['title']),
            'link'      => esc_url($_POST['link']),
            'reading'   => intval($_POST['reading']),
            'rules'     => wp_kses_post($_POST['rules']),
            'shortcode' => preg_replace('/[^a-zA-Z0-9_\-\[\]\=\"\'\s]/', '', $_POST['shortcode']),
            'status'    => 1
        ]);

        echo '<div class="updated"><p>Task Saved Successfully.</p></div>';
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE TASK
    |--------------------------------------------------------------------------
    */
    if (isset($_POST['task_save']) && !empty($_POST['edit_id'])) {

        $id = intval($_POST['edit_id']);

        $wpdb->update($table, [
            'title'     => sanitize_text_field($_POST['title']),
            'link'      => esc_url($_POST['link']),
            'reading'   => intval($_POST['reading']),
            'rules'     => wp_kses_post($_POST['rules']),
            'shortcode' => preg_replace('/[^a-zA-Z0-9_\-\[\]\=\"\'\s]/', '', $_POST['shortcode'])
        ], ['id' => $id]);

        echo '<div class="updated"><p>Task Updated Successfully.</p></div>';
    }

    /*
    |--------------------------------------------------------------------------
    | EDIT MODE LOAD
    |--------------------------------------------------------------------------
    */
    $edit = false;
    if (isset($_GET['edit'])) {
        $edit = $wpdb->get_row("SELECT * FROM $table WHERE id=" . intval($_GET['edit']));
    }

    /*
    |--------------------------------------------------------------------------
    | PAGINATION
    |--------------------------------------------------------------------------
    */
    $per_page = 10;
    $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($page - 1) * $per_page;

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
    $tasks = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT $offset, $per_page");

    $total_pages = ceil($total / $per_page);
?>
<div class="wrap">

    <h1><?php echo $edit ? "Edit Task" : "Create Task"; ?></h1>

    <form method="post">
        <input type="hidden" name="edit_id" value="<?php echo $edit ? $edit->id : ""; ?>">

        <table class="form-table">
            <tr>
                <th>Task Title</th>
                <td><input type="text" name="title" class="regular-text"
                    value="<?php echo $edit ? esc_attr($edit->title) : ""; ?>" required></td>
            </tr>

            <tr>
                <th>Task Link</th>
                <td><input type="text" name="link" class="regular-text"
                    value="<?php echo $edit ? esc_attr($edit->link) : ""; ?>" required></td>
            </tr>

            <tr>
                <th>Reading Time</th>
                <td>
                    <input type="number" name="reading" style="width:100px;"
                    value="<?php echo $edit ? intval($edit->reading) : ""; ?>"> minutes
                </td>
            </tr>

            <tr>
                <th>Rules</th>
                <td><textarea name="rules" rows="4" class="large-text"><?php
                    echo $edit ? esc_textarea($edit->rules) : "";
                ?></textarea></td>
            </tr>

            <tr>
                <th>Shortcode</th>
                <td>
                    <input type="text" name="shortcode" class="regular-text"
                    placeholder="[button id='1']"
                    value="<?php echo $edit ? esc_attr($edit->shortcode) : ""; ?>" required>
                </td>
            </tr>
        </table>

        <button type="submit" name="task_save" class="button button-primary">
            <?php echo $edit ? "Update Task" : "Save Task"; ?>
        </button>
    </form>

    <hr><br>

    <h2>All Tasks</h2>

    <table class="widefat fixed striped">

        <thead>
            <tr>
                <th style="width:40px;">#</th>
                <th style="width:200px;">Title</th>
                <th style="width:200px;">Shortcode</th>
                <th style="width:120px;">Status</th>
                <th style="width:160px;">Actions</th>
            </tr>
        </thead>

        <tbody>
<?php foreach ($tasks as $i => $t): ?>
<tr>
    <td><?php echo $offset + $i + 1; ?></td>
    <td><?php echo esc_html($t->title); ?></td>

    <td><code><?php echo $t->shortcode; ?></code></td>

    <td>
        <span class="tm-toggle" data-id="<?php echo $t->id; ?>"
            style="
                cursor:pointer;
                padding:6px 14px;
                border-radius:20px;
                color:#fff;
                font-weight:600;
                background:<?php echo $t->status ? '#1fae04' : '#d40000'; ?>;
            ">
            <?php echo $t->status ? 'ON' : 'OFF'; ?>
        </span>
    </td>

    <td>
        <a class="button" href="?page=taskmgr-links&edit=<?php echo $t->id; ?>">Edit</a>

        <?php $nonce = wp_create_nonce('taskmgr_delete_' . $t->id); ?>
        <a class="button" style="color:red;"
            href="?page=taskmgr-links&delete=<?php echo $t->id; ?>&_wpnonce=<?php echo $nonce; ?>">
            Delete
        </a>
    </td>
</tr>
<?php endforeach; ?>
        </tbody>
    </table>

    <?php
    echo paginate_links([
        'current' => $page,
        'total'   => $total_pages,
        'format'  => '?paged=%#%'
    ]);
    ?>

</div>

<script>
jQuery(function($){
    $('.tm-toggle').on('click', function(){

        var span = $(this);
        var id = span.data('id');

        $.post(ajaxurl, {
            action: 'taskmgr_toggle_status',
            id: id,
            _ajax_nonce: '<?php echo wp_create_nonce("taskmgr_toggle_nonce"); ?>'
        }, function(res){

            if(res.success){

                let st = res.data.new_status;

                span.text(st ? 'ON' : 'OFF');
                span.css('background', st ? '#1fae04' : '#d40000');
            }
        });
    });
});
</script>

<?php
}

/*
|--------------------------------------------------------------------------
| FRONTEND: VIEW SPECIFIC TASK
|--------------------------------------------------------------------------
*/
add_shortcode('taskmgr_view', function($atts){
    global $wpdb;
    $table = $wpdb->prefix . "taskmgr_list";
    $id = intval($atts['id']);

    $task = $wpdb->get_row("SELECT shortcode FROM $table WHERE id=$id");

    if (!$task) return "Task Not Found";

    return do_shortcode($task->shortcode);
});

/*
|--------------------------------------------------------------------------
| FRONTEND COLORFUL UI (SHOW ALL)
|--------------------------------------------------------------------------
*/
add_shortcode('taskmgr_all', function(){
    global $wpdb;
    $table = $wpdb->prefix . "taskmgr_list";

    $tasks = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");

    if (!$tasks) return "<p>No tasks available.</p>";

    ob_start();
?>

<style>
.tm-box {
    padding: 22px; 
    border-radius: 16px;
    color: #fff;
    margin-bottom: 22px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.18);
}
.tm-grad-1 { background: linear-gradient(135deg, #ff7a7a, #ff375f); }
.tm-grad-2 { background: linear-gradient(135deg, #6a5cff, #8a2be2); }
.tm-grad-3 { background: linear-gradient(135deg, #00c6ff, #0072ff); }
.tm-grad-4 { background: linear-gradient(135deg, #ff9a3c, #ff4e00); }
.tm-grad-5 { background: linear-gradient(135deg, #34e89e, #0f3443); }
</style>

<div>
<?php $c = 1; foreach ($tasks as $t): ?>
    <div class="tm-box tm-grad-<?php echo $c; ?>">

        <h2><?php echo esc_html($t->title); ?></h2>

        <p><strong>Reading:</strong> <?php echo intval($t->reading); ?> min</p>

        <p><strong>Rules:</strong><br>
            <?php echo nl2br(esc_html($t->rules)); ?>
        </p>

        <p><strong>Link:</strong>
            <a href="<?php echo esc_url($t->link); ?>" style="color:#fff;text-decoration:underline;" target="_blank">
                Open
            </a>
        </p>

        <p><strong>Your Button:</strong><br>
            <?php echo do_shortcode($t->shortcode); ?>
        </p>

    </div>
<?php $c = ($c == 5) ? 1 : $c + 1; endforeach; ?>
</div>

<?php
return ob_get_clean();
});