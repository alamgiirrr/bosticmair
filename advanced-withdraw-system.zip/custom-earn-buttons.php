<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| SIMPLE CUSTOM EARN BUTTONS – EXTENDED + AUTO TABLE UPGRADE
|--------------------------------------------------------------------------
| Features:
| - Dynamic shortcode
| - Points reward
| - Daily limit
| - Interval cooldown
| - Status ON/OFF toggle
| - Reload-proof system
| - Frontend auto-disable
| - Admin CRUD + toggle
| - Table auto-create
| - Table auto-upgrade (missing columns auto add)
|--------------------------------------------------------------------------
*/

/* Include earn logs page */
require_once plugin_dir_path(__FILE__) . 'earn-logs.php';


/* ============================================================
   ACTIVATION HOOK – CREATE TABLE + AUTO UPDATE
============================================================ */
register_activation_hook(__FILE__, 'aws_earn_buttons_install');

function aws_earn_buttons_install() {
    global $wpdb;

    $buttons_table = $wpdb->prefix . "aws_earn_buttons";
    $logs_table    = $wpdb->prefix . "aws_earn_logs";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    /* -------- CREATE/UPDATE MAIN BUTTONS TABLE -------- */
    dbDelta("CREATE TABLE $buttons_table (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        shortcode VARCHAR(200),
        button_text VARCHAR(200),
        points INT,
        daily_limit INT DEFAULT 0,
        interval_minutes INT DEFAULT 0,
        status TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");

    /* -------- CREATE/UPDATE EARN LOGS TABLE -------- */
    dbDelta("CREATE TABLE $logs_table (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT,
        user_name VARCHAR(200),
        user_email VARCHAR(200),
        button_id BIGINT,
        button_name VARCHAR(200),
        points INT,
        ip VARCHAR(50),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");

    /* Run Auto Upgrade */
    aws_earn_buttons_upgrade();
}



/* ============================================================
   AUTO UPGRADE SYSTEM (Add Missing Columns Automatically)
============================================================ */
function aws_earn_buttons_upgrade() {
    global $wpdb;

    $buttons_table = $wpdb->prefix . "aws_earn_buttons";
    $logs_table    = $wpdb->prefix . "aws_earn_logs";

    /* ---------- CHECK BUTTONS TABLE COLUMNS ---------- */
    $columns = $wpdb->get_results("SHOW COLUMNS FROM $buttons_table", ARRAY_A);
    $existing = wp_list_pluck($columns, 'Field');

    if (!in_array('daily_limit', $existing)) {
        $wpdb->query("ALTER TABLE $buttons_table ADD daily_limit INT DEFAULT 0");
    }
    if (!in_array('interval_minutes', $existing)) {
        $wpdb->query("ALTER TABLE $buttons_table ADD interval_minutes INT DEFAULT 0");
    }
    if (!in_array('status', $existing)) {
        $wpdb->query("ALTER TABLE $buttons_table ADD status TINYINT DEFAULT 1");
    }

    /* ---------- CHECK LOG TABLE COLUMNS (FUTURE SAFE) ---------- */
    $log_cols = $wpdb->get_results("SHOW COLUMNS FROM $logs_table", ARRAY_A);
    $existing_logs = wp_list_pluck($log_cols, 'Field');

    $need_cols = [
        "user_id"     => "BIGINT",
        "user_name"   => "VARCHAR(200)",
        "user_email"  => "VARCHAR(200)",
        "button_id"   => "BIGINT",
        "button_name" => "VARCHAR(200)",
        "points"      => "INT",
        "ip"          => "VARCHAR(50)",
        "created_at"  => "DATETIME DEFAULT CURRENT_TIMESTAMP"
    ];

    foreach ($need_cols as $col => $type) {
        if (!in_array($col, $existing_logs)) {
            $wpdb->query("ALTER TABLE $logs_table ADD $col $type");
        }
    }
}




/* ============================================================
   MAIN PLUGIN CLASS
============================================================ */
class AWS_Custom_Earn_Buttons {

    public function __construct() {

        add_action('wp_head', function(){
            ?>
            <script>
                var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
            </script>
            <?php
        });

        add_action('admin_menu', [$this, 'admin_menu']);

        add_action('admin_post_aws_add_earn_button', [$this, 'save_button']);
        add_action('admin_post_aws_edit_earn_button', [$this, 'edit_button']);
        add_action('admin_post_aws_delete_earn_button', [$this, 'delete_button']);
        add_action('admin_post_aws_toggle_status', [$this, 'toggle_status']);

        add_action('init', [$this, 'register_dynamic_shortcodes']);

        add_action('wp_ajax_simple_dynamic_earn', [$this, 'process_earn']);
        add_action('wp_ajax_nopriv_simple_dynamic_earn', function(){
            wp_die("Login required");
        });
    }


    /* ============================================================
       SHORTCODES
    ============================================================ */
    public function register_dynamic_shortcodes() {
        global $wpdb;

        $table = $wpdb->prefix . "aws_earn_buttons";
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table)
            return;

        $rows = $wpdb->get_results("SELECT * FROM $table WHERE status=1");

        if (!$rows) return;

        foreach ($rows as $btn) {
            add_shortcode($btn->shortcode, function($atts) use ($btn) {
                return $this->render_earn_button(['id' => $btn->id]);
            });
        }
    }



    /* ============================================================
       ADMIN MENU
    ============================================================ */
    public function admin_menu() {
        add_menu_page(
            "Earn Buttons",
            "Earn Buttons",
            "manage_options",
            "aws-earn-buttons",
            [$this, "admin_page"],
            "dashicons-awards",
            55
        );

     add_submenu_page(
    'aws-earn-buttons',
    'Earn Logs',
    'Earn Logs',
    'manage_options',
    'aws-earn-logs',
    'aws_earn_logs_page'
);


    }



    /* ============================================================
       ADMIN PAGE (FULL UI)
    ============================================================ */
    public function admin_page() {
        global $wpdb;
        $table = $wpdb->prefix . "aws_earn_buttons";
        $rows  = $wpdb->get_results("SELECT * FROM $table");
        ?>

<style>
.aws-btn{
    padding:6px 12px;
    border-radius:6px;
    font-weight:600;
    text-decoration:none!important;
    color:#fff!important;
    display:inline-block;
    margin-right:6px;
}
.aws-btn-blue{ background:#0073aa; }
.aws-btn-red{ background:#d63638; }
.aws-btn-red:hover{ background:#b82b2d; }
.aws-btn-blue:hover{ background:#005c87; }
.aws-status-on{
    background:#28a745; color:#fff; padding:4px 10px; border-radius:5px;
}
.aws-status-off{
    background:#d63638; color:#fff; padding:4px 10px; border-radius:5px;
}
</style>

<div class="wrap">


<?php
/* ---------------- EDIT MODE ---------------- */
if (isset($_GET['edit'])) {

    $id  = intval($_GET['edit']);
    $row = $wpdb->get_row("SELECT * FROM $table WHERE id=$id");

    if ($row) { ?>
        <h2>Edit Earn Button</h2>

        <form method="POST" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="aws_edit_earn_button">
            <input type="hidden" name="id" value="<?php echo $row->id; ?>">

            <table class="form-table">
                <tr><th>Shortcode Name</th>
                    <td><input type="text" name="shortcode" value="<?php echo $row->shortcode; ?>" required></td>
                </tr>
                <tr><th>Button Text</th>
                    <td><input type="text" name="button_text" value="<?php echo $row->button_text; ?>" required></td>
                </tr>
                <tr><th>Points</th>
                    <td><input type="number" name="points" value="<?php echo $row->points; ?>" required></td>
                </tr>
                <tr><th>Daily Limit</th>
                    <td><input type="number" name="daily_limit" value="<?php echo $row->daily_limit; ?>"></td>
                </tr>
                <tr><th>Interval (Minutes)</th>
                    <td><input type="number" name="interval_minutes" value="<?php echo $row->interval_minutes; ?>"></td>
                </tr>
                <tr><th>Status</th>
                    <td>
                        <select name="status">
                            <option value="1" <?php selected($row->status,1); ?>>ON</option>
                            <option value="0" <?php selected($row->status,0); ?>>OFF</option>
                        </select>
                    </td>
                </tr>
            </table>

            <button class="button button-primary">Update</button>
        </form>

        <hr>
<?php }} ?>


<h2>Create Earn Button</h2>

<form method="POST" action="<?php echo admin_url('admin-post.php'); ?>">
    <input type="hidden" name="action" value="aws_add_earn_button">

    <table class="form-table">
        <tr><th>Shortcode Name</th>
            <td><input type="text" name="shortcode" required></td>
        </tr>
        <tr><th>Button Text</th>
            <td><input type="text" name="button_text" required></td>
        </tr>
        <tr><th>Points</th>
            <td><input type="number" name="points" required></td>
        </tr>
        <tr><th>Daily Limit</th>
            <td><input type="number" name="daily_limit"></td>
        </tr>
        <tr><th>Interval (Minutes)</th>
            <td><input type="number" name="interval_minutes"></td>
        </tr>
        <tr><th>Status</th>
            <td>
                <select name="status">
                    <option value="1">ON</option>
                    <option value="0">OFF</option>
                </select>
            </td>
        </tr>
    </table>

    <button class="button button-primary">Create</button>
</form>

<hr>

<h2>Earn Buttons</h2>

<table class="widefat striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Shortcode</th>
            <th>Text</th>
            <th>Points</th>
            <th>Daily Limit</th>
            <th>Interval</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>

    <tbody>
    <?php foreach ($rows as $r): ?>
        <tr>
            <td><?php echo $r->id; ?></td>
            <td>[<?php echo $r->shortcode; ?> id="<?php echo $r->id; ?>"]</td>
            <td><?php echo $r->button_text; ?></td>
            <td><?php echo $r->points; ?></td>
            <td><?php echo $r->daily_limit; ?></td>
            <td><?php echo $r->interval_minutes; ?> min</td>
            <td><?php echo $r->status ? '<span class="aws-status-on">ON</span>' : '<span class="aws-status-off">OFF</span>'; ?></td>

            <td>
                <a class="aws-btn aws-btn-blue" href="<?php echo admin_url('admin.php?page=aws-earn-buttons&edit='.$r->id); ?>">Edit</a>

                <a class="aws-btn aws-btn-red"
                   onclick="return confirm('Delete this button?');"
                   href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=aws_delete_earn_button&id='.$r->id),'aws_delete_'.$r->id); ?>">Delete</a>

                <a class="aws-btn" style="background:#ff9800;"
                   href="<?php echo admin_url('admin-post.php?action=aws_toggle_status&id='.$r->id); ?>">Toggle</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</div>

<?php
    }



    /* ============================================================
       CRUD
    ============================================================ */
    public function save_button() {
        global $wpdb;
        $table = $wpdb->prefix . "aws_earn_buttons";

        $wpdb->insert($table, [
            "shortcode"        => sanitize_text_field($_POST['shortcode']),
            "button_text"      => sanitize_text_field($_POST['button_text']),
            "points"           => intval($_POST['points']),
            "daily_limit"      => intval($_POST['daily_limit']),
            "interval_minutes" => intval($_POST['interval_minutes']),
            "status"           => intval($_POST['status'])
        ]);

        wp_redirect(admin_url("admin.php?page=aws-earn-buttons"));
        exit;
    }


    public function edit_button() {
        global $wpdb;
        $table = $wpdb->prefix . "aws_earn_buttons";

        $wpdb->update(
            $table,
            [
                "shortcode"        => sanitize_text_field($_POST['shortcode']),
                "button_text"      => sanitize_text_field($_POST['button_text']),
                "points"           => intval($_POST['points']),
                "daily_limit"      => intval($_POST['daily_limit']),
                "interval_minutes" => intval($_POST['interval_minutes']),
                "status"           => intval($_POST['status'])
            ],
            ["id" => intval($_POST['id'])]
        );

        wp_redirect(admin_url("admin.php?page=aws-earn-buttons"));
        exit;
    }


    public function delete_button() {
        global $wpdb;

        $id = intval($_GET['id']);

        if (!wp_verify_nonce($_GET['_wpnonce'], 'aws_delete_'.$id))
            wp_die("Security error");

        $wpdb->delete($wpdb->prefix."aws_earn_buttons", ["id"=>$id]);

        wp_redirect(admin_url("admin.php?page=aws-earn-buttons"));
        exit;
    }



    /* ============================================================
       STATUS TOGGLE
    ============================================================ */
    public function toggle_status() {
        global $wpdb;

        $id = intval($_GET['id']);
        $table = $wpdb->prefix . "aws_earn_buttons";

        $row = $wpdb->get_row("SELECT status FROM $table WHERE id=$id");

        if ($row) {
            $new = $row->status ? 0 : 1;
            $wpdb->update($table, ["status" => $new], ["id" => $id]);
        }

        wp_redirect(admin_url("admin.php?page=aws-earn-buttons"));
        exit;
    }



    /* ============================================================
       EARN PROCESS
    ============================================================ */
    public function process_earn() {

        if (!is_user_logged_in()) wp_die("Login required");

        global $wpdb;

        $btn_id = intval($_POST['id']);
        $table = $wpdb->prefix . "aws_earn_buttons";
        $btn = $wpdb->get_row("SELECT * FROM $table WHERE id=$btn_id");

        if (!$btn) wp_die("Invalid button");

        if ($btn->status == 0) wp_die("This reward is disabled");

        $uid = get_current_user_id();
        $points = intval($btn->points);

        if ($points < 1) wp_die("Invalid points");

        /* ---------- DAILY LIMIT ---------- */
        $limit = intval($btn->daily_limit);

        $date_key  = "aws_click_date_$btn_id";
        $count_key = "aws_click_count_$btn_id";

        $today = date("Y-m-d");
        $saved_date  = get_user_meta($uid, $date_key, true);
        $saved_count = intval(get_user_meta($uid, $count_key, true));

        if ($saved_date !== $today) {
            update_user_meta($uid, $date_key, $today);
            update_user_meta($uid, $count_key, 0);
            $saved_count = 0;
        }

        if ($limit > 0 && $saved_count >= $limit)
            wp_die("Daily limit reached");

        /* ---------- INTERVAL COOLDOWN ---------- */
        $interval = intval($btn->interval_minutes);

        if ($interval > 0) {
            $last_click_key = "aws_last_click_$btn_id";
            $last_click = intval(get_user_meta($uid, $last_click_key, true));

            $now = time();

            if ($last_click > 0) {
                $next_allowed = $last_click + ($interval * 60);
                if ($now < $next_allowed) {
                    $wait = $next_allowed - $now;
                    $min = ceil($wait / 60);
                    wp_die("Wait $min minutes");
                }
            }
        }

        /* ---------- ADD BALANCE ---------- */
        $bal = (float) get_user_meta($uid, 'user_balance', true);
        update_user_meta($uid, 'user_balance', $bal + $points);

        /* --- SAVE LOG --- */
$wpdb->insert(
    $wpdb->prefix . "aws_earn_logs",
    [
        "user_id"     => $uid,
        "user_name"   => wp_get_current_user()->display_name,
        "user_email"  => wp_get_current_user()->user_email,
        "button_id"   => $btn_id,
        "button_name" => $btn->button_text,
        "points"      => $points,
        "ip"          => $_SERVER['REMOTE_ADDR'],
    ]
);


        /* ---------- UPDATE COUNTERS ---------- */
        update_user_meta($uid, $count_key, $saved_count + 1);

        if ($interval > 0)
            update_user_meta($uid, "aws_last_click_$btn_id", time());

        wp_die("ok");
    }



    /* ============================================================
       FRONTEND BUTTON OUTPUT
    ============================================================ */
    public function render_earn_button($atts) {

        if (!is_user_logged_in()) {
            return "<p>Please login to earn rewards.</p>";
        }

        global $wpdb;

        $id = intval($atts['id']);
        $row = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}aws_earn_buttons WHERE id=$id");

        if (!$row) return "Invalid Button";

        $uid = get_current_user_id();

        if ($row->status == 0)
            return "<button class='simple-earn-btn disabled' disabled>Disabled</button>";

        $today = date("Y-m-d");
        $date_key  = "aws_click_date_$id";
        $count_key = "aws_click_count_$id";
        $last_click_key = "aws_last_click_$id";

        $saved_date  = get_user_meta($uid, $date_key, true);
        $saved_count = intval(get_user_meta($uid, $count_key, true));
        $interval    = intval($row->interval_minutes);
        $limit       = intval($row->daily_limit);

        if ($saved_date !== $today) $saved_count = 0;

        $disable = false;
        $disable_msg = "";

        if ($limit > 0 && $saved_count >= $limit) {
            $disable = true;
            $disable_msg = "Daily limit reached";
        }

        if (!$disable && $interval > 0) {
            $last_click = intval(get_user_meta($uid, $last_click_key, true));
            if ($last_click) {
                $next_allowed = $last_click + ($interval * 60);
                if (time() < $next_allowed) {
                    $wait = $next_allowed - time();
                    $minutes = ceil($wait / 60);
                    $disable = true;
                    $disable_msg = "Wait $minutes min";
                }
            }
        }

        $btn_text = $disable ? $disable_msg : $row->button_text;

        ob_start(); ?>

<style>
.simple-earn-btn{
    background:#28a745; color:#fff;
    padding:12px 22px; border-radius:8px;
    font-weight:600; cursor:pointer;
    border:none; transition:.25s;
}
.simple-earn-btn:hover{
    background:#1f8c39;
}
.simple-earn-btn.disabled{
    background:#888!important;
    cursor:not-allowed!important;
}
</style>

<button class="simple-earn-btn <?php echo $disable ? 'disabled':''; ?>"
        data-id="<?php echo $row->id; ?>"
        <?php echo $disable ? 'disabled':''; ?>>
    <?php echo esc_html($btn_text); ?>
</button>

<script>
jQuery(document).on("click",".simple-earn-btn",function(){

    let btn = jQuery(this);
    if(btn.hasClass("disabled")) return;

    btn.text("Processing...");
    let id = btn.data("id");

    jQuery.post(ajaxurl,{
        action: "simple_dynamic_earn",
        id: id
    }, function(res){

        if(res === "ok"){
            btn.text("Success! Balance Added");
            btn.addClass("disabled").prop("disabled",true);
        } else {
            btn.text(res);
            btn.addClass("disabled").prop("disabled",true);
        }

    });
});
</script>

<?php
        return ob_get_clean();
    }

} // END CLASS


new AWS_Custom_Earn_Buttons();

?>
