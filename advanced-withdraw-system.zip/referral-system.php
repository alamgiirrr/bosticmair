<?php
if (!defined('ABSPATH')) exit;

/* ============================================================
   FORCE SESSION START
   ============================================================ */
add_action('init', function () {
    if (!session_id()) {
        session_start();
    }
}, 1);


/* ============================================================
   REFERRAL LOG TABLE CREATE
   ============================================================ */
add_action('init', function () {
    global $wpdb;

    $table = $wpdb->prefix . 'aws_ref_logs';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE $table (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            referrer_id BIGINT NOT NULL,
            referred_id BIGINT NOT NULL,
            bonus FLOAT NOT NULL,
            status VARCHAR(20) DEFAULT 'pending',
            ip_address VARCHAR(50),
            browser VARCHAR(100),
            device VARCHAR(100),
            created DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
    }

    if (get_option('aws_ref_bonus') === false) {
        update_option('aws_ref_bonus', 10);
    }
});


/* ============================================================
   AUTO FIX – ADD MISSING COLUMNS
   ============================================================ */
add_action('init', function () {
    global $wpdb;
    $table = $wpdb->prefix . 'aws_ref_logs';

    $cols = [
        'status'     => "ALTER TABLE $table ADD COLUMN status VARCHAR(20) DEFAULT 'pending'",
        'ip_address' => "ALTER TABLE $table ADD COLUMN ip_address VARCHAR(50)",
        'browser'    => "ALTER TABLE $table ADD COLUMN browser VARCHAR(100)",
        'device'     => "ALTER TABLE $table ADD COLUMN device VARCHAR(100)"
    ];

    foreach ($cols as $col => $sql) {
        if (!$wpdb->get_results("SHOW COLUMNS FROM $table LIKE '$col'")) {
            $wpdb->query($sql);
        }
    }
});


/* ============================================================
   REF LINK TRACKING
   ============================================================ */
add_action('template_redirect', function () {
    if (isset($_GET['ref']) && is_numeric($_GET['ref'])) {
        $_SESSION['aws_ref'] = intval($_GET['ref']);
        wp_redirect(site_url('/wp-login.php?action=register'));
        exit;
    }
});


/* ============================================================
   DEVICE / BROWSER / IP DETECT
   ============================================================ */
function aws_get_ip() {
    return $_SERVER['HTTP_CLIENT_IP']
        ?? $_SERVER['HTTP_X_FORWARDED_FOR']
        ?? $_SERVER['REMOTE_ADDR'];
}

function aws_get_browser() {
    $ua = $_SERVER['HTTP_USER_AGENT'];
    if (strpos($ua, 'Chrome') && !strpos($ua, 'Edge')) return 'Chrome';
    if (strpos($ua, 'Firefox')) return 'Firefox';
    if (strpos($ua, 'Safari') && !strpos($ua, 'Chrome')) return 'Safari';
    if (strpos($ua, 'Edge')) return 'Edge';
    if (strpos($ua, 'Opera') || strpos($ua, 'OPR')) return 'Opera';
    return 'Unknown';
}

function aws_get_device() {
    $ua = $_SERVER['HTTP_USER_AGENT'];
    if (preg_match('/android/i', $ua)) return 'Android';
    if (preg_match('/iphone|ipad|ipod/i', $ua)) return 'iOS';
    if (preg_match('/windows/i', $ua)) return 'Windows';
    if (preg_match('/mac/i', $ua)) return 'MacOS';
    if (preg_match('/linux/i', $ua)) return 'Linux';
    return 'Unknown';
}


/* ============================================================
   REGISTER FORM: EXTRA FIELDS
   ============================================================ */
add_action('register_form', function () { ?>
    <p>
        <label>Password<br/>
            <input type="password" name="password" />
        </label>
    </p>

    <p>
        <label>Referral Code (Optional)<br/>
            <input type="text" name="ref_code" />
        </label>
    </p>
<?php });


/* ============================================================
   VALIDATION
   ============================================================ */
add_filter('registration_errors', function ($errors) {

    if (empty($_POST['password'])) {
        $errors->add('password_error', 'Please enter a password.');
    }

    if (!empty($_POST['ref_code'])) {
        $code = sanitize_text_field($_POST['ref_code']);
        $user = get_user_by('login', $code) ?: get_user_by('id', $code);

        if (!$user) {
            $errors->add('ref_code_error', 'Invalid referral code.');
        }
    }

    return $errors;
}, 10, 3);


/* ============================================================
   AFTER USER REGISTER
   ============================================================ */
add_action('user_register', function ($new_uid) {

    global $wpdb;

    if (!empty($_POST['password'])) {
        wp_set_password($_POST['password'], $new_uid);
    }

    $referrer_id = null;

    if (!empty($_POST['ref_code'])) {
        $user = get_user_by('login', $_POST['ref_code']) ?: get_user_by('id', $_POST['ref_code']);
        if ($user) {
            $referrer_id = $user->ID;
        }
    }

    if (!$referrer_id && !empty($_SESSION['aws_ref'])) {
        $referrer_id = intval($_SESSION['aws_ref']);
    }

    if ($referrer_id == $new_uid || !$referrer_id) {
        unset($_SESSION['aws_ref']);
        return;
    }

    $bonus = (float) get_option('aws_ref_bonus', 10);

    $ip      = aws_get_ip();
    $browser = aws_get_browser();
    $device  = aws_get_device();

    /* === BLOCK SAME IP === */
    if ($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}aws_ref_logs WHERE ip_address=%s", $ip)) > 0) {

        $wpdb->insert(
            $wpdb->prefix . 'aws_ref_logs',
            [
                'referrer_id' => $referrer_id,
                'referred_id' => $new_uid,
                'bonus'       => 0,
                'status'      => 'blocked_ip',
                'ip_address'  => $ip,
                'browser'     => $browser,
                'device'      => $device
            ]
        );

        unset($_SESSION['aws_ref']);
        return;
    }

    /* === BLOCK SAME DEVICE === */
    if ($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}aws_ref_logs WHERE device=%s", $device)) > 0) {

        $wpdb->insert(
            $wpdb->prefix . 'aws_ref_logs',
            [
                'referrer_id' => $referrer_id,
                'referred_id' => $new_uid,
                'bonus'       => 0,
                'status'      => 'blocked_device',
                'ip_address'  => $ip,
                'browser'     => $browser,
                'device'      => $device
            ]
        );

        unset($_SESSION['aws_ref']);
        return;
    }

    /* === VALID INSERT === */
    $wpdb->insert(
        $wpdb->prefix . 'aws_ref_logs',
        [
            'referrer_id' => $referrer_id,
            'referred_id' => $new_uid,
            'bonus'       => $bonus,
            'status'      => 'pending',
            'ip_address'  => $ip,
            'browser'     => $browser,
            'device'      => $device
        ]
    );

    update_user_meta($new_uid, 'referred_by', $referrer_id);
    unset($_SESSION['aws_ref']);
});



/* ============================================================
   ADMIN MENU
   ============================================================ */
add_action('admin_menu', function () {

    add_submenu_page(
        'aws-withdraws',
        'Referral Settings',
        'Referral Settings',
        'manage_options',
        'aws-ref-settings',
        'aws_ref_settings_page'
    );

    add_submenu_page(
        'aws-withdraws',
        'Referral History',
        'Referral History',
        'manage_options',
        'aws-ref-history',
        'aws_ref_history_page'
    );
});


/* ============================================================
   ADMIN SETTINGS PAGE
   ============================================================ */
function aws_ref_settings_page() {

    if (isset($_POST['bonus'])) {
        update_option('aws_ref_bonus', floatval($_POST['bonus']));
        echo '<div class="updated"><p><strong>Referral Bonus Updated</strong></p></div>';
    }

    $bonus = get_option('aws_ref_bonus', 10);

    echo '<div class="wrap">
        <h2>Referral Settings</h2>
        <form method="post" style="max-width:400px;background:#fff;padding:20px;border-radius:8px;">
            <label>Referral Bonus Amount</label>
            <input type="number" name="bonus" value="'.$bonus.'" style="width:100%;margin-top:10px;">
            <button class="button button-primary" style="margin-top:15px;">Save</button>
        </form>
    </div>';
}


/* ============================================================
   ADMIN HISTORY PAGE
   ============================================================ */
function aws_ref_history_page() {
    global $wpdb;

    $table = $wpdb->prefix . 'aws_ref_logs';

    if (isset($_GET['approve'])) {
        $id  = intval($_GET['approve']);
        $row = $wpdb->get_row("SELECT * FROM $table WHERE id=$id");

        if ($row && $row->status == 'pending') {
            $bal = (float) get_user_meta($row->referrer_id, 'user_balance', true);
            update_user_meta($row->referrer_id, 'user_balance', $bal + $row->bonus);
            $wpdb->update($table, ['status' => 'approved'], ['id' => $id]);
            echo '<div class="updated"><p>Referral Approved</p></div>';
        }
    }

    if (isset($_GET['reject'])) {
        $id  = intval($_GET['reject']);
        $row = $wpdb->get_row("SELECT * FROM $table WHERE id=$id");

        if ($row && $row->status == 'pending') {
            $wpdb->update($table, ['status' => 'rejected'], ['id' => $id]);
            echo '<div class="updated"><p>Referral Rejected</p></div>';
        }
    }

    $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");

    echo '<div class="wrap"><h2>Referral History Log</h2>';

    if (!$rows) {
        echo '<p>No data found</p></div>';
        return;
    }

    echo '<table class="widefat striped">
        <thead>
            <tr>
                <th>Referrer</th>
                <th>Referred</th>
                <th>Bonus</th>
                <th>Status</th>
                <th>IP</th>
                <th>Browser</th>
                <th>Device</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead><tbody>';

    foreach ($rows as $r) {

        $ref = get_user_by('id', $r->referrer_id);
        $new = get_user_by('id', $r->referred_id);

        echo "<tr>
            <td>{$ref->user_login}</td>
            <td>{$new->user_login}</td>
            <td>{$r->bonus}</td>
            <td>{$r->status}</td>
            <td>{$r->ip_address}</td>
            <td>{$r->browser}</td>
            <td>{$r->device}</td>
            <td>{$r->created}</td>
            <td>";

        if ($r->status == 'pending') {
            echo "<a href='?page=aws-ref-history&approve={$r->id}' class='button button-primary'>Approve</a>
                  <a href='?page=aws-ref-history&reject={$r->id}' class='button'>Reject</a>";
        } else {
            echo "—";
        }

        echo "</td></tr>";
    }

    echo '</tbody></table></div>';
}



/* ============================================================
   FRONTEND SHORTCODE — FULL BOOTSTRAP MODERN UI
   ============================================================ */

function aws_referral_panel_shortcode_modern() {

    if (!is_user_logged_in()) {
        return "<div class='alert alert-warning text-center'>Please login first.</div>";
    }

    global $wpdb;

    $uid   = get_current_user_id();
    $table = $wpdb->prefix . 'aws_ref_logs';

    $ref_link = site_url('/?ref=' . $uid);
    $user     = wp_get_current_user();
    $ref_code = $user->user_login;

    $total_income = $wpdb->get_var(
        $wpdb->prepare("SELECT SUM(bonus) FROM $table WHERE referrer_id=%d AND status='approved'", $uid)
    );
    if (!$total_income) $total_income = 0;

    $rows = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table WHERE referrer_id=%d ORDER BY id DESC", $uid)
    );

    ob_start();
    ?>

    <!-- BOOTSTRAP LOAD -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .ref-card {
            border-radius: 12px;
            padding: 25px;
            color: #fff;
        }
        .ref-table th {
            background: #6610f2 !important;
            color: #fff;
            text-align: center;
        }
        .ref-table td {
            text-align: center;
            vertical-align: middle;
        }
    </style>

    <div class="container py-4">

        <h2 class="mb-4 text-center fw-bold">Referral Dashboard</h2>

        <div class="row g-4">

            <div class="col-md-4">
                <div class="ref-card" style="background:#0d6efd;">
                    <h5>Your Referral Link</h5>
                    <input type="text" id="refLink" value="<?php echo $ref_link; ?>" class="form-control mt-2" readonly>
                    <button class="btn btn-light btn-sm mt-2" onclick="copyLink('refLink')">Copy</button>
                </div>
            </div>

            <div class="col-md-4">
                <div class="ref-card" style="background:#6f42c1;">
                    <h5>Your Referral Code</h5>
                    <p class="fs-4 mt-2"><?php echo $ref_code; ?></p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="ref-card" style="background:#d63384;">
                    <h5>Total Referral Income</h5>
                    <p class="fs-4 mt-2"><?php echo $total_income; ?></p>
                </div>
            </div>

        </div>

        <h3 class="mt-5 fw-bold">Referred Users</h3>

        <?php if (!$rows) { ?>

            <div class="alert alert-info mt-3">No referred users yet.</div>

        <?php } else { ?>

            <table class="table table-bordered table-striped mt-3 ref-table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Bonus</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>

                <?php foreach ($rows as $r) {
                    $u = get_user_by('id', $r->referred_id);
                ?>
                    <tr>
                        <td><?php echo $u ? $u->user_login : 'Unknown'; ?></td>
                        <td><?php echo $r->bonus; ?></td>

                        <td>
                            <?php if ($r->status == 'approved') { ?>
                                <span class="badge bg-success">Approved</span>
                            <?php } elseif ($r->status == 'pending') { ?>
                                <span class="badge bg-warning text-dark">Pending</span>
                            <?php } elseif ($r->status == 'rejected') { ?>
                                <span class="badge bg-danger">Rejected</span>
                            <?php } else { ?>
                                <span class="badge bg-secondary"><?php echo $r->status; ?></span>
                            <?php } ?>
                        </td>

                        <td><?php echo $r->created; ?></td>
                    </tr>
                <?php } ?>

                </tbody>
            </table>

        <?php } ?>

    </div>

    <script>
        function copyLink(id) {
            var copyText = document.getElementById(id);
            copyText.select();
            document.execCommand("copy");
            alert("Copied!");
        }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('aws_referral_panel', 'aws_referral_panel_shortcode_modern');

