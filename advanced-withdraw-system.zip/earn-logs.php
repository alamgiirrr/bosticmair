<?php
if (!defined('ABSPATH')) exit;

function aws_earn_logs_page() {
    global $wpdb;
    $table = $wpdb->prefix . "aws_earn_logs";

    /* Delete single */
    if (isset($_GET['delete'])) {
        $id = intval($_GET['delete']);
        $wpdb->delete($table, ["id" => $id]);
        echo "<div class='updated'><p>Log deleted.</p></div>";
    }

    /* Bulk delete */
    if (isset($_POST['bulk_delete']) && !empty($_POST['ids'])) {
        foreach ($_POST['ids'] as $log_id) {
            $wpdb->delete($table, ["id" => intval($log_id)]);
        }
        echo "<div class='updated'><p>Selected logs deleted.</p></div>";
    }

    /* Pagination */
    $limit = 20;
    $page  = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
    $offset = ($page - 1) * $limit;

    $logs = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT $offset, $limit");
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");

    $total_pages = ceil($total / $limit);
?>
<div class="wrap">
<h2>Earn Logs</h2>

<form method="POST">
<table class="widefat striped">
<thead>
<tr>
    <th><input type="checkbox" id="checkAll"></th>
    <th>User ID</th>
    <th>Username</th>
    <th>Email</th>
    <th>Button ID</th>
    <th>Button Name</th>
    <th>Points</th>
    <th>IP</th>
    <th>Date/Time</th>
    <th>Action</th>
</tr>
</thead>

<tbody>
<?php foreach ($logs as $l): ?>
<tr>
    <td><input type="checkbox" name="ids[]" value="<?php echo $l->id; ?>"></td>
    <td><?php echo $l->user_id; ?></td>
    <td><?php echo $l->user_name; ?></td>
    <td><?php echo $l->user_email; ?></td>
    <td><?php echo $l->button_id; ?></td>
    <td><?php echo $l->button_name; ?></td>
    <td><?php echo $l->points; ?></td>
    <td><?php echo $l->ip; ?></td>
    <td><?php echo $l->created_at; ?></td>
    <td><a class="button button-small" href="?page=aws-earn-logs&delete=<?php echo $l->id; ?>">Delete</a></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<br>

<input type="submit" name="bulk_delete" class="button button-primary" value="Delete Selected">

</form>

<script>
document.getElementById("checkAll").addEventListener("change", function(){
    let c = document.querySelectorAll("input[type='checkbox'][name='ids[]']");
    for (let i of c) i.checked = this.checked;
});
</script>

<!-- PAGINATION -->
<div style="margin-top:20px;">
<?php
for ($i=1;$i<=$total_pages;$i++){
    echo "<a style='padding:6px 12px;margin-right:5px;border:1px solid #ccc;' 
           href='?page=aws-earn-logs&paged=$i'>$i</a>";
}
?>
</div>

</div>
<?php } ?>
