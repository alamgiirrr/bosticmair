<?php
/*
Plugin Name: Advanced Withdraw System
Version: 2.9 FINAL
*/

if (!defined('ABSPATH')) exit;

global $wpdb;
define('AWS_TABLE', $wpdb->prefix . 'aws_withdraws');
define('AWS_MIN', 100);

/* ================= Custom Earn Button ================= */
/* Load the extended earn button system */
require_once plugin_dir_path(__FILE__) . 'custom-earn-buttons.php';

/**
 * DO NOT call create_table() manually anymore.
 * Our new plugin already uses:
 * - register_activation_hook()
 * - dbDelta()
 * - auto-upgrade system
 *
 * So we simply call the installer:
 */

register_activation_hook(__FILE__, function () {
    if (function_exists('aws_earn_buttons_install')) {
        aws_earn_buttons_install();   // <-- This safely handles create + upgrade
    }
});




/* ================= ACTIVATION ================= */
register_activation_hook(__FILE__, function () {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta("CREATE TABLE " . AWS_TABLE . " (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT NOT NULL,
        method VARCHAR(50),
        account VARCHAR(100),
        amount FLOAT,
        status VARCHAR(20) DEFAULT 'pending',
        created DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    if (!get_page_by_path('withdraw')) {
        wp_insert_post([
            'post_title'   => 'Withdraw',
            'post_name'    => 'withdraw',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '[aws_withdraw_form][aws_withdraw_history]'
        ]);
    }
});

/* ================= BALANCE ================= */
function aws_balance($uid) {
    return (float) get_user_meta($uid, 'user_balance', true);
}

/* ================= ADMIN MENU ================= */
add_action('admin_menu', function () {
    add_menu_page(
        'Withdraw Requests',
        'Withdraws',
        'manage_options',
        'aws-withdraws',
        'aws_admin_page',
        'dashicons-money-alt',
        26
    );

    add_submenu_page(
        'aws-withdraws',
        'User Balances',
        'User Balance',
        'manage_options',
        'aws-balance',
        'aws_balance_page'
    );
});

/* ================= ADMIN PAGE ================= */
function aws_admin_page() {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT * FROM ".AWS_TABLE." WHERE status!='trash' ORDER BY id DESC");

echo '<div class="wrap"><h2>Withdraw Requests</h2>

<style>

table.widefat th,
table.widefat td{
    padding:10px 12px !important;
}

table.widefat th{
    font-weight:600;
}

.aws-badge{
    padding:6px 16px;
    border-radius:999px;
    font-weight:600;
    font-size:13px;
    display:inline-block;
}
.aws-badge.approved{
    background:#E6F9EE;
    color:#0F8A4B;
}
.aws-badge.rejected{
    background:#FDECEC;
    color:#C62828;
}
.aws-badge.pending{
    background:#FFF8D8;
    color:#B26A00;
}

.aws-act{
    background:#1e3a8a !important;
    border-color:#1e3a8a !important;
    color:#fff !important;
    border-radius:6px !important;
}

.aws-act[data-t="approved"]{
    background:#16a34a !important;
    border-color:#16a34a !important;
}

.aws-act[data-t="rejected"]{
    background:#dc2626 !important;
    border-color:#dc2626 !important;
}

.aws-act[data-t="trash"]{
    background:#111 !important;
    border-color:#111 !important;
}

.aws-act.applied-approve,
.aws-act.applied-approve:disabled{
    background:#E6F9EE !important;
    border-color:#A5E6C1 !important;
    color:#0F8A4B !important;
    opacity:1 !important;
}

.aws-act.applied-reject,
.aws-act.applied-reject:disabled{
    background:#FDECEC !important;
    border-color:#F5B5B5 !important;
    color:#C62828 !important;
    opacity:1 !important;
}

.aws-act:disabled{
    opacity:0.55;
    cursor:not-allowed;
}

</style>

<table class="widefat striped">
<thead>
<tr>
    <th>User ID</th>
    <th>Username</th>
    <th>Email</th>
    <th>Method</th>
    <th>Account</th>
    <th>Amount</th>
    <th>Status</th>
    <th>Date</th>
    <th>Action</th>
</tr>
</thead>
<tbody>';

foreach($rows as $r){

    $u = get_user_by('id', $r->user_id);
    if(!$u) continue;

    $approveClass = ($r->status=='approved') ? 'applied-approve' : '';
    $rejectClass  = ($r->status=='rejected') ? 'applied-reject' : '';

    $disabled = in_array($r->status,['approved','rejected']) ? 'disabled' : '';

    echo "<tr data-id='{$r->id}'>
        <td>{$u->ID}</td>
        <td>{$u->user_login}</td>
        <td>{$u->user_email}</td>
        <td>{$r->method}</td>
        <td>{$r->account}</td>
        <td>{$r->amount}</td>

        <td><span class='aws-badge {$r->status}'>".ucfirst($r->status)."</span></td>

        <td>".date('d M Y, h:i A', strtotime($r->created))."</td>

        <td>
            <button class='button aws-act $approveClass' data-t='approved' $disabled>Approve</button>
            <button class='button aws-act $rejectClass' data-t='rejected' $disabled>Reject</button>
            <button class='button aws-act' data-t='trash'>Delete</button>
        </td>
    </tr>";
}

echo '</tbody></table></div>';
?>

<script>
jQuery(document).on("click",".aws-act",function(){
    let btn = jQuery(this),
        tr  = btn.closest("tr");

    if(btn.prop("disabled")) return;

    jQuery.post(ajaxurl,{
        action:"aws_admin_action",
        id: tr.data("id"),
        type: btn.data("t")
    },function(res){

        if(res==="locked") return alert("Already finalized");

        if(btn.data("t")==="trash"){
            tr.fadeOut();
            return;
        }

        tr.find(".aws-badge")
            .attr("class","aws-badge "+btn.data("t"))
            .text(btn.data("t").charAt(0).toUpperCase()+btn.data("t").slice(1));

        tr.find(".aws-act").prop("disabled",true);

        if(btn.data("t")==="approved"){
            btn.addClass("applied-approve");
        }
        if(btn.data("t")==="rejected"){
            btn.addClass("applied-reject");
        }
    });
});
</script>

<?php }

/* ================= AJAX ================= */
add_action('wp_ajax_aws_admin_action', function(){
    global $wpdb;

    $id = intval($_POST['id']);
    $type = sanitize_text_field($_POST['type']);

    $row = $wpdb->get_row("SELECT * FROM ".AWS_TABLE." WHERE id=$id");
    if(!$row) wp_die("no-row");
    if(in_array($row->status,['approved','rejected'])) wp_die("locked");

    if($type=='rejected'){
        $bal = aws_balance($row->user_id);
        update_user_meta($row->user_id,'user_balance',$bal + $row->amount);
    }

    $wpdb->update(AWS_TABLE,['status'=>$type],['id'=>$id]);

    wp_die("ok");
});

/* ================= BALANCE PAGE ================= */
function aws_balance_page(){
    if(!current_user_can('manage_options')) return;

    if(isset($_POST['uid'])){
        $uid = intval($_POST['uid']);
        $amt = floatval($_POST['amt']);
        $bal = aws_balance($uid);

        update_user_meta($uid,'user_balance',
            $_POST['type']=='add' ? $bal+$amt : max(0,$bal-$amt)
        );
    }

    echo '<div class="wrap"><h2>User Balance</h2>
    <table class="widefat striped"><tr>
    <th>User ID</th><th>Username</th><th>Email</th><th>Balance</th><th>Action</th></tr>';

    foreach(get_users() as $u){
        echo "<tr>
        <td>{$u->ID}</td>
        <td>{$u->user_login}</td>
        <td>{$u->user_email}</td>
        <td>".aws_balance($u->ID)."</td>
        <td>
        <form method='post' style='display:flex;gap:6px'>
            <input type='hidden' name='uid' value='{$u->ID}'>
            <input name='amt' type='number' required>
            <select name='type'>
                <option value='add'>Add</option>
                <option value='remove'>Remove</option>
            </select>
            <button class='button'>Update</button>
        </form>
        </td></tr>";
    }
    echo '</table></div>';
}

/* ================= WITHDRAW FORM (FINAL UI FIXED) ================= */
add_shortcode('aws_withdraw_form', function(){
    if(!is_user_logged_in()) return '';
    if(!session_id()) session_start();

    $uid = get_current_user_id();
    $bal = aws_balance($uid);

ob_start(); ?>

<style>
.aws-box{
    max-width:700px;
    margin:40px auto;
    background:#fff;
    padding:40px 35px;
    border-radius:26px;
    box-shadow:0 8px 50px rgba(0,0,0,0.08);
    font-family:system-ui;
}

.aws-box h3{
    font-size:32px;
    font-weight:700;
    margin-bottom:25px;
    color:#111;
}

.aws-field{
    width:100%;
    margin-bottom:18px;
}

.aws-field select,
.aws-field input{
    width:100% !important;
    height:55px !important;
    padding:0 18px !important;
    font-size:16px !important;
    border:1px solid #d1d5db !important;
    border-radius:12px !important;
    background:#fff !important;
    outline:none !important;
    transition:.2s !important;
    box-sizing:border-box !important;
}

.aws-field select:focus,
.aws-field input:focus{
    border-color:#3b82f6 !important;
}

.aws-submit-btn{
    width:100%;
    height:55px;
    background:#1d6fbe;
    border:none;
    border-radius:12px;
    font-size:18px;
    font-weight:600;
    color:#fff;
    cursor:pointer;
    transition:.2s;
}

.aws-submit-btn:hover{
    background:#155b98;
}

.aws-msg{
    background:#f1f5f9;
    padding:10px 15px;
    border-radius:8px;
    margin-bottom:15px;
    border-left:4px solid #1d6fbe;
}
</style>

<div class="aws-box">

<h3>Withdraw (Min <?php echo AWS_MIN;?>)</h3>

<p><b>Balance:</b> <?php echo number_format($bal,2);?></p>

<?php if(!empty($_SESSION['msg'])){ echo "<div class='aws-msg'>{$_SESSION['msg']}</div>"; unset($_SESSION['msg']); } ?>

<?php if($bal >= AWS_MIN): ?>

<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
<?php wp_nonce_field('aws','n'); ?>
<input type="hidden" name="action" value="aws_submit">

<div class="aws-field">
    <select name="method" required>
        <option>bKash</option>
        <option>Nagad</option>
        <option>Rocket</option>
        <option>Mobile Recharge</option>
        <option>Binance UID</option>
    </select>
</div>

<div class="aws-field">
    <input name="account" placeholder="Number / UID" required>
</div>

<div class="aws-field">
    <input name="amount" type="number" placeholder="Amount" required>
</div>

<button class="aws-submit-btn">Submit</button>

</form>

<?php else: ?>
<p style="color:red;">Insufficient balance</p>
<?php endif; ?>

</div>

<?php return ob_get_clean();
});

/* ================= WITHDRAW HISTORY ================= */
add_shortcode('aws_withdraw_history', function(){
    if(!is_user_logged_in()) return '';
    global $wpdb;

    $uid = get_current_user_id();
    $rows = $wpdb->get_results("SELECT * FROM ".AWS_TABLE."
        WHERE user_id=$uid AND status!='trash' ORDER BY id DESC");

    if(!$rows) return '';

ob_start(); ?>

<style>
.aws-history-box{
    max-width:700px;
    margin:40px auto;
    background:#ffffff;
    padding:32px;
    border-radius:22px;
    box-shadow:0 10px 35px rgba(0,0,0,0.06);
    font-family:system-ui;
}

.aws-history-box h2{
    font-size:26px;
    font-weight:700;
    margin-bottom:20px;
    color:#111;
}

.aws-table{
    width:100%;
    border-collapse:collapse;
}

.aws-table th{
    text-align:left;
    padding:14px 10px;
    font-weight:600;
    font-size:16px;
    border-bottom:1px solid #e5e7eb;
    color:#333;
}

.aws-table td{
    padding:14px 10px;
    font-size:15px;
    color:#444;
    border-bottom:1px solid #f1f1f1;
}

.aws-badge{
    padding:6px 14px;
    border-radius:999px;
    font-size:13px;
    font-weight:600;
    display:inline-block;
}

.aws-badge.approved{ background:#E6F9EE; color:#0F8A4B; }
.aws-badge.rejected{ background:#FDECEC; color:#C62828; }
.aws-badge.pending{ background:#FFF8D8; color:#B26A00; }

.aws-table-wrapper{ overflow-x:auto; }
.aws-table th, .aws-table td{ white-space:nowrap; }
    
    
    
 @media (max-width:600px){

    .aws-history-box{
        padding:18px !important;
        border-radius:16px !important;
        margin:25px auto !important;
    }

    .aws-history-box h2{
        font-size:20px !important;
        margin-bottom:14px !important;
    }

    .aws-table th{
        font-size:12px !important;
        padding:8px 4px !important;
    }

    .aws-table td{
        font-size:12px !important;
        padding:8px 4px !important;
    }

    .aws-badge{
        font-size:10px !important;
        padding:4px 8px !important;
    }

    .aws-table-wrapper{
        overflow-x:auto;
    }
}
   
    
</style>

<div class="aws-history-box">
<h2>Withdraw History</h2>

<div class="aws-table-wrapper">
<table class="aws-table">
<thead>
<tr>
    <th>Method</th>
    <th>Wallet</th>
    <th>Amount</th>
    <th>Status</th>
    <th>Date</th>
</tr>
</thead>

<tbody>
<?php foreach($rows as $r){ ?>
<tr>
    <td><?php echo esc_html($r->method); ?></td>
    <td><?php echo esc_html($r->account); ?></td>
    <td><?php echo number_format($r->amount,2); ?></td>
    <td><span class="aws-badge <?php echo $r->status; ?>"><?php echo ucfirst($r->status); ?></span></td>
    <td><?php echo date('d M Y, h:i A', strtotime($r->created)); ?></td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
</div>

<?php return ob_get_clean();
});

/* ================= SUBMIT HANDLER ================= */
add_action('admin_post_nopriv_aws_submit', 'aws_submit_handler');
add_action('admin_post_aws_submit', 'aws_submit_handler');

function aws_submit_handler() {

    if(!wp_verify_nonce($_POST['n'], 'aws')) wp_die('Security failed');

    if(!session_id()) session_start();

    $uid = get_current_user_id();
    $amt = floatval($_POST['amount']);
    $bal = aws_balance($uid);

    if ($amt < AWS_MIN || $amt > $bal) {
        $_SESSION['msg'] = 'Invalid withdraw amount.';
    } else {
        update_user_meta($uid,'user_balance',$bal - $amt);

        global $wpdb;
        $wpdb->insert(AWS_TABLE, [
            'user_id' => $uid,
            'method'  => sanitize_text_field($_POST['method']),
            'account' => sanitize_text_field($_POST['account']),
            'amount'  => $amt
        ]);

        $_SESSION['msg'] = 'Your withdrawal request is pending.';
    }

    wp_safe_redirect(wp_get_referer());
    exit;
}

require_once __DIR__ . '/referral-system.php';

?>

