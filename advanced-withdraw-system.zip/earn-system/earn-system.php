<?php
if (!defined('ABSPATH')) exit;

/* ============================================================
   EARN BUTTON RENDER
   ============================================================ */
function aws_render_earn_button($atts){
    if(!is_user_logged_in()) return "<p>Please login to earn points.</p>";

    $point = intval($atts['p']);
    if($point < 1 || $point > 10) return '';

    ob_start(); ?>

    <button class="aws-earn-btn" data-point="<?php echo $point; ?>">
        Earn <?php echo $point; ?> Point
    </button>

    <style>
        .aws-earn-btn{
            padding:12px 22px;
            background:#1d6fbe;
            color:#fff;
            border:none;
            border-radius:8px;
            cursor:pointer;
            font-size:16px;
            font-weight:600;
            transition:.2s;
        }
        .aws-earn-btn:hover{ background:#155b98; }
    </style>

    <script>
    jQuery(document).ready(function($){

        $(document).on("click",".aws-earn-btn",function(){

            let btn = $(this);
            let p   = btn.data("point");

            if(btn.data("cooldown")) return;

            btn.text("Processing...");

            $.post(ajaxurl,{
                action:"aws_earn_points",
                p:p
            },function(res){

                if(res === "ok"){
                    btn.text("Earned +" + p + " Points");
                    btn.prop("disabled", true);
                } else {
                    btn.text(res);
                }

                let cd = 5;
                btn.data("cooldown", true);

                let int = setInterval(function(){
                    cd--;
                    btn.text("Wait "+cd+"s");
                    if(cd <= 0){
                        clearInterval(int);
                        btn.text("Earn "+p+" Point");
                        btn.data("cooldown", false);
                    }
                },1000);

            });

        });

    });
    </script>

    <?php
    return ob_get_clean();
}

/* Register 10 shortcodes: [earn1] ... [earn10] */
for($i=1;$i<=10;$i++){
    add_shortcode("earn$i", function() use ($i){
        return aws_render_earn_button(['p'=>$i]);
    });
}


/* ============================================================
   AJAX HANDLER: ADD POINTS + LIMIT + IP PROTECTION + COOLDOWN
   ============================================================ */
add_action('wp_ajax_aws_earn_points', 'aws_add_points');
add_action('wp_ajax_nopriv_aws_earn_points', function(){
    wp_die("Login required");
});

function aws_add_points(){
    if(!is_user_logged_in()) wp_die("Login required");

    global $wpdb;
    $table = $wpdb->prefix . "aws_earn_history";

    $uid = get_current_user_id();
    $p   = intval($_POST['p']);
    $ip  = $_SERVER['REMOTE_ADDR'];

    if($p < 1 || $p > 10) wp_die("Invalid");

    // Cooldown (server side)
    $last = get_user_meta($uid, 'aws_last_earn', true);
    if($last && time() - $last < 5){
        wp_die("Slow down...");
    }
    update_user_meta($uid, 'aws_last_earn', time());

    // Daily limit per button
    $today = date("Y-m-d");
    $limit = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(*) FROM $table 
        WHERE user_id=%d AND points=%d AND DATE(created)=%s
    ", $uid, $p, $today));

    if($limit > 0){
        wp_die("You already earned this today");
    }

    // IP Protection
    $ip_count = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(*) FROM $table 
        WHERE ip=%s AND DATE(created)=%s
    ", $ip, $today));

    if($ip_count >= 5){
        wp_die("IP limit reached");
    }

    // Add points
    $bal = (float) get_user_meta($uid, 'user_balance', true);
    update_user_meta($uid, 'user_balance', $bal + $p);

    // Insert earn history
    $wpdb->insert($table, [
        'user_id' => $uid,
        'points'  => $p,
        'ip'      => $ip
    ]);

    wp_die("ok");
}


/* ============================================================
   FRONTEND SHORTCODE: [earn_history]
   ============================================================ */
add_shortcode('earn_history', function(){
    if(!is_user_logged_in()) return '';

    global $wpdb;
    $table = $wpdb->prefix . "aws_earn_history";
    $uid = get_current_user_id();

    $rows = $wpdb->get_results("
        SELECT * FROM $table 
        WHERE user_id=$uid 
        ORDER BY id DESC
    ");

    if(!$rows) return "<p>No earn history found.</p>";

    ob_start(); ?>

    <style>
    .earn-box{
        max-width:700px;
        margin:30px auto;
        background:#fff;
        padding:25px;
        border-radius:18px;
        box-shadow:0 6px 25px rgba(0,0,0,0.08);
        font-family:system-ui;
    }
    .earn-box h2{
        font-size:24px;
        font-weight:700;
        margin-bottom:15px;
    }
    .earn-table{
        width:100%;
        border-collapse:collapse;
    }
    .earn-table th, .earn-table td{
        padding:12px 10px;
        border-bottom:1px solid #e5e7eb;
        font-size:15px;
    }
    </style>

    <div class="earn-box">
    <h2>Your Earn History</h2>
    <table class="earn-table">
        <tr><th>Points</th><th>IP</th><th>Date</th></tr>
        <?php foreach($rows as $r){ ?>
        <tr>
            <td><?php echo $r->points; ?></td>
            <td><?php echo $r->ip; ?></td>
            <td><?php echo date('d M Y, h:i A', strtotime($r->created)); ?></td>
        </tr>
        <?php } ?>
    </table>
    </div>

    <?php return ob_get_clean();
});


/* ============================================================
   ADMIN MENU CALLBACK (Earn History Page)
   ============================================================ */
function aws_admin_earn_history_page(){
    global $wpdb;
    $table = $wpdb->prefix . "aws_earn_history";

    $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 500");

    echo '<div class="wrap"><h2>Earn History (Last 500)</h2>';

    echo '<table class="widefat striped" style="margin-top:20px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Points</th>
                <th>IP</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>';

    foreach($rows as $r){
        $u = get_user_by('id', $r->user_id);
        echo "<tr>
            <td>{$r->id}</td>
            <td>{$u->user_login} ({$u->user_email})</td>
            <td>{$r->points}</td>
            <td>{$r->ip}</td>
            <td>".date('d M Y, h:i A', strtotime($r->created))."</td>
        </tr>";
    }

    echo '</tbody></table></div>';
}
