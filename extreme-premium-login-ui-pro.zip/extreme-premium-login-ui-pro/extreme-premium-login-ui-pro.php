<?php
/*
Plugin Name: Extreme Premium Login UI PRO
Description: Extreme premium animated login UI with glassmorphism form and admin settings.
Version: 3.8
Author: Custom AI Builder
*/

if (!defined('ABSPATH')) exit;

/* ---------------------------
   Admin Menu
---------------------------- */
add_action('admin_menu', function () {
    add_menu_page(
        'Login UI PRO',
        'Login UI PRO',
        'manage_options',
        'login-ui-pro',
        'login_ui_pro_settings_page',
        'dashicons-admin-customizer'
    );
});

/* ---------------------------
   Register Settings
---------------------------- */
add_action('admin_init', function () {
    register_setting('login_ui_pro_group', 'login_ui_pro_logo');

    register_setting('login_ui_pro_group', 'login_ui_bg_c1');
    register_setting('login_ui_pro_group', 'login_ui_bg_c2');
    register_setting('login_ui_pro_group', 'login_ui_bg_c3');
    register_setting('login_ui_pro_group', 'login_ui_bg_c4');
});

/* ---------------------------
   Admin Settings Page
---------------------------- */
function login_ui_pro_settings_page() { ?>
    <div class="wrap">
        <h2>Extreme Premium Login UI PRO Settings</h2>

        <form method="post" action="options.php">
            <?php settings_fields('login_ui_pro_group'); ?>
            <?php do_settings_sections('login_ui_pro_group'); ?>

            <table class="form-table">

                <tr>
                    <th>Logo URL</th>
                    <td><input type="text" name="login_ui_pro_logo"
                        value="<?php echo esc_attr(get_option('login_ui_pro_logo')); ?>"
                        style="width:400px;"></td>
                </tr>

                <tr><th colspan="2"><h3>Background Gradient Colors</h3></th></tr>

                <tr><th>Color 1</th>
                    <td><input type="color" name="login_ui_bg_c1"
                        value="<?php echo esc_attr(get_option('login_ui_bg_c1', '#4f46e5')); ?>"></td>
                </tr>

                <tr><th>Color 2</th>
                    <td><input type="color" name="login_ui_bg_c2"
                        value="<?php echo esc_attr(get_option('login_ui_bg_c2', '#9333ea')); ?>"></td>
                </tr>

                <tr><th>Color 3</th>
                    <td><input type="color" name="login_ui_bg_c3"
                        value="<?php echo esc_attr(get_option('login_ui_bg_c3', '#0ea5e9')); ?>"></td>
                </tr>

                <tr><th>Color 4</th>
                    <td><input type="color" name="login_ui_bg_c4"
                        value="<?php echo esc_attr(get_option('login_ui_bg_c4', '#14b8a6')); ?>"></td>
                </tr>

            </table>

            <?php submit_button(); ?>
        </form>
    </div>
<?php }

/* ---------------------------
   Premium Login/Register UI
---------------------------- */
add_action('login_enqueue_scripts', function () {

    $logo = esc_url(get_option('login_ui_pro_logo', ''));

    $c1 = get_option('login_ui_bg_c1', '#4f46e5');
    $c2 = get_option('login_ui_bg_c2', '#9333ea');
    $c3 = get_option('login_ui_bg_c3', '#0ea5e9');
    $c4 = get_option('login_ui_bg_c4', '#14b8a6');
?>
<style>
    body.login {
        height:100vh;
        margin:0;
        font-family:"Poppins",sans-serif;
        background: linear-gradient(-45deg, <?php echo "$c1, $c2, $c3, $c4"; ?>);
        background-size:400% 400%;
        animation: premiumBG 14s ease infinite;
        display:flex; justify-content:center; align-items:center;
    }
    @keyframes premiumBG {
        0%{background-position:0% 50%;}
        50%{background-position:100% 50%;}
        100%{background-position:0% 50%;}
    }

    #login {
        width:410px;
        padding:40px 40px;
        background: rgba(255,255,255,0.12);
        backdrop-filter: blur(20px);
        border-radius:22px;
        border:1px solid rgba(255,255,255,0.25);
        box-shadow:0 25px 50px rgba(0,0,0,0.35);
    }

    /* REMOVE DEFAULT REGISTER TITLE (100% accurate) */
    body.login-action-register .message.register {
        display:none !important;
    }
    body.login-action-register #login h1 + p {
        display:none !important;
    }

    /* LOGO */
    #login h1 a {
        <?php if ($logo) { ?>
        background-image:url('<?php echo $logo; ?>');
        width:160px; height:65px;
        background-size:contain;
        background-repeat:no-repeat;
        <?php } else { ?>
        display:none;
        <?php } ?>
    }

    /* FORM GLASS BACKGROUND */
    #login form {
        background: rgba(255,255,255,0.10);
        padding:25px;
        border-radius:16px;
        border:1px solid rgba(255,255,255,0.25);
        backdrop-filter: blur(15px);
        color:#fff !important;
    }

    /* INPUT LABELS + LINKS */
    #login form label,
    #login p,
    #login #nav a,
    #login #backtoblog a {
        color:#fff !important;
    }

    /* CUSTOM ERROR BOX */
    .login #login_error,
    .login .message.error,
    .login .message {
        background:#e11d48 !important;
        border:1px solid #ffffff !important;
        color:#fff !important;
        padding:14px !important;
        border-radius:10px !important;
        box-shadow:0 0 15px rgba(0,0,0,0.3) !important;
    }

    /* INPUT FIELDS */
    #login form .input {
        width:100%;
        padding:14px;
        font-size:15px;
        color:#fff;
        background:rgba(255,255,255,0.20);
        border:1px solid rgba(255,255,255,0.45);
        border-radius:12px;
        margin-top:6px;
    }
    #login form .input::placeholder { color:#e5e7eb; }

    #login form .input:focus {
        border-color:#fff;
        box-shadow:0 0 10px rgba(255,255,255,0.5);
    }

    /* BUTTON */
    .wp-core-ui .button-primary {
        width:100%;
        background:linear-gradient(135deg,#2563eb,#4f46e5);
        border:none;
        padding:14px;
        font-size:17px;
        border-radius:12px;
        color:#fff;
        box-shadow:0 6px 18px rgba(0,0,0,0.35);
        transition:.2s;
    }
    .wp-core-ui .button-primary:hover {
        transform: translateY(-2px);
        box-shadow:0 10px 25px rgba(0,0,0,0.40);
    }
</style>
<?php
});

/* ---------------------------
   ANDROID + IOS ADDRESS BAR COLOR
---------------------------- */
add_action('login_head', function () {
    $c1 = get_option('login_ui_bg_c1', '#4f46e5');
    echo '<meta name="theme-color" content="'.$c1.'">';
    echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">';
});
?>