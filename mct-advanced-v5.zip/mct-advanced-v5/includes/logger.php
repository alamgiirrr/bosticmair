<?php
if (!defined('ABSPATH')) exit;

add_action('init',function(){
    global $wpdb;
    $t=$wpdb->prefix.'mcta_logs';
    if($wpdb->get_var("SHOW TABLES LIKE '$t'")!=$t){
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE $t (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT,
            ip VARCHAR(100),
            country VARCHAR(100),
            city VARCHAR(100),
            isp VARCHAR(200),
            mobile_network VARCHAR(10),
            connection_type VARCHAR(20),
            is_vpn VARCHAR(10),
            browser VARCHAR(200),
            device VARCHAR(200),
            fingerprint VARCHAR(200),
            last_active DATETIME,
            created_at DATETIME
        );");
    }
});
?>
