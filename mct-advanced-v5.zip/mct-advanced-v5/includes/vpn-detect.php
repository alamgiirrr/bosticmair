<?php
if (!defined('ABSPATH')) exit;

function mcta_vpn_check($isp,$proxy,$hosting){
    $dc=['digitalocean','ovh','hetzner','contabo','aws','google','linode','vultr','m247','seflow','leaseweb'];
    foreach($dc as $x){
        if(strpos($isp,$x)!==false) return 'yes';
    }
    if($proxy) return 'yes';
    if($hosting) return 'yes';
    return 'no';
}

add_action('wp_ajax_mcta_delete', function(){
    global $wpdb;
    $t=$wpdb->prefix.'mcta_logs';
    $wpdb->delete($t,['id'=>intval($_POST['id'])]);
    wp_send_json(['ok'=>1]);
});

add_action('wp_ajax_mcta_bulk_delete', function(){
    global $wpdb;
    $t=$wpdb->prefix.'mcta_logs';
    foreach($_POST['ids'] as $id){
        $wpdb->delete($t,['id'=>intval($id)]);
    }
    wp_send_json(['ok'=>1]);
});
?>
