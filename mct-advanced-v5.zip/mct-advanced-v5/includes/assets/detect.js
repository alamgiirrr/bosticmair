document.addEventListener('DOMContentLoaded',()=>{
    let conn=navigator.connection?navigator.connection.effectiveType:'unknown';
    let browser=navigator.userAgent;
    let device=/mobile/i.test(browser)?'mobile':'desktop';
    let finger=btoa(browser+navigator.platform+screen.width+screen.height);

    fetch(mcta_ajax.ajax_url,{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
            action:'mcta_log',
            conn,browser,device,finger
        })
    });
});
