<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu',function(){
    add_menu_page('Realtime Monitor','Realtime Monitor','manage_options','mcta-rt','mcta_rt_page');
});

function mcta_rt_page(){
    global $wpdb;
    $rows=$wpdb->get_results("SELECT * FROM {$wpdb->prefix}mcta_logs ORDER BY last_active DESC LIMIT 200");

    echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">';
    echo '<div class="container mt-4">
        <h2>Realtime User Monitor</h2>

        <table class="table table-striped table-hover table-bordered">
        <thead class="table-dark"><tr>
            <th>User</th><th>IP</th><th>Country</th><th>ISP</th><th>Conn</th><th>VPN</th><th>Device</th><th>Fingerprint</th>
        </tr></thead><tbody>';

    foreach($rows as $r){
        $username=$r->user_id? get_userdata($r->user_id)->user_login: "Guest";
        $cls=$r->is_vpn=='yes'?'table-danger':'';
        $short=substr($r->fingerprint,0,20).'...';

        echo "<tr class='$cls'>
            <td>$username</td>
            <td>$r->ip</td>
            <td>$r->country</td>
            <td>$r->isp</td>
            <td>$r->connection_type</td>
            <td>$r->is_vpn</td>
            <td>$r->device</td>
            <td><span title='$r->fingerprint'>$short</span></td>
        </tr>";
    }

    echo "</tbody></table></div>";
}
?>
