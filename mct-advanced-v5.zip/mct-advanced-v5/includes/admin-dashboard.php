<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu',function(){
    add_menu_page('Logs History','Logs History','manage_options','mcta-logs','mcta_logs_page');
});

function mcta_logs_page(){
    global $wpdb;
    $t=$wpdb->prefix.'mcta_logs';

    $search="";
    if(isset($_GET['s'])) $search=sanitize_text_field($_GET['s']);

    $query="SELECT * FROM $t WHERE 
        ip LIKE '%$search%' OR 
        country LIKE '%$search%' OR 
        user_id IN (SELECT ID FROM {$wpdb->users} WHERE user_login LIKE '%$search%')
        ORDER BY id DESC LIMIT 500";

    $rows=$wpdb->get_results($query);

    echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">';
    echo '<div class="container mt-4">
        <h2>Logs History</h2>

        <form method="get" class="mb-3">
            <input type="hidden" name="page" value="mcta-logs"/>
            <input class="form-control" style="max-width:300px" name="s" placeholder="Search IP, Country, Username"/>
        </form>

        <button id="bulkdel" class="btn btn-danger mb-3">Bulk Delete</button>

        <table class="table table-striped table-hover table-bordered">
        <thead class="table-dark"><tr>
            <th><input type="checkbox" id="all"></th>
            <th>ID</th><th>User</th><th>IP</th><th>Country</th><th>ISP</th><th>VPN</th><th>Device</th><th>Date</th><th>Action</th>
        </tr></thead><tbody>';

    foreach($rows as $r){
        $username=$r->user_id? get_userdata($r->user_id)->user_login : "Guest";
        $cls=$r->is_vpn=='yes'?'table-danger':'';

        echo "<tr class='$cls'>
            <td><input type='checkbox' class='itm' value='$r->id'></td>
            <td>$r->id</td>
            <td>$username</td>
            <td>$r->ip</td>
            <td>$r->country</td>
            <td>$r->isp</td>
            <td>$r->is_vpn</td>
            <td>$r->device</td>
            <td>$r->created_at</td>
            <td><button class='btn btn-danger del' data-id='$r->id'>Delete</button></td>
        </tr>";
    }

    echo "</tbody></table></div>";

    echo "<script src='https://code.jquery.com/jquery-3.6.0.min.js'></script>
    <script>
    jQuery(function($){
        $('#all').on('click',()=>$('.itm').prop('checked',$('#all').is(':checked')));

        $('.del').on('click',function(){
            $.post(ajaxurl,{action:'mcta_delete',id:$(this).data('id')},()=>location.reload());
        });

        $('#bulkdel').on('click',function(){
            let ids=[];
            $('.itm:checked').each(function(){ ids.push($(this).val()); });
            $.post(ajaxurl,{action:'mcta_bulk_delete',ids:ids},()=>location.reload());
        });
    });
    </script>";
}
?>
