<?php
if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_mcta_log','mcta_log');
add_action('wp_ajax_mcta_log','mcta_log');

function mcta_log(){
    $d=file_get_contents("http://ip-api.com/json/".$_SERVER['REMOTE_ADDR']);
    $j=json_decode($d,true);
    global $wpdb;
    $wpdb->insert($wpdb->prefix.'mcta_logs',[
        'user_id'=>get_current_user_id(),
        'ip'=>$_SERVER['REMOTE_ADDR'],
        'country'=>$j['country']??'',
        'city'=>$j['city']??'',
        'isp'=>$j['isp']??'',
        'mobile_network'=>($j['mobile']??false)?'yes':'no',
        'connection_type'=>sanitize_text_field($_POST['conn']),
        'is_vpn'=>mcta_vpn_check(strtolower($j['isp']??''),$j['proxy']??false,$j['hosting']??false),
        'browser'=>sanitize_text_field($_POST['browser']),
        'device'=>sanitize_text_field($_POST['device']),
        'fingerprint'=>sanitize_text_field($_POST['finger']),
        'last_active'=>current_time('mysql'),
        'created_at'=>current_time('mysql')
    ]);
    wp_send_json(['ok'=>1]);
}
?>
