<?php
/**
 * Plugin Name: My Connection Tracker Advanced v5
 * Description: Delete Fix + Bulk Delete Fix + Search Filter + Bootstrap UI + VPN Detect.
 */
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__).'includes/tracker.php';
require_once plugin_dir_path(__FILE__).'includes/logger.php';
require_once plugin_dir_path(__FILE__).'includes/admin-dashboard.php';
require_once plugin_dir_path(__FILE__).'includes/realtime-monitor.php';
require_once plugin_dir_path(__FILE__).'includes/vpn-detect.php';

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('mcta-detect', plugin_dir_url(__FILE__).'includes/assets/detect.js',[],false,true);
    wp_localize_script('mcta-detect','mcta_ajax',['ajax_url'=>admin_url('admin-ajax.php')]);
});
?>
