
<?php
/*
Plugin Name: Registration Ultimate Security
Version: 4.0
*/
if (!defined('ABSPATH')) exit;

$incs=[
 'activator','device','fingerprint','vpn','blocker','admin','ajax','cleanup','geoip'
];
foreach($incs as $f){ require_once __DIR__.'/includes/'.$f.'.php'; }

register_activation_hook(__FILE__,'asrf_activate');
