// ===================================================
// ASRF Fingerprint System (Client-side SHA256 Version)
// ===================================================

// SHA256 hashing function (Browser-native Crypto API)
async function asrf_sha256(str) {
    const enc = new TextEncoder().encode(str);
    const buf = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(buf))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");
}


// ---------------------------------------------------
// Collect Strong Fingerprint
// ---------------------------------------------------
async function asrf_collectFingerprint() {
    let canvasFP = "";
    let webglFP = "";
    let audioFP = "";

    // -----------------------
    // Canvas Fingerprint
    // -----------------------
    try {
        let canvas = document.createElement("canvas");
        let ctx = canvas.getContext("2d");
        ctx.textBaseline = "top";
        ctx.font = "16px Arial";
        ctx.fillText("ASRF-FP", 2, 2);

        // shorten for stability
        canvasFP = canvas.toDataURL().substring(0, 50);
    } catch (e) {
        canvasFP = "canvas-error";
    }


    // -----------------------
    // WebGL Fingerprint
    // -----------------------
    try {
        let gl = document.createElement("canvas").getContext("webgl");

        if (gl) {
            webglFP =
                (gl.getParameter(gl.RENDERER) || "") +
                (gl.getParameter(gl.VENDOR) || "");
        } else {
            webglFP = "webgl-unsupported";
        }
    } catch (e) {
        webglFP = "webgl-error";
    }


    // -----------------------
    // Audio Fingerprint
    // -----------------------
    try {
        let AC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
        let audioCtx = new AC(1, 5000, 44100);
        let osc = audioCtx.createOscillator();
        let analyser = audioCtx.createAnalyser();

        osc.connect(analyser);
        analyser.connect(audioCtx.destination);
        osc.start(0);

        let buf = await audioCtx.startRendering();
        audioFP = buf.getChannelData(0).slice(0, 10).toString();
    } catch (e) {
        audioFP = "audio-error";
    }


    // -----------------------
    // Combine All Fingerprint Data (Raw)
    // -----------------------
    let rawFP = [
        navigator.userAgent,
        screen.width + "x" + screen.height,
        Intl.DateTimeFormat().resolvedOptions().timeZone || "",
        canvasFP,
        webglFP,
        audioFP
    ].join("|");


    // -----------------------
    // Hash with SHA256 (Client-side)
    // -----------------------
    let finalHash = await asrf_sha256(rawFP);

    return finalHash;
}



// ===================================================
// Attach FP to registration form + Save via AJAX
// ===================================================
document.addEventListener("DOMContentLoaded", () => {
    let form = document.querySelector("form");
    if (!form) return;

    asrf_collectFingerprint().then(finalHash => {

        // Add fingerprint as hidden form field
        let i = document.createElement("input");
        i.type = "hidden";
        i.name = "asrf_fp";
        i.value = finalHash;
        form.appendChild(i);

        // AJAX (optional) to store fp before submit
        if (typeof asrf_fp_ajax !== "undefined") {
            fetch(asrf_fp_ajax, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "action=asrf_fp_save&asrf_fp=" + encodeURIComponent(finalHash)
            });
        }

    });
});
