<?php

/**
 * ASRF GeoIP Lookup (3-level fallback, super reliable)
 * Returns country name
 */

function asrf_get_country($ip = null) {

    if (!$ip) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    }

    if (!$ip) {
        return 'Unknown';
    }


    // ----------------------------------------------
    // 1) ip-api.com  (Fast + Free + High accuracy)
    // ----------------------------------------------
    $url1 = "http://ip-api.com/json/{$ip}?fields=status,country";

    $resp1 = @file_get_contents($url1);

    if ($resp1) {
        $data = json_decode($resp1, true);

        if (!empty($data['status']) && $data['status'] === 'success') {
            if (!empty($data['country'])) {
                return $data['country'];
            }
        }
    }


    // ----------------------------------------------
    // 2) ipinfo.io (Backup)
    // ----------------------------------------------
    $url2 = "https://ipinfo.io/{$ip}/json";
    $resp2 = @file_get_contents($url2);

    if ($resp2) {
        $data = json_decode($resp2, true);

        if (!empty($data['country'])) {
            return $data['country']; // Country code (BD, US etc.)
        }
    }


    // ----------------------------------------------
    // 3) geoplugin.net (Last fallback)
    // ----------------------------------------------
    $url3 = "http://www.geoplugin.net/json.gp?ip={$ip}";
    $resp3 = @file_get_contents($url3);

    if ($resp3) {
        $data = json_decode($resp3, true);

        if (!empty($data['geoplugin_countryName'])) {
            return $data['geoplugin_countryName'];
        }
    }


    // ----------------------------------------------
    // If all fail → Unknown
    // ----------------------------------------------
    return 'Unknown';
}

?>
