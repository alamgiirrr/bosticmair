
<?php
add_action('admin_menu', function(){
 add_menu_page('Registration Logs','Registration Logs','manage_options','asrf', 'asrf_logs_page');
});

function asrf_logs_page(){
 echo '<h1>ASRF Ultimate Logs</h1>';
 echo '<input type="text" id="asrf-search" placeholder="Search Email / IP / Hash">
       <button id="asrf-btn">Search</button>';
 echo '<div id="asrf-table"></div>';
 echo "<script>
 jQuery('#asrf-btn').click(function(){
   let q=jQuery('#asrf-search').val();
   jQuery('#asrf-table').load(ajaxurl+'?action=asrf_load&q='+q);
 });
 jQuery('#asrf-table').load(ajaxurl+'?action=asrf_load');
 </script>";
}

add_action('wp_ajax_asrf_load', function(){
 global $wpdb;
 $t=$wpdb->prefix.'asrf_reg_logs';
 $q=isset($_GET['q'])? sanitize_text_field($_GET['q']):'';

 if($q){
   $rows=$wpdb->get_results($wpdb->prepare(
     "SELECT * FROM $t WHERE email LIKE %s OR ip LIKE %s OR device_hash LIKE %s ORDER BY id DESC",
     "%$q%","%$q%","%$q%"
   ));
 } else {
   $rows=$wpdb->get_results("SELECT * FROM $t ORDER BY id DESC LIMIT 500");
 }

 echo "<table class='widefat'>
 <tr><th><input type='checkbox' id='asrf-all'></th>
 <th>ID</th><th>Email</th><th>IP</th><th>Country</th>
 <th>Device</th><th>FP</th><th>Reason</th></tr>";

 foreach($rows as $r){
   echo "<tr>
   <td><input type='checkbox' class='asrf-check' value='$r->id'></td>
   <td>$r->id</td>
   <td>$r->email</td>
   <td>$r->ip</td>
   <td>$r->country</td>
   <td>$r->device_hash</td>
   <td>$r->fingerprint_hash</td>
   <td>$r->reason</td>
   </tr>";
 }

 echo "</table>
 <button id='asrf-del'>Delete Selected</button>
 <script>
 jQuery('#asrf-all').on('change',function(){
    jQuery('.asrf-check').prop('checked',this.checked);
 });
 jQuery('#asrf-del').click(function(){
    let ids=[];
    jQuery('.asrf-check:checked').each(function(){ids.push(jQuery(this).val());});
    jQuery.post(ajaxurl,{action:'asrf_bulk_del',ids:ids},()=>location.reload());
 });
 </script>";
});
