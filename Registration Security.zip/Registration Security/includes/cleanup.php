
<?php
add_action('asrf_clean','asrf_cleaner');
function asrf_cleaner(){
 global $wpdb;
 $t=$wpdb->prefix.'asrf_reg_logs';
 $wpdb->query("DELETE FROM $t WHERE created_at < NOW() - INTERVAL 30 DAY");
}
if(!wp_next_scheduled('asrf_clean')){
 wp_schedule_event(time(),'daily','asrf_clean');
}
