
<?php
function asrf_activate(){
 global $wpdb;
 $t=$wpdb->prefix.'asrf_reg_logs';
 $wpdb->query("CREATE TABLE IF NOT EXISTS $t (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 status VARCHAR(20),
 email VARCHAR(190),
 ip VARCHAR(50),
 country VARCHAR(100),
 device_hash VARCHAR(200),
 fingerprint_hash VARCHAR(200),
 browser VARCHAR(200),
 reason TEXT,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
}
