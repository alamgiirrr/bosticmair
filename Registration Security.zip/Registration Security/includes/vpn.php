<?php
function asrf_is_vpn() {

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';

    if (!$ip) return false;

    // ---------------------------------------------------
    // 1. Local / Private IP → Never VPN
    // ---------------------------------------------------
    if (preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1]))/', $ip)) {
        return false;
    }

    // ---------------------------------------------------
    // 2. Proxy Headers (Only strong indicators)
    // ---------------------------------------------------
    $proxy_headers = [
        'HTTP_VIA',
        'HTTP_PROXY_CONNECTION',
        'HTTP_X_FORWARDED'
    ];

    foreach ($proxy_headers as $h) {
        if (!empty($_SERVER[$h])) {
            // These headers are used mostly by transparent proxies/VPN
            return true;
        }
    }

    // ---------------------------------------------------
    // 3. X-Forwarded-For check (Safe handling)
    // ---------------------------------------------------
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {

        $xff = $_SERVER['HTTP_X_FORWARDED_FOR'];

        // multiple IP = proxy chain
        if (strpos($xff, ',') !== false) {
            return true;
        }

        // if XFF is public IP AND different from real → definite proxy
        if (filter_var($xff, FILTER_VALIDATE_IP) && $xff !== $ip) {
            return true;
        }
    }

    // ---------------------------------------------------
    // 4. Cloud Provider IP Detection (High accuracy)
    // ---------------------------------------------------
    $cloud_patterns = [
        'amazonaws',
        'google',
        'google cloud',
        'cloudflare',
        'digitalocean',
        'vultr',
        'linode',
        'azure',
        'gcore',
        'ovh',
        'netlify'
    ];

    $hostname = @gethostbyaddr($ip);

    if ($hostname && $hostname !== $ip) {
        foreach ($cloud_patterns as $c) {
            if (stripos($hostname, $c) !== false) {
                return true; // Cloud IP = 100% VPN/proxy hosting
            }
        }
    }

    // ---------------------------------------------------
    // 5. TOR exit node detection
    // ---------------------------------------------------
    if (preg_match('/\.tor-exit\./i', $hostname)) {
        return true;
    }

    // ---------------------------------------------------
    // Result: No VPN detected
    // ---------------------------------------------------
    return false;
}
?>
