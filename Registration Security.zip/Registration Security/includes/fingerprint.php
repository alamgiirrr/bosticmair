<?php

// =========================================================
//  ASRF FINGERPRINT — FULL UPDATED VERSION (NO-FP FIXED)
// =========================================================


/**
 * Force-load fingerprint.js on login & register pages
 */
add_action('login_enqueue_scripts', function() {

    // Load JS file
    wp_enqueue_script(
        'asrf-fingerprint',
        plugin_dir_url(__FILE__) . '../assets/js/fingerprint.js',
        [],
        '1.0',
        true
    );

    // Pass AJAX URL to JS
    ?>
    <script>
        var asrf_fp_ajax = "<?php echo admin_url('admin-ajax.php'); ?>";
    </script>
    <?php
});



/**
 * Generate fingerprint hash from POST data
 * Accepts both: fp AND asrf_fp
 */
function asrf_fingerprint_hash() {

    // Accept multiple parameter names
    if (isset($_POST['asrf_fp'])) {
        $raw = $_POST['asrf_fp'];

    } elseif (isset($_POST['fp'])) {
        $raw = $_POST['fp'];

    } elseif (!empty($_COOKIE['asrf_fp_temp'])) {
        // Fallback from JS cookie (most reliable)
        $raw = $_COOKIE['asrf_fp_temp'];

    } else {
        return 'no-fp';
    }

    // Clean fingerprint
    $clean = sanitize_text_field($raw);

    if (empty($clean)) {
        return 'no-fp';
    }

    // Return final hash
    return hash('sha256', $clean);
}



/**
 * AJAX endpoint — Save fingerprint via JS
 */
add_action('wp_ajax_nopriv_asrf_fp_save', 'asrf_fp_save');
add_action('wp_ajax_asrf_fp_save', 'asrf_fp_save');

function asrf_fp_save() {

    // Accept both parameter names
    if (isset($_POST['asrf_fp'])) {
        $raw = $_POST['asrf_fp'];

    } elseif (isset($_POST['fp'])) {
        $raw = $_POST['fp'];

    } else {
        wp_send_json_error('Missing fingerprint');
    }

    $clean = sanitize_text_field($raw);

    if (empty($clean)) {
        wp_send_json_error('Fingerprint empty');
    }

    // Store temporarily (used during registration)
    setcookie('asrf_fp_temp', $clean, time() + 300, '/', '', false, false);

    wp_send_json_success('Fingerprint saved');
}



/**
 * Get saved fingerprint (backup function)
 */
function asrf_get_saved_fingerprint() {

    if (!empty($_COOKIE['asrf_fp_temp'])) {
        $clean = sanitize_text_field($_COOKIE['asrf_fp_temp']);
        return hash('sha256', $clean);
    }

    return 'no-fp';
}

?>
