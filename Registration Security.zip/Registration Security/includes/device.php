
<?php
function asrf_device_hash(){
 $data = $_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR'];
 if(isset($_COOKIE['asrf_uid'])) $data .= $_COOKIE['asrf_uid'];
 return hash('sha256', $data);
}
