<?php

// Ensure cookie
add_action('init', function () {
    if (!isset($_COOKIE['asrf_uid'])) {
        setcookie('asrf_uid', bin2hex(random_bytes(32)), time() + 365 * DAY_IN_SECONDS, '/');
    }
});


// 🔒 PRE-REGISTRATION BLOCK (FULLY UPDATED)
add_filter('registration_errors', function ($errors, $sanitized_user_login, $user_email) {

    global $wpdb;
    $table = $wpdb->prefix . 'asrf_reg_logs';

    $device_hash = asrf_device_hash();
    $fingerprint = asrf_fingerprint_hash();
    $ip = $_SERVER['REMOTE_ADDR'];
    $ua = $_SERVER['HTTP_USER_AGENT'];
    $vpn = asrf_is_vpn();

    $reason = 'OK';


    // ---------------------------------------------------------
    // 1. CHECK: Multiple accounts from SAME DEVICE or SAME FP
    // ---------------------------------------------------------
    $exists_device = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE device_hash = %s OR fingerprint_hash = %s",
        $device_hash,
        $fingerprint
    ));

    if ($exists_device > 0) {
        $reason = 'MULTI-ACCOUNT DETECTED';
        $errors->add('asrf_multi', 'Registration blocked: Multiple accounts detected.');
    }


    // ---------------------------------------------------------
    // 2. CHECK: MULTIPLE ACCOUNTS FROM SAME IP
    // ---------------------------------------------------------
    $exists_ip = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE ip = %s",
        $ip
    ));

    if ($exists_ip > 0) {
        $reason = 'IP-MULTI-ACCOUNT BLOCKED';
        $errors->add('asrf_ip_multi', 'Registration blocked: Multiple accounts from same IP.');
    }


    // ---------------------------------------------------------
    // 3. CHECK: VPN / PROXY
    // ---------------------------------------------------------
    if ($vpn) {
        $reason = 'VPN BLOCKED';
        $errors->add('asrf_vpn', 'Registration blocked: VPN / Proxy detected.');
    }


    // ---------------------------------------------------------
    // 4. LOG ATTEMPT (SUCCESS / FAILED)
    // ---------------------------------------------------------
    $wpdb->insert($table, [
        'status'           => $errors->has_errors() ? 'failed' : 'success',
        'email'            => $user_email,
        'ip'               => $ip,
        'country'          => asrf_get_country($ip),
        'browser'          => $ua,
        'device_hash'      => $device_hash,
        'fingerprint_hash' => $fingerprint,
        'reason'           => $reason
    ]);


    return $errors;

}, 10, 3);

?>
