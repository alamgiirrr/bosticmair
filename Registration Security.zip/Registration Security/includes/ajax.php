
<?php
add_action('wp_ajax_asrf_bulk_del', function(){
 global $wpdb;
 $t=$wpdb->prefix.'asrf_reg_logs';
 $ids=$_POST['ids'];
 if(is_array($ids)){
   foreach($ids as $id){
     $wpdb->delete($t,['id'=>$id]);
   }
 }
 wp_die();
});
