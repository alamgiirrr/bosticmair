<?php
/*
Plugin Name: WP Ad Anti-Fraud Enterprise PRO
Description: Enterprise Fingerprint Engine + AI Fraud Prevention
Version: 3.0
Author: AI Builder
*/

if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| Load Core Modules
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/core/fingerprint-engine.php";
require_once __DIR__ . "/core/behavior-engine.php";
require_once __DIR__ . "/core/vpn-detection.php";
require_once __DIR__ . "/core/geo-velocity.php";
require_once __DIR__ . "/core/traps.php";
require_once __DIR__ . "/core/auto-ban.php";
require_once __DIR__ . "/core/waf.php";
require_once __DIR__ . "/core/session-guard.php";



/*
|--------------------------------------------------------------------------
| Admin Menu
|--------------------------------------------------------------------------
*/
add_action('admin_menu', function () {
    add_menu_page(
        'AntiFraud',
        'AntiFraud',
        'manage_options',
        'af-dashboard',
        function () {
            include __DIR__ . '/admin/dashboard.php';
        }
    );
});






// =====================================
// AJAX: Clear Logs (ALWAYS LOADED)
// =====================================
add_action('wp_ajax_wpaf_clear_logs', 'wpaf_handle_clear_logs');

function wpaf_handle_clear_logs() {

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $type = sanitize_text_field($_POST['type'] ?? '');

    $map = [
        'autoban' => 'wpaf_auto_ban_logs',
        'vpn'     => 'wpaf_vpn_logs',
        'geo'     => 'wpaf_geo_logs',
        'session' => 'wpaf_session_logs',
        'trap'    => 'wpaf_trap_logs',
    ];

    if (!isset($map[$type])) {
        wp_send_json_error('Invalid type');
    }

    $key = $map[$type];

    delete_option($key);
    add_option($key, []);

    wp_send_json_success('Logs permanently deleted');
}










/*
|--------------------------------------------------------------------------
| Enqueue Advanced Fingerprint JS
|--------------------------------------------------------------------------
*/
   
 add_action('wp_enqueue_scripts', function () {

    $base = plugin_dir_url(__FILE__) . "js/";

    wp_enqueue_script('wpaf-fp', $base . "fp-advanced.js", [], time(), true);
    wp_enqueue_script('wpaf-behavior', $base . "behavior.js", [], time(), true);
    wp_enqueue_script('wpaf-honeypot', $base . "honeypot.js", [], time(), true);      
  
    
});
?>