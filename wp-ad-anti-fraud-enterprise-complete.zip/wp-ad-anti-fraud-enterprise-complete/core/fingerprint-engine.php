<?php

if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| REGISTER REST ROUTE
|--------------------------------------------------------------------------
*/
add_action('rest_api_init', function () {
    register_rest_route('wpaf-enterprise/v1', '/save-fp', [
        'methods'  => 'POST',
        'callback' => 'wpaf_enterprise_save_fingerprint',
        'permission_callback' => '__return_true'
    ]);
});

/*
|--------------------------------------------------------------------------
| SAVE FINGERPRINT
|--------------------------------------------------------------------------
*/
function wpaf_enterprise_save_fingerprint($req)
{
    $fp = sanitize_text_field($req->get_param('fp'));
    $entropy = sanitize_text_field($req->get_param('entropy'));
    $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
    $ua = sanitize_text_field($_SERVER['HTTP_USER_AGENT']);
    $user = get_current_user_id();

    if (!$fp || !$user) {
        return ['status' => 'error', 'msg' => 'Invalid data'];
    }

    update_user_meta($user, 'wpaf_fp', $fp);
    update_user_meta($user, 'wpaf_entropy', $entropy);
    update_user_meta($user, 'wpaf_fp_ip', $ip);
    update_user_meta($user, 'wpaf_fp_ua', $ua);
    update_user_meta($user, 'wpaf_fp_time', time());

    wpaf_enterprise_add_log($user, "Fingerprint updated");

    return ['status' => 'success'];
}

/*
|--------------------------------------------------------------------------
| ADD LOG
|--------------------------------------------------------------------------
*/
function wpaf_enterprise_add_log($user, $msg)
{
    $logs = get_option('wpaf_enterprise_logs', []);
    $logs[] = [
        'user' => $user,
        'msg'  => $msg,
        'time' => current_time('mysql'),

    ];
    update_option('wpaf_enterprise_logs', $logs);
}

?>
