<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| GET LOCATION FROM IP (FREE API)
|--------------------------------------------------------------------------
|
| এটি ip-api.com ব্যবহার করছে (free, fast, no key required)।
| চাইলে premium API সংযোগ করতে পারো।
|
*/
function wpaf_geo_from_ip($ip)
{
    $url = "http://ip-api.com/json/" . $ip . "?fields=status,message,country,countryCode,lat,lon,city";

    $response = wp_remote_get($url, ['timeout' => 6]);

    if (is_wp_error($response)) return false;

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (!$data || $data['status'] !== 'success') return false;

    return [
        "lat"     => $data['lat'],
        "lon"     => $data['lon'],
        "country" => $data['country'],
        "city"    => $data['city']
    ];
}

/*
|--------------------------------------------------------------------------
| DISTANCE BETWEEN 2 GEO POINTS (KM)
|--------------------------------------------------------------------------
*/
function wpaf_geo_distance_km($lat1, $lon1, $lat2, $lon2)
{
    $earth = 6371; // KM

    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);

    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

    return $earth * $c;
}

/*
|--------------------------------------------------------------------------
| GEO VELOCITY CHECK ON LOGIN
|--------------------------------------------------------------------------
*/
add_action("wp_login", function ($username, $user) {

    $ip  = $_SERVER['REMOTE_ADDR'];
    $geo = wpaf_geo_from_ip($ip);

    if (!$geo) return;

    $last_geo  = get_user_meta($user->ID, "wpaf_last_geo", true);
    $last_time = intval(get_user_meta($user->ID, "wpaf_last_geo_time", true));

    // প্রথমবার লগইন হলে baseline সেট করো
    if (!$last_geo) {
        update_user_meta($user->ID, "wpaf_last_geo", $geo);
        update_user_meta($user->ID, "wpaf_last_geo_time", time());
        return;
    }

    // Distance calculate
    $distance = wpaf_geo_distance_km(
        $last_geo['lat'], $last_geo['lon'],
        $geo['lat'], $geo['lon']
    );

    // Time difference in hours
    $hours = (time() - $last_time) / 3600;

    // Prevent division by zero
    if ($hours <= 0) $hours = 0.01;

    // Velocity (km/hour)
    $speed = $distance / $hours;

    // Save new geo
    update_user_meta($user->ID, "wpaf_last_geo", $geo);
    update_user_meta($user->ID, "wpaf_last_geo_time", time());

    // Log
    wpaf_geo_log($user->ID, "Login from {$geo['country']} - Speed={$speed} km/h");

    /*
    |--------------------------------------------------------------------------
    | AUTO-BAN / AUTO-FLAG RULES
    |--------------------------------------------------------------------------
    | Human possible speed:
    | - < 900 km/h = Possible (Airplane)
    | - > 900 km/h = Impossible
    |--------------------------------------------------------------------------
    */

    if ($speed > 1000) {
        update_user_meta($user->ID, "wpaf_banned", 1);
        wpaf_geo_log($user->ID, "AUTO-BANNED (Impossible travel detected: {$speed} km/h)");
    }
    elseif ($speed > 600) {
        update_user_meta($user->ID, "wpaf_flagged", 1);
        wpaf_geo_log($user->ID, "FLAGGED (Suspicious travel velocity: {$speed} km/h)");
    }

}, 10, 2);

/*
|--------------------------------------------------------------------------
| GEO LOG STORAGE
|--------------------------------------------------------------------------
*/
function wpaf_geo_log($user, $msg)
{
    $log = get_option("wpaf_geo_logs", []);

    $log[] = [
        "user" => $user,
        "msg"  => $msg,
        "time" => current_time('mysql')
    ];

    update_option("wpaf_geo_logs", $log);
}
?>
