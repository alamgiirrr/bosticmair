<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| CONFIG — SET YOUR VPNAPI.IO KEY
|--------------------------------------------------------------------------
*/
define("WPAF_VPNAPI_KEY", "9961388710c34855bf2fc9f76965d4a7"); 
// তোমার vpnapi.io API KEY এখানে যোগ করবে

/*
|--------------------------------------------------------------------------
| CHECK VPN STATUS FOR USER
|--------------------------------------------------------------------------
*/
function wpaf_is_vpn_ip($ip)
{
    if (!WPAF_VPNAPI_KEY) return false;

    $url = "https://vpnapi.io/api/{$ip}?key=" . WPAF_VPNAPI_KEY;

    $response = wp_remote_get($url, ['timeout' => 8]);

    if (is_wp_error($response)) return false;

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (!$data || !isset($data['security'])) return false;

    return [
        "vpn"         => $data['security']['vpn'] ?? false,
        "proxy"       => $data['security']['proxy'] ?? false,
        "tor"         => $data['security']['tor'] ?? false,
        "relay"       => $data['security']['relay'] ?? false,
        "datacenter"  => $data['security']['datacenter'] ?? false,
        "risk_score"  => $data['security']['threat_score'] ?? 0,
        "asn"         => $data['network']['autonomous_system_number'] ?? '',
        "isp"         => $data['network']['organization'] ?? '',
        "city"        => $data['location']['city'] ?? '',
        "country"     => $data['location']['country_code'] ?? ''
    ];
}

/*
|--------------------------------------------------------------------------
| AUTO CHECK ON LOGIN + STORE IN USERMETA
|--------------------------------------------------------------------------
*/
add_action("wp_login", function ($username, $user) {

    $ip = $_SERVER['REMOTE_ADDR'];
    $check = wpaf_is_vpn_ip($ip);

    if (!$check) return;

    update_user_meta($user->ID, "wpaf_vpn_data", $check);
    update_user_meta($user->ID, "wpaf_vpn_ip", $ip);

    wpaf_vpn_log($user->ID, $check);

    // AUTO-ACTIONS
    if ($check['tor'] || $check['datacenter']) {
        update_user_meta($user->ID, "wpaf_banned", 1);
        wpaf_vpn_log($user->ID, "AUTO-BANNED (TOR/DC IP Detected)");
    }

    if ($check['vpn'] || $check['proxy']) {
        update_user_meta($user->ID, "wpaf_flagged", 1);
        wpaf_vpn_log($user->ID, "FLAGGED (VPN/Proxy detected)");
    }

    if ($check['risk_score'] >= 60) {
        update_user_meta($user->ID, "wpaf_flagged", 1);
        wpaf_vpn_log($user->ID, "HIGH RISK IP DETECTED (Score >= 60)");
    }

}, 10, 2);

/*
|--------------------------------------------------------------------------
| LOGGING SYSTEM
|--------------------------------------------------------------------------
*/
function wpaf_vpn_log($user, $msg)
{
    $log = get_option("wpaf_vpn_logs", []);

    $log[] = [
        "user" => $user,
        "msg"  => $msg,
        "time" => current_time('mysql'),
       
    ];

    update_option("wpaf_vpn_logs", $log);
}

/*
|--------------------------------------------------------------------------
| BLOCK ADS ON VPN/PROXY
|--------------------------------------------------------------------------
*/
function wpaf_vpn_adblock($user_id)
{
    $data = get_user_meta($user_id, "wpaf_vpn_data", true);

    if (!$data) return false;

    if ($data['vpn'] == true) return true;
    if ($data['proxy'] == true) return true;
    if ($data['tor'] == true) return true;
    if ($data['datacenter'] == true) return true;

    if ($data['risk_score'] >= 60) return true;

    return false;
}
?>
