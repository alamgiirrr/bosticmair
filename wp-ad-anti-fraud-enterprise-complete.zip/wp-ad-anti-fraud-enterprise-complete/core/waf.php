<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| FIREWALL CONFIG
|--------------------------------------------------------------------------
*/
define("WPAF_WAF_RATE_LIMIT", 30); // 30 requests / minute
define("WPAF_WAF_BAN_DURATION", 86400); // 1 day



/*
|--------------------------------------------------------------------------
| BLOCK HEADLESS BROWSERS
|--------------------------------------------------------------------------
*/
function wpaf_waf_is_headless()
{
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

    $patterns = [
        "headless",
        "phantom",
        "selenium",
        "puppeteer",
        "playwright",
        "nodejs",
        "curl",
        "wget",
        "python-requests",
        "python",
        "powershell",
        "scrapy",
        "java"
    ];

    foreach ($patterns as $bad) {
        if (strpos($ua, $bad) !== false) {
            return true;
        }
    }

    return false;
}

/*
|--------------------------------------------------------------------------
| BLOCK IF JAVASCRIPT DISABLED (JS Test Cookie)
|--------------------------------------------------------------------------
*/
function wpaf_waf_js_test()
{
    if (!isset($_COOKIE['wpaf_js_enabled'])) {
        // Set cookie
        setcookie("wpaf_js_enabled", 1, time() + 3600, "/");
        return false; 
    }

    return false;
}

/*
|--------------------------------------------------------------------------
| RATE LIMITING
|--------------------------------------------------------------------------
*/
function wpaf_waf_rate_limit($ip)
{
    $key = "wpaf_rate_" . md5($ip);
    $data = get_transient($key);

    if (!$data) {
        $data = ["count" => 1, "start" => time()];
        set_transient($key, $data, 60);
        return false;
    }

    $data['count']++;

    set_transient($key, $data, 60);

    if ($data['count'] > WPAF_WAF_RATE_LIMIT) {
        return true; // rate limit exceeded
    }

    return false;
}

/*
|--------------------------------------------------------------------------
| FIREWALL EXECUTION
|--------------------------------------------------------------------------
*/

function wpaf_waf_should_bypass() {

    // Logged in admin always safe
    if (is_user_logged_in() && current_user_can('administrator')) {
        return true;
    }

    // wp-admin panel safe
    if (is_admin()) {
        return true;
    }

    // wp-login safe
    if (strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false) {
        return true;
    }

    return false;
}

add_action('init', function () {
    
    if (wpaf_waf_should_bypass()) return;

    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    // 1. Check if IP already banned
    $banned_ips = get_option("wpaf_waf_banned_ips", []);
    if (isset($banned_ips[$ip]) && $banned_ips[$ip] > time()) {
        wp_die("Access Denied (WAF Blocked)", "WAF Block");
    }

    // 2. Detect headless browsers
    if (wpaf_waf_is_headless()) {
        wpaf_waf_ban_ip($ip, "Headless Browser Detected");
        wp_die("Access Denied (Bot Detected)", "WAF Block");
    }

    // 3. Javascript disabled
    if (!isset($_COOKIE['wpaf_js_enabled'])) {
        // Will be validated after first refresh
        setcookie("wpaf_js_enabled", 1, time() + 3600, "/");
    } 

    // 4. Rate limiting
    if (wpaf_waf_rate_limit($ip)) {
        wpaf_waf_ban_ip($ip, "Rate Limit Exceeded");
        wp_die("Access Denied (Too Many Requests)", "WAF Block");
    }

});

/*
|--------------------------------------------------------------------------
| BAN IP
|--------------------------------------------------------------------------
*/
function wpaf_waf_ban_ip($ip, $reason)
{
    $banned = get_option("wpaf_waf_banned_ips", []);
    $banned[$ip] = time() + WPAF_WAF_BAN_DURATION;
    update_option("wpaf_waf_banned_ips", $banned);

    wpaf_waf_log($ip, "IP BANNED: {$reason}");
}

/*
|--------------------------------------------------------------------------
| LOGGING
|--------------------------------------------------------------------------
*/
function wpaf_waf_log($ip, $msg)
{
    $log = get_option("wpaf_waf_logs", []);
    $log[] = [
        "ip"   => $ip,
        "msg"  => $msg,
        "time' => current_time('mysql"
    ];
    update_option("wpaf_waf_logs", $log);
}
?>
