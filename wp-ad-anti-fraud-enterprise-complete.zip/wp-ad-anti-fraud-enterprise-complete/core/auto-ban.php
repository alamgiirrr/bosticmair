<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| MAIN AUTO-BAN POLICY ENGINE
|--------------------------------------------------------------------------
| এই ফাংশন সব Risk Sources থেকে ডেটা নিয়ে সিদ্ধান্ত নেয়
|--------------------------------------------------------------------------
*/

function wpaf_run_auto_ban_engine($user_id) 
{
    $reason = [];
    $shouldBan  = false;
    $shouldFlag = false;

    /*
    |--------------------------------------------------------------------------
    | 1. Fingerprint Fraud (Duplicate Device)
    |--------------------------------------------------------------------------
    */
    $fp = get_user_meta($user_id, 'wpaf_fp', true);
    if ($fp) {
        global $wpdb;
        $dupes = $wpdb->get_results($wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='wpaf_fp' AND meta_value=%s",
            $fp
        ));

        if (count($dupes) > 1) {
            $shouldBan = true;
            $reason[]  = "Duplicate Fingerprint (Multi-account same device)";
        }
    }


    /*
    |--------------------------------------------------------------------------
    | 2. VPN / Proxy / TOR
    |--------------------------------------------------------------------------
    */
    $vpn = get_user_meta($user_id, 'wpaf_vpn_data', true);

    if ($vpn) {
        if ($vpn['tor'] || $vpn['datacenter']) {
            $shouldBan = true;
            $reason[]  = "TOR/Datacenter IP detected";
        }

        if ($vpn['vpn'] || $vpn['proxy']) {
            $shouldFlag = true;
            $reason[]   = "VPN/Proxy usage";
        }

        if ($vpn['risk_score'] >= 60) {
            $shouldBan = true;
            $reason[]  = "High Risk IP Score ({$vpn['risk_score']})";
        }
    }


    /*
    |--------------------------------------------------------------------------
    | 3. Behavior AI FraudScore
    |--------------------------------------------------------------------------
    */
    $behaviorScore = intval(get_user_meta($user_id, 'wpaf_fraudscore', true));

    if ($behaviorScore >= 80) {
        $shouldBan = true;
        $reason[]  = "High FraudScore ($behaviorScore)";
    }
    elseif ($behaviorScore >= 60) {
        $shouldFlag = true;
        $reason[]   = "Suspicious Behavior Score ($behaviorScore)";
    }


    /*
    |--------------------------------------------------------------------------
    | 4. Geo-Velocity (Impossible Travel)
    |--------------------------------------------------------------------------
    */
    $geoLogs = get_option("wpaf_geo_logs", []);
    if (!empty($geoLogs)) {
        $lastEntry = end($geoLogs);
        if ($lastEntry['user'] == $user_id) {
            if (strpos($lastEntry['msg'], "AUTO-BANNED") !== false) {
                $shouldBan = true;
                $reason[]  = "Geo-Velocity: Impossible travel";
            }
            elseif (strpos($lastEntry['msg'], "FLAGGED") !== false) {
                $shouldFlag = true;
                $reason[]   = "Geo-Velocity: Suspicious travel pattern";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | 5. Honeypot Trap Trigger
    |--------------------------------------------------------------------------
    */
    $trapLogs = get_option("wpaf_trap_logs", []);
    if (!empty($trapLogs)) {
        $lastTrap = end($trapLogs);
        if ($lastTrap['user'] == $user_id) {
            if (strpos($lastTrap['msg'], "Bot Trap Activated") !== false) {
                $shouldBan = true;
                $reason[]  = "Honeypot Triggered (Bot Behavior)";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | 6. Session Hijacking (Token / IP mismatch)
    |--------------------------------------------------------------------------
    */
    $sessionLogs = get_option("wpaf_session_logs", []);
    if (!empty($sessionLogs)) {
        $lastS = end($sessionLogs);
        if ($lastS['user'] == $user_id) {
            if (
                strpos($lastS['msg'], "token mismatch") !== false ||
                strpos($lastS['msg'], "hijack") !== false ||
                strpos($lastS['msg'], "Different IP detected") !== false
            ) {
                $shouldBan = true;
                $reason[]  = "Session Hijack Suspicion";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | FINAL DECISION (BAN / FLAG / CLEAN)
    |--------------------------------------------------------------------------
    */

    if ($shouldBan) {
        update_user_meta($user_id, 'wpaf_banned', 1);
        wpaf_auto_ban_log($user_id, "USER BANNED", $reason);
        return "banned";
    }

    if ($shouldFlag) {
        update_user_meta($user_id, 'wpaf_flagged', 1);
        wpaf_auto_ban_log($user_id, "USER FLAGGED", $reason);
        return "flagged";
    }

    // If clean
    wpaf_auto_ban_log($user_id, "USER CLEAN", ["No risks"]);
    return "clean";
}



/*
|--------------------------------------------------------------------------
| AUTO-RUN ENGINE ON EACH PAGE LOAD
|--------------------------------------------------------------------------
*/
add_action("init", function () {
    if (!is_user_logged_in()) return;

    $user_id = get_current_user_id();
    wpaf_run_auto_ban_engine($user_id);
});


/*
|--------------------------------------------------------------------------
| LOG STORAGE
|--------------------------------------------------------------------------
*/
function wpaf_auto_ban_log($user, $status, $reasons)
{
    $logs = get_option("wpaf_auto_ban_logs", []);

    $logs[] = [
        "user"   => $user,
        "status" => $status,
        "reason" => implode(" | ", $reasons),
        "time"   => current_time('mysql')
    ];

    update_option("wpaf_auto_ban_logs", $logs);
}

?>
