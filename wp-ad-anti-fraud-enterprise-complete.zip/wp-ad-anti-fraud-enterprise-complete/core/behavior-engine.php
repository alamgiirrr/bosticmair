<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| SAVE BEHAVIOR DATA (REST API)
|--------------------------------------------------------------------------
*/
add_action('rest_api_init', function () {
    register_rest_route('wpaf-enterprise/v1', '/behavior', [
        'methods'  => 'POST',
        'callback' => 'wpaf_behavior_save',
        'permission_callback' => '__return_true'
    ]);
});

/*
|--------------------------------------------------------------------------
| CALCULATE FRAUDSCORE
|--------------------------------------------------------------------------
*/
function wpaf_calculate_fraudscore($data)
{
    $score = 0;

    // 1. Mouse movement entropy
    if ($data['mouse_entropy'] < 25) $score += 30;

    // 2. Scroll abnormal pattern
    if ($data['scroll_variance'] < 10) $score += 20;

    // 3. Dwell time
    if ($data['dwell'] < 2) $score += 25; // Less than 2 sec = BOT

    // 4. Click interval check
    if ($data['click_speed'] < 120) $score += 15;

    // 5. Hover timing
    if ($data['hover_avg'] < 80) $score += 10;

    return min($score, 100);
}

/*
|--------------------------------------------------------------------------
| SAVE BEHAVIOR + SCORE
|--------------------------------------------------------------------------
*/
function wpaf_behavior_save($req)
{
    $user = get_current_user_id();
    if (!$user) return ['status' => 'not_logged'];

    $data = [
        'mouse_entropy'  => floatval($req->get_param('mouse_entropy')),
        'scroll_variance'=> floatval($req->get_param('scroll_var')),
        'dwell'          => floatval($req->get_param('dwell')),
        'click_speed'    => floatval($req->get_param('click_speed')),
        'hover_avg'      => floatval($req->get_param('hover_avg')),
    ];

    $score = wpaf_calculate_fraudscore($data);

    update_user_meta($user, 'wpaf_behavior_data', $data);
    update_user_meta($user, 'wpaf_fraudscore', $score);

    wpaf_behavior_log($user, "Behavior updated | FraudScore: $score");

    // AUTO BAN RULE
    if ($score >= 80) {
        update_user_meta($user, 'wpaf_banned', 1);
        wpaf_behavior_log($user, "AUTO-BANNED for High FraudScore ($score)");
    }

    // AUTO FLAG
    if ($score >= 60 && $score < 80) {
        update_user_meta($user, 'wpaf_flagged', 1);
        wpaf_behavior_log($user, "FLAGGED for Suspicious Behavior ($score)");
    }

    return ['score' => $score];
}

/*
|--------------------------------------------------------------------------
| LOG SYSTEM
|--------------------------------------------------------------------------
*/
function wpaf_behavior_log($user, $msg)
{
    $log = get_option('wpaf_behavior_logs', []);
    $log[] = [
        "user" => $user,
        "msg"  => $msg,
        "time" => current_time('mysql')
    ];
    update_option("wpaf_behavior_logs", $log);
}
?>
