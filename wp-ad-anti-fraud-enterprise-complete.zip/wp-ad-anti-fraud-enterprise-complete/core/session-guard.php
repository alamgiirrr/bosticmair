<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------
| SAFE TOKEN GENERATOR
|--------------------------------------------------
*/
function wpaf_generate_session_token() {
    if (function_exists('random_bytes')) {
        return bin2hex(random_bytes(32));
    }
    return wp_hash(uniqid(mt_rand(), true));
}

/*
|--------------------------------------------------
| CREATE SESSION ON LOGIN
|--------------------------------------------------
*/
add_action('wp_login', function ($username, $user) {

    if (!$user || !isset($user->ID)) return;

    $session_token = wpaf_generate_session_token();
    $ip            = $_SERVER['REMOTE_ADDR'] ?? '';
    $fp            = get_user_meta($user->ID, "wpaf_fp", true);

    $session_data = [
        "token" => $session_token,
        "ip"    => $ip,
        "fp"    => $fp,
        "time"  => time()
    ];

    update_user_meta($user->ID, "wpaf_session", $session_data);

    // Safe cookie
    setcookie(
        "wpaf_session",
        $session_token,
        time() + 86400,
        COOKIEPATH,
        COOKIE_DOMAIN,
        is_ssl(),
        true
    );

    wpaf_session_log($user->ID, "Session created | IP={$ip}");

}, 10, 2);

/*
|--------------------------------------------------
| VALIDATE SESSION (SAFE HOOK)
|--------------------------------------------------
*/
add_action("template_redirect", function () {

    if (!is_user_logged_in()) return;

    $user_id = get_current_user_id();
    $session = get_user_meta($user_id, "wpaf_session", true);

    if (!$session || !is_array($session)) {
        wpaf_session_log($user_id, "Missing session → force logout");
        wp_safe_redirect(wp_logout_url());
        exit;
    }

    $browser_token = $_COOKIE['wpaf_session'] ?? null;

    if (!$browser_token || $browser_token !== ($session['token'] ?? null)) {
        wpaf_session_log($user_id, "Token mismatch → logout");
        wp_safe_redirect(wp_logout_url());
        exit;
    }

    // FP mismatch
    $current_fp = get_user_meta($user_id, "wpaf_fp", true);
    if (!empty($session['fp']) && $current_fp && $session['fp'] !== $current_fp) {
        update_user_meta($user_id, "wpaf_flagged", 1);
        wpaf_session_log($user_id, "FP mismatch → logout");
        wp_safe_redirect(wp_logout_url());
        exit;
    }

    // IP mismatch
    $current_ip = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!empty($session['ip']) && $session['ip'] !== $current_ip) {
        update_user_meta($user_id, "wpaf_flagged", 1);
        wpaf_session_log($user_id, "IP mismatch → logout");
        wp_safe_redirect(wp_logout_url());
        exit;
    }

});

/*
|--------------------------------------------------
| LOG SYSTEM
|--------------------------------------------------
*/
function wpaf_session_log($user, $msg) {

    $logs = get_option("wpaf_session_logs", []);
    if (!is_array($logs)) $logs = [];

    $logs[] = [
        "user" => $user,
        "msg"  => $msg,
        "time" => current_time('mysql')
    ];

    update_option("wpaf_session_logs", $logs);
}
