<?php
if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| REGISTER REST API FOR BOT TRAP EVENTS
|--------------------------------------------------------------------------
*/
add_action('rest_api_init', function () {
    register_rest_route('wpaf-enterprise/v1', '/trap-trigger', [
        'methods'  => 'POST',
        'callback' => 'wpaf_trap_triggered',
        'permission_callback' => '__return_true'
    ]);
});

/*
|--------------------------------------------------------------------------
| WHEN BOT TRIGGERED A TRAP
|--------------------------------------------------------------------------
*/
function wpaf_trap_triggered($req)
{
    $user = get_current_user_id();
    $ip   = $_SERVER['REMOTE_ADDR'];
    $type = sanitize_text_field($req->get_param('trap'));

    // Log trap trigger
    wpaf_trap_log($user, "Bot Trap Activated: {$type} from IP {$ip}");

    // Auto-ban the user
    if ($user) {
        update_user_meta($user, 'wpaf_banned', 1);
        wpaf_trap_log($user, "AUTO-BANNED (Bot Trap Triggered)");
    }

    // IP-level ban (optional)
    $banned_ips = get_option('wpaf_banned_ips', []);
    $banned_ips[$ip] = time();
    update_option('wpaf_banned_ips', $banned_ips);

    return ['status' => 'bot_flagged'];
}

/*
|--------------------------------------------------------------------------
| STORE LOGS
|--------------------------------------------------------------------------
*/
function wpaf_trap_log($user, $msg)
{
    $log = get_option("wpaf_trap_logs", []);
    $log[] = [
        "user" => $user,
        "msg"  => $msg,
        "time" => current_time('mysql')
    ];

    update_option("wpaf_trap_logs", $log);
}

/*
|--------------------------------------------------------------------------
| ADD BOT TRAPS AUTOMATICALLY INTO PAGE FOOTER
|--------------------------------------------------------------------------
*/
add_action('wp_footer', function () {

    // Hidden button trap
    echo '<button id="wpaf_trap_btn" style="opacity:0;pointer-events:none;position:absolute;top:-9999px;">
        Invisible Trap
    </button>';

    // Hidden fake ad link
    echo '<a id="wpaf_fake_ad" href="#" style="opacity:0;pointer-events:none;position:absolute;left:-9999px;">
        Fake Ad Click
    </a>';

    // Hidden form trap
    echo '<form id="wpaf_trap_form" style="display:none;">
        <input type="text" name="trap_input" value="">
        <button type="submit">Submit</button>
    </form>';

    // Include JS traps handler
    echo '<script src="' . plugin_dir_url(__FILE__) . '../js/honeypot.js"></script>';
});
?>
