async function wpafCanvasFingerprint() {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    ctx.textBaseline = "top";
    ctx.font = "14px 'Arial'";
    ctx.fillStyle = "#f60";
    ctx.fillRect(0, 0, 100, 30);
    ctx.fillStyle = "#069";
    ctx.fillText("WP AntiFraud Fingerprint", 2, 14);

    return canvas.toDataURL();
}

async function wpafWebGLFingerprint() {
    let canvas = document.createElement("canvas");
    let gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");

    if (!gl) return "no_webgl";

    let ext = gl.getExtension("WEBGL_debug_renderer_info");

    let renderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL);
    let vendor = gl.getParameter(ext.UNMASKED_VENDOR_WEBGL);

    return renderer + "::" + vendor;
}

async function wpafAudioFingerprint() {
    const ctx = new AudioContext();
    const oscillator = ctx.createOscillator();
    const analyser = ctx.createAnalyser();
    const gain = ctx.createGain();

    oscillator.type = "triangle";
    gain.gain.value = 0;

    oscillator.connect(gain);
    gain.connect(analyser);
    oscillator.start(0);

    const data = new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatFrequencyData(data);

    oscillator.stop();

    return btoa(data.join(""));
}

async function wpafDeviceEntropy() {
    return [
        navigator.userAgent,
        navigator.language,
        screen.width + "x" + screen.height,
        window.devicePixelRatio,
        navigator.hardwareConcurrency,
        navigator.platform,
        new Date().getTimezoneOffset(),
        Intl.DateTimeFormat().resolvedOptions().timeZone,
        navigator.maxTouchPoints,
        performance.memory ? performance.memory.jsHeapSizeLimit : "0",
        !!window.WebDriver,
        !!navigator.plugins.length
    ].join("::");
}

async function wpafGenerateFingerprint() {

    let canvas = await wpafCanvasFingerprint();
    let webgl = await wpafWebGLFingerprint();
    let audio = await wpafAudioFingerprint();
    let entropy = await wpafDeviceEntropy();

    let combined = canvas + "||" + webgl + "||" + audio + "||" + entropy;

    let finalFp = btoa(combined);

    return {
        fp: finalFp,
        entropy: btoa(entropy)
    };
}

/*
|--------------------------------------------------------------------------
| AUTO EXECUTE
|--------------------------------------------------------------------------
*/
document.addEventListener("DOMContentLoaded", async () => {

    const result = await wpafGenerateFingerprint();

    // Local Lock
    if (!localStorage.getItem("wpaf_enterprise_lock")) {
        localStorage.setItem("wpaf_enterprise_lock", "1");
    }
    document.cookie = "wpaf_enterprise_lock=1; path=/";

    // Send to server
    fetch("/wp-json/wpaf-enterprise/v1/save-fp", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            fp: result.fp,
            entropy: result.entropy
        })
    });
});
