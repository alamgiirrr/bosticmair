let wpafBehavior = {
    mouseMoves: [],
    scrollPos: [],
    clicks: [],
    hovers: [],
    dwellStart: Date.now()
};

// Track mouse movement
document.addEventListener("mousemove", (e) => {
    wpafBehavior.mouseMoves.push([e.clientX, e.clientY, Date.now()]);
});

// Scroll tracking
document.addEventListener("scroll", () => {
    wpafBehavior.scrollPos.push([window.scrollY, Date.now()]);
});

// Click tracking
document.addEventListener("click", () => {
    wpafBehavior.clicks.push(Date.now());
});

// Hover tracking
document.addEventListener("mouseover", () => {
    wpafBehavior.hovers.push(Date.now());
});

// After 5 seconds, send behavior to server
setTimeout(() => {
    let now = Date.now();

    // 1. Mouse entropy
    let mouse_entropy = wpafBehavior.mouseMoves.length;

    // 2. Scroll variance
    let scroll_var = wpafBehavior.scrollPos.length;

    // 3. Dwell time
    let dwell = (now - wpafBehavior.dwellStart) / 1000;

    // 4. Click speed (ms between clicks)
    let click_speed = 9999;
    if (wpafBehavior.clicks.length >= 2) {
        click_speed = wpafBehavior.clicks[1] - wpafBehavior.clicks[0];
    }

    // 5. Hover time interval
    let hover_avg = 9999;
    if (wpafBehavior.hovers.length >= 2) {
        hover_avg = wpafBehavior.hovers[1] - wpafBehavior.hovers[0];
    }

    fetch("/wp-json/wpaf-enterprise/v1/behavior", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            mouse_entropy,
            scroll_var,
            dwell,
            click_speed,
            hover_avg
        })
    });

}, 5000);
