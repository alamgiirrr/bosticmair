// 1. Invisible button clicked → BOT
document.addEventListener("click", (e) => {
    if (e.target.id === "wpaf_trap_btn") {
        wpafSendTrap("invisible_button");
    }
});

// 2. Fake ad clicked → BOT
document.addEventListener("click", (e) => {
    if (e.target.id === "wpaf_fake_ad") {
        wpafSendTrap("fake_ad_click");
    }
});

// 3. Hidden form auto-submitted → BOT
document.addEventListener("submit", (e) => {
    if (e.target.id === "wpaf_trap_form") {
        wpafSendTrap("hidden_form_submit");
    }
});

// 4. Rapid automated clicking → BOT
let lastClickTime = 0;
document.addEventListener("click", () => {
    let now = Date.now();
    if (now - lastClickTime < 40) { // <40ms = BOT (human can’t click this fast)
        wpafSendTrap("rapid_clicking");
    }
    lastClickTime = now;
});

// 5. Automated scrolling → BOT
let lastScroll = 0;
document.addEventListener("scroll", () => {
    let now = Date.now();
    if (now - lastScroll < 10) { // too-fast scroll
        wpafSendTrap("robotic_scroll");
    }
    lastScroll = now;
});


// SEND TRAP EVENT TO SERVER
function wpafSendTrap(type) {
    fetch("/wp-json/wpaf-enterprise/v1/trap-trigger", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({trap: type})
    });
}
