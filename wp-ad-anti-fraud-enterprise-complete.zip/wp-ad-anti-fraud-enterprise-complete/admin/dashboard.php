<?php
if (!defined('ABSPATH')) exit;

/* -----------------------------
   HELPERS
------------------------------*/
function wpaf_get($key, $default = []) {
    $data = get_option($key);
    return is_array($data) ? $data : $default;
}

function wpaf_render_logs_table($logs) {
    if (empty($logs)) {
        echo "<p style='color:#777;'>No logs found.</p>";
        return;
    }

    $first = reset($logs);
    if (!is_array($first)) {
        echo "<p>Invalid log format</p>";
        return;
    }

    echo '<table class="wpaf-table"><tr>';
    foreach (array_keys($first) as $col) {
        echo '<th>' . ucfirst(esc_html($col)) . '</th>';
    }
    echo '</tr>';

    foreach (array_reverse($logs) as $row) {
        echo '<tr>';
        foreach ($row as $cell) {
            echo '<td>' . esc_html($cell) . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
}

/* -----------------------------
   LOAD LOGS
------------------------------*/
$autoBanLogs = wpaf_get('wpaf_auto_ban_logs');
$vpnLogs     = wpaf_get('wpaf_vpn_logs');
$geoLogs     = wpaf_get('wpaf_geo_logs');
$sessionLogs = wpaf_get('wpaf_session_logs');
$trapLogs    = wpaf_get('wpaf_trap_logs');

/* -----------------------------
   STATS
------------------------------*/
$banned = 0;
$flagged = 0;

foreach ($autoBanLogs as $l) {
    if (($l['status'] ?? '') === 'USER BANNED') $banned++;
    if (($l['status'] ?? '') === 'USER FLAGGED') $flagged++;
}
?>

<div style="padding:25px;font-family:Arial">

<h1>🛡 AntiFraud Enterprise Dashboard</h1>

<div style="display:flex;gap:20px;margin-bottom:30px;">
    <div style="background:#ffe3e3;padding:20px;border-radius:10px;width:30%;">
        <h2>🔴 Total Banned</h2>
        <p style="font-size:32px;font-weight:bold;"><?php echo $banned; ?></p>
    </div>
    <div style="background:#fff5d1;padding:20px;border-radius:10px;width:30%;">
        <h2>🟡 Flagged Users</h2>
        <p style="font-size:32px;font-weight:bold;"><?php echo $flagged; ?></p>
    </div>
    <div style="background:#e5ffe3;padding:20px;border-radius:10px;width:30%;">
        <h2>🟢 System Status</h2>
        <p style="font-size:32px;font-weight:bold;">Operational</p>
    </div>
</div>

<style>
.wpaf-tab{padding:10px 20px;background:#f1f1f1;border-radius:6px;cursor:pointer;margin-right:10px;display:inline-block}
.wpaf-tab.active{background:#0073aa;color:#fff}
.wpaf-box{display:none;padding:20px;background:#fff;border:1px solid #ddd;border-radius:10px;margin-top:10px}
.wpaf-box.active{display:block}
.wpaf-table{width:100%;border-collapse:collapse;margin-top:10px}
.wpaf-table th,.wpaf-table td{border:1px solid #ccc;padding:10px}
</style>

<h2 style="margin:20px 0;">📘 Security Logs</h2>
    
<div id="wpaf_tabs">
    <div class="wpaf-tab active" data-box="autoban">Auto-Ban Logs</div>
    <div class="wpaf-tab" data-box="vpn">VPN Logs</div>
    <div class="wpaf-tab" data-box="geo">Geo Logs</div>
    <div class="wpaf-tab" data-box="session">Session Logs</div>
    <div class="wpaf-tab" data-box="trap">Trap Logs</div>
</div>

<?php
function render_box($id, $title, $logs) {
    echo "<div id='$id' class='wpaf-box ".($id==='autoban'?'active':'')."'>";
    echo "<h3>$title</h3>";
    echo "<button class='wpaf-clear-logs' data-type='$id'>🧹 Delete All Logs</button>";
    echo "<div class='wpaf-result'></div>";
    wpaf_render_logs_table($logs);
    echo "</div>";
}

render_box('autoban','Auto Ban Logs',$autoBanLogs);
render_box('vpn','VPN Logs',$vpnLogs);
render_box('geo','Geo Logs',$geoLogs);
render_box('session','Session Logs',$sessionLogs);
render_box('trap','Trap Logs',$trapLogs);
?>

</div>

<script>
var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {

    // Tabs
    document.querySelectorAll(".wpaf-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            document.querySelectorAll(".wpaf-tab").forEach(t => t.classList.remove("active"));
            document.querySelectorAll(".wpaf-box").forEach(b => b.classList.remove("active"));
            tab.classList.add("active");
            document.getElementById(tab.dataset.box).classList.add("active");
        });
    });

    // Delete
    document.querySelectorAll(".wpaf-clear-logs").forEach(btn => {
        btn.addEventListener("click", () => {

            if (!confirm("Delete all logs permanently?")) return;

            fetch(ajaxurl, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "action=wpaf_clear_logs&type=" + btn.dataset.type
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    btn.parentElement.querySelector("table")?.remove();
                    btn.nextElementSibling.innerHTML =
                        "<p style='color:green'>" + data.data + "</p>";
                } else {
                    alert("Error: " + data.data);
                }
            })
            .catch(err => {
                console.error(err);
                alert("AJAX failed");
            });

        });
    });

});
</script>