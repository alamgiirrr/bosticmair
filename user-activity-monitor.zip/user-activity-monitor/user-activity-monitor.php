<?php
/**
 * Plugin Name: User Activity Monitor PRO
 * Description: Full analytics engine: visitors, pageviews, time, scroll, referrer, device, browser, OS, geolocation (country+city), real-time sessions. (PART-1)
 * Version: 7.0
 */

if (!defined('ABSPATH')) exit;
global $wpdb;

/* ========================================================
   1) DATABASE TABLES (Phase-1: core analytics store)
======================================================== */

function uampro_create_tables() {
    global $wpdb;
    $p = $wpdb->prefix;
    $charset = $wpdb->get_charset_collate();

    require_once ABSPATH . "wp-admin/includes/upgrade.php";

    /* TABLE 1: Visits */
    $sql1 = "CREATE TABLE {$p}uampro_visits (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(60),
        user_id BIGINT,
        user_agent TEXT,
        device VARCHAR(20),
        browser VARCHAR(30),
        os VARCHAR(30),
        referrer TEXT,
        country VARCHAR(50),
        country_code VARCHAR(10),
        city VARCHAR(100),
        first_seen DATETIME,
        last_seen DATETIME
    ) $charset;";
    dbDelta($sql1);

    /* TABLE 2: Pageviews */
    $sql2 = "CREATE TABLE {$p}uampro_pageviews (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        visit_id BIGINT,
        url TEXT,
        time_spent INT,
        scroll_depth INT,
        clicked INT DEFAULT 0,
        clicked_positions LONGTEXT,
        viewed_at DATETIME
    ) $charset;";
    dbDelta($sql2);

    /* TABLE 3: Realtime Sessions */
    $sql3 = "CREATE TABLE {$p}uampro_realtime (
        session_id VARCHAR(200) PRIMARY KEY,
        ip VARCHAR(60),
        page TEXT,
        country VARCHAR(50),
        city VARCHAR(100),
        last_activity DATETIME
    ) $charset;";
    dbDelta($sql3);

    /* TABLE 4: User Flow */
    $sql4 = "CREATE TABLE {$p}uampro_flow (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        visit_id BIGINT,
        from_page TEXT,
        to_page TEXT,
        moved_at DATETIME
    ) $charset;";
    dbDelta($sql4);
}

register_activation_hook(__FILE__, 'uampro_create_tables');


/* Schedule cleanup cron if not already scheduled */
if (!wp_next_scheduled('uampro_realtime_cleanup')) {
    wp_schedule_event(time(), 'every_10_minutes', 'uampro_realtime_cleanup');
}


/* ========================================================
   2) USER AGENT PARSER (device + browser + os)
======================================================== */
function uampro_detect_device($ua){
    return (stripos($ua,"mobile")!==false) ? "Mobile" : "Desktop";
}

function uampro_detect_browser($ua){
    $ua = strtolower($ua);

    if (strpos($ua, 'edge') !== false || strpos($ua, 'edg') !== false) {
        return "Edge";
    }
    if (strpos($ua, 'opr') !== false || strpos($ua, 'opera') !== false) {
        return "Opera";
    }
    if (strpos($ua, 'chrome') !== false && strpos($ua, 'safari') !== false) {
        return "Chrome";
    }
    if (strpos($ua, 'firefox') !== false) {
        return "Firefox";
    }
    if (strpos($ua, 'safari') !== false) {
        return "Safari";
    }

    return "Other";
}


function uampro_detect_os($ua) {
    $ua = strtolower($ua);

    if (strpos($ua, 'windows phone') !== false) {
        return "Windows Phone";
    }
    if (strpos($ua, 'windows') !== false) {
        return "Windows";
    }
    if (strpos($ua, 'android') !== false) {
        return "Android";
    }
    if (strpos($ua, 'iphone') !== false || strpos($ua, 'ipad') !== false || strpos($ua, 'ipod') !== false) {
        return "iOS";
    }
    if (strpos($ua, 'macintosh') !== false || strpos($ua, 'mac os') !== false) {
        return "Mac";
    }
    if (strpos($ua, 'linux') !== false || strpos($ua, 'x11') !== false) {
        return "Linux";
    }

    return "Other";
}



/* ========================================================
   GEO-LOCATION LOOKUP (Optimized + Cached + Error Safe)
======================================================== */
function uampro_geo($ip) {
    // 1) CACHE: get stored result if exists (24 hours)
    $cache_key = "uampro_geo_" . md5($ip);
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        return $cached;  // skip API, return instantly
    }

    // 2) API Request with timeout + error protection
    $res = wp_remote_get(
        "http://ip-api.com/json/$ip?fields=status,country,countryCode,city",
        ['timeout' => 2]  // if slow, auto fallback
    );

    if (is_wp_error($res)) {
        $data = ["Unknown","--","Unknown"];
        set_transient($cache_key, $data, DAY_IN_SECONDS);
        return $data;
    }

    $body = json_decode($res["body"], true);

    if (!is_array($body) || ($body["status"] ?? "") !== "success") {
        $data = ["Unknown","--","Unknown"];
        set_transient($cache_key, $data, DAY_IN_SECONDS);
        return $data;
    }

    // Valid result
    $data = [
        $body["country"]     ?? "Unknown",
        $body["countryCode"] ?? "--",
        $body["city"]        ?? "Unknown"
    ];

    // 3) Cache for 24 hours
    set_transient($cache_key, $data, DAY_IN_SECONDS);

    return $data;
}


/* ========================================================
   4) FRONTEND TRACKER JS (FULL UPDATED - accurate time + no duplicates)
======================================================== */
function uampro_js(){ ?>
<script>
(function(){

    /* ========== ACCURATE ACTIVE TIME TRACKER ========== */
    let activeTime = 0;          // Total active browsing seconds
    let lastActive = Date.now(); // Last active timestamp
    let isActive = true;         // Tab is currently active?

    /* Idle detection (20 seconds) */
    let idleTimer;

    function tick() {
        if (isActive) {
            let now = Date.now();
            activeTime += Math.round((now - lastActive) / 1000);
            lastActive = now;
        }
        setTimeout(tick, 1000);
    }
    tick();

    function markActive() {
        isActive = true;
        lastActive = Date.now();
        clearTimeout(idleTimer);

        idleTimer = setTimeout(() => {
            isActive = false;
        }, 20000); // 20 sec idle → stop counting
    }

    ["mousemove","keydown","scroll","click","touchstart"].forEach(evt => {
        window.addEventListener(evt, markActive);
    });

    markActive();

    document.addEventListener("visibilitychange", () => {
        if (document.hidden) {
            isActive = false;
        } else {
            isActive = true;
            lastActive = Date.now();
        }
    });

    window.addEventListener("blur", () => { isActive = false; });
    window.addEventListener("focus", () => { 
        isActive = true; 
        lastActive = Date.now();
    });


    /* ========== SCROLL + CLICK HEATMAP ========== */
    let maxScroll = 0;
    let clicks = [];
    let pageviewID = 0;

    document.addEventListener("click", e => {
        clicks.push({
            x: e.clientX,
            y: e.clientY,
            t: Date.now()
        });
    });

    window.addEventListener("scroll", () => {
        let doc = document.documentElement;
        let percent = ((window.scrollY + window.innerHeight) / doc.scrollHeight) * 100;
        maxScroll = Math.max(maxScroll, Math.round(percent));
    });


    /* ========== AJAX Sender Utility ========== */
    function send(action, data = {}) {
        data.action = action;
        return fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: new URLSearchParams(data).toString()
        }).then(res => res.text());
    }


    /* ========== CREATE PAGEVIEW RECORD (returns ID) ========== */
    send("uampro_pageview", {
        url: location.pathname,
        ref: document.referrer
    }).then(id => {
        pageviewID = id;
    });


    /* ========== FINAL SEND ON EXIT ========== */
    window.addEventListener("beforeunload", () => {
        if (!pageviewID) return;

        navigator.sendBeacon(
            "<?php echo admin_url('admin-ajax.php'); ?>?action=uampro_timespent",
            new URLSearchParams({
                id: pageviewID,
                time: activeTime,     // accurate time
                scroll: maxScroll,
                url: location.pathname,
                clicks: JSON.stringify(clicks)
            })
        );
    });


    /* ========== REAL-TIME PING (unchanged) ========== */
    setInterval(() => send("uampro_live", { page: location.pathname }), 15000);

})();
</script>
<?php }
add_action('wp_footer','uampro_js');



/* ========================================================
   5) PAGEVIEW LOGGER (FIXED: no duplicate, secure)
======================================================== */
function uampro_pageview(){
    global $wpdb;
    $p = $wpdb->prefix;

    $ip   = $_SERVER["REMOTE_ADDR"];
    $ua   = $_SERVER["HTTP_USER_AGENT"];
    $user = get_current_user_id();
    $url  = sanitize_text_field($_POST["url"]);
    $ref  = sanitize_text_field($_POST["ref"]);

    $device  = uampro_detect_device($ua);
    $browser = uampro_detect_browser($ua);
    $os      = uampro_detect_os($ua);

    list($country,$code,$city)=uampro_geo($ip);

    $vis = "{$p}uampro_visits";

    /* EXISTING VISIT? (SECURE prepare) */
    $v = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $vis WHERE ip=%s ORDER BY last_seen DESC LIMIT 1",
            $ip
        )
    );

    if(!$v){
        /* Create new visit */
        $wpdb->insert($vis,[
            'ip'=>$ip,
            'user_id'=>$user,
            'user_agent'=>$ua,
            'device'=>$device,
            'browser'=>$browser,
            'os'=>$os,
            'referrer'=>$ref,
            'country'=>$country,
            'country_code'=>$code,
            'city'=>$city,
            'first_seen'=>current_time('mysql'),
            'last_seen'=>current_time('mysql')
        ]);
        $vid = $wpdb->insert_id;

    } else {
        /* Update last_seen */
        $vid = $v->id;
        $wpdb->update($vis,
            ['last_seen'=>current_time('mysql')],
            ['id'=>$vid]
        );

        /* USER FLOW: last → new */
        $last_page = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT url FROM {$p}uampro_pageviews WHERE visit_id=%d ORDER BY viewed_at DESC LIMIT 1",
                $vid
            )
        );

        if($last_page && $last_page->url !== $url){
            $wpdb->insert("{$p}uampro_flow",[
                'visit_id'=>$vid,
                'from_page'=>$last_page->url,
                'to_page'=>$url,
                'moved_at'=>current_time('mysql')
            ]);
        }
    }

    /* PAGEVIEW INSERT (only once per page load) */
    $wpdb->insert("{$p}uampro_pageviews",[
        'visit_id'=>$vid,
        'url'=>$url,
        'time_spent'=>0,
        'scroll_depth'=>0,
        'clicked'=>0,
        'clicked_positions'=>"",
        'viewed_at'=>current_time('mysql')
    ]);

    /* return pageview id */
    echo $wpdb->insert_id;

    wp_die();
}
add_action("wp_ajax_uampro_pageview","uampro_pageview");
add_action("wp_ajax_nopriv_uampro_pageview","uampro_pageview");


/* ========================================================
   6) TIME + SCROLL + CLICK LOGGER (FIXED: update instead of insert)
======================================================== */
function uampro_timespent(){
    global $wpdb;
    $p = $wpdb->prefix;

    /* pageview ID sent from JS */
    $pageview_id = intval($_POST["id"]);
    $time   = intval($_POST["time"]);
    $scroll = intval($_POST["scroll"]);
    $clicks = stripslashes($_POST["clicks"]);

    /* no ID = no update */
    if(!$pageview_id) wp_die();

    /* UPDATE existing pageview record */
    $wpdb->update(
        "{$p}uampro_pageviews",
        [
            'time_spent'       => $time,
            'scroll_depth'     => $scroll,
            'clicked'          => (strlen($clicks) > 5 ? 1 : 0),
            'clicked_positions'=> $clicks,
        ],
        ['id' => $pageview_id]   // WHERE id = pageview row
    );

    wp_die();
}

add_action("wp_ajax_uampro_timespent","uampro_timespent");
add_action("wp_ajax_nopriv_uampro_timespent","uampro_timespent");



/* ========================================================
   7) LIVE USERS LOGGER
======================================================== */
function uampro_live(){
    global $wpdb;
    $p=$wpdb->prefix;

    if(!session_id()) session_start();
    $sid=session_id();
    $ip=$_SERVER["REMOTE_ADDR"];
    $page=sanitize_text_field($_POST["page"]);

    list($country,$code,$city)=uampro_geo($ip);

    $wpdb->replace("{$p}uampro_realtime",[
        'session_id'=>$sid,
        'ip'=>$ip,
        'page'=>$page,
        'country'=>$country,
        'city'=>$city,
        'last_activity'=>current_time('mysql')
    ]);

    wp_die();
}
add_action("wp_ajax_uampro_live","uampro_live");
add_action("wp_ajax_nopriv_uampro_live","uampro_live");
/* ========================================================
   8) ADMIN MENU
======================================================== */
function uampro_menu(){
 add_menu_page(
   "Analytics PRO",
   "Analytics PRO",
   "manage_options",
   "uampro",
   "uampro_dashboard",
   "dashicons-chart-area",
   70
 );
}
add_action("admin_menu","uampro_menu");


/* ========================================================
   9) DASHBOARD (MAIN UI + GRID LAYOUT)
======================================================== */
function uampro_dashboard(){
    global $wpdb;
    $p=$wpdb->prefix;

    /* ---------------- DATE FILTER ---------------- */
    $from = $_GET['from'] ?? date("Y-m-01");
    $to   = $_GET['to'] ?? date("Y-m-d");
    $fd = $from." 00:00:00";
    $td = $to." 23:59:59";

    /* ---------------- SUMMARY STATS ---------------- */
    $total_vis = $wpdb->get_var("SELECT COUNT(*) FROM {$p}uampro_visits");
    $total_pv  = $wpdb->get_var("SELECT COUNT(*) FROM {$p}uampro_pageviews");
    $live      = $wpdb->get_var("SELECT COUNT(*) FROM {$p}uampro_realtime WHERE last_activity > (NOW()-INTERVAL 1 MINUTE)");

    $range_vis = $wpdb->get_var("SELECT COUNT(*) FROM {$p}uampro_visits WHERE last_seen BETWEEN '$fd' AND '$td'");
    $range_pv  = $wpdb->get_var("SELECT COUNT(*) FROM {$p}uampro_pageviews WHERE viewed_at BETWEEN '$fd' AND '$td'");

?>
<style>
.uam-box{display:flex;gap:20px;margin:20px 0;}
.uam-card{
 background:#fff;padding:20px;border-radius:12px;text-align:center;
 box-shadow:0 0 10px rgba(0,0,0,0.1);flex:1;
}
.chart-grid{
 display:grid;
 grid-template-columns:repeat(2,1fr);
 gap:25px;margin:30px 0;
}
.chart-box{
 background:white;padding:20px;border-radius:12px;
 box-shadow:0 0 10px rgba(0,0,0,0.08);
}
canvas{
 width:100%!important;
 max-height:260px!important;
}
table{
 width:100%;border-collapse:collapse;margin-top:25px;
 background:#fff;border-radius:12px;
 box-shadow:0 0 10px rgba(0,0,0,0.1);overflow:hidden;
}
th,td{padding:12px;border-bottom:1px solid #eee;}
th{background:#fafafa;text-align:left;}
</style>

<div class="wrap">

<h1>Analytics PRO Dashboard</h1>

<form method="GET" style="margin:20px 0;">
 <input type="hidden" name="page" value="uampro">
 <strong>From:</strong> <input type="date" name="from" value="<?php echo $from; ?>">
 <strong>To:</strong> <input type="date" name="to" value="<?php echo $to; ?>">
 <button class="button button-primary">Filter</button>
</form>

<div class="uam-box">
 <div class="uam-card"><h2>Total Visitors</h2><p><?= $total_vis ?></p></div>
 <div class="uam-card"><h2>Total Pageviews</h2><p><?= $total_pv ?></p></div>
 <div class="uam-card"><h2>Live Users</h2><p><?= $live ?></p></div>
</div>

<div class="uam-box">
 <div class="uam-card"><h2>Visitors (Range)</h2><p><?= $range_vis ?></p></div>
 <div class="uam-card"><h2>Pageviews (Range)</h2><p><?= $range_pv ?></p></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php
/* ---------------- QUERIES FOR CHARTS ---------------- */

$daily=$wpdb->get_results("
 SELECT DATE(viewed_at) d, COUNT(*) c
 FROM {$p}uampro_pageviews
 WHERE viewed_at BETWEEN '$fd' AND '$td'
 GROUP BY DATE(viewed_at)
");

$weekly=$wpdb->get_results("
 SELECT YEARWEEK(viewed_at) w, COUNT(*) c
 FROM {$p}uampro_pageviews
 WHERE viewed_at BETWEEN '$fd' AND '$td'
 GROUP BY YEARWEEK(viewed_at)
");

$monthly=$wpdb->get_results("
 SELECT DATE_FORMAT(viewed_at,'%Y-%m') m, COUNT(*) c
 FROM {$p}uampro_pageviews
 WHERE viewed_at BETWEEN '$fd' AND '$td'
 GROUP BY m
");

$devices=$wpdb->get_results("
 SELECT device d, COUNT(*) c
 FROM {$p}uampro_visits
 WHERE last_seen BETWEEN '$fd' AND '$td'
 GROUP BY device
");

$top_pages=$wpdb->get_results("
 SELECT url, COUNT(*) c
 FROM {$p}uampro_pageviews
 WHERE viewed_at BETWEEN '$fd' AND '$td'
 GROUP BY url ORDER BY c DESC LIMIT 20
");

$refs=$wpdb->get_results("
 SELECT referrer r, COUNT(*) c
 FROM {$p}uampro_visits
 WHERE last_seen BETWEEN '$fd' AND '$td'
 GROUP BY referrer ORDER BY c DESC LIMIT 20
");

$countries=$wpdb->get_results("
 SELECT country, COUNT(*) c
 FROM {$p}uampro_visits
 WHERE last_seen BETWEEN '$fd' AND '$td'
 GROUP BY country ORDER BY c DESC LIMIT 20
");

?>

<div class="chart-grid">

 <div class="chart-box">
   <h2>Daily Chart</h2>
   <canvas id="dailyChart"></canvas>
 </div>

 <div class="chart-box">
   <h2>Weekly Chart</h2>
   <canvas id="weeklyChart"></canvas>
 </div>

 <div class="chart-box">
   <h2>Monthly Chart</h2>
   <canvas id="monthlyChart"></canvas>
 </div>

 <div class="chart-box">
   <h2>Device Analytics</h2>
   <canvas id="deviceChart"></canvas>
 </div>

</div>

<h2>Top Pages</h2>
<table>
<tr><th>Page</th><th>Views</th></tr>
<?php foreach($top_pages as $p): ?>
<tr><td><?= $p->url ?></td><td><?= $p->c ?></td></tr>
<?php endforeach ?>
</table>

<h2>Top Referrers</h2>
<table>
<tr><th>Referrer</th><th>Hits</th></tr>
<?php foreach($refs as $r): ?>
<tr><td><?= $r->r ?: 'Direct' ?></td><td><?= $r->c ?></td></tr>
<?php endforeach ?>
</table>

<h2>Top Countries</h2>
<table>
<tr><th>Country</th><th>Visitors</th></tr>
<?php foreach($countries as $c): ?>
<tr><td><?= $c->country ?></td><td><?= $c->c ?></td></tr>
<?php endforeach ?>
</table>

<script>
new Chart(dailyChart,{
 type:"line",
 data:{
  labels:[<?= implode(',', array_map(fn($d)=>"'".$d->d."'",$daily)); ?>],
  datasets:[{label:"Daily",data:[<?= implode(',', array_map(fn($d)=>$d->c,$daily)); ?>],borderWidth:2}]
 }
});
new Chart(weeklyChart,{
 type:"bar",
 data:{
  labels:[<?= implode(',', array_map(fn($d)=>"'".$d->w."'",$weekly)); ?>],
  datasets:[{label:"Weekly",data:[<?= implode(',', array_map(fn($d)=>$d->c,$weekly)); ?>]}]
 }
});
new Chart(monthlyChart,{
 type:"line",
 data:{
  labels:[<?= implode(',', array_map(fn($d)=>"'".$d->m."'",$monthly)); ?>],
  datasets:[{label:"Monthly",data:[<?= implode(',', array_map(fn($d)=>$d->c,$monthly)); ?>],borderWidth:2}]
 }
});
new Chart(deviceChart,{
 type:"pie",
 data:{
  labels:[<?= implode(',', array_map(fn($d)=>"'".$d->d."'",$devices)); ?>],
  datasets:[{data:[<?= implode(',', array_map(fn($d)=>$d->c,$devices)); ?>]}]
 }
});
</script>

</div>
<?php
}
/* ========================================================
   10) EXPORT FUNCTIONS (CSV / JSON)
======================================================== */
function uampro_export_csv($filename, $rows){
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=$filename.csv");
    $out=fopen("php://output","w");
    foreach($rows as $r){
        fputcsv($out,(array)$r);
    }
    fclose($out);
    exit;
}

function uampro_export_json($filename,$rows){
    header("Content-Type: application/json");
    header("Content-Disposition: attachment; filename=$filename.json");
    echo json_encode($rows,JSON_PRETTY_PRINT);
    exit;
}

/* Export handler */
add_action("admin_post_uampro_export",function(){
    global $wpdb;
    $p=$wpdb->prefix;

    $type=$_GET["type"];
    $range=$_GET["range"] ?? "all";

    /* Range */
    if($range==="today"){
        $fd=date("Y-m-d")." 00:00:00";
        $td=date("Y-m-d")." 23:59:59";
    } else {
        $fd="1970-01-01 00:00:00";
        $td="2999-12-31 23:59:59";
    }

    if($type==="visitors"){
        $rows=$wpdb->get_results("SELECT * FROM {$p}uampro_visits WHERE last_seen BETWEEN '$fd' AND '$td'");
        uampro_export_json("visitors",$rows);
    }
    if($type==="pageviews"){
        $rows=$wpdb->get_results("SELECT * FROM {$p}uampro_pageviews WHERE viewed_at BETWEEN '$fd' AND '$td'");
        uampro_export_csv("pageviews",$rows);
    }
    if($type==="heatmap"){
        $rows=$wpdb->get_results("SELECT url,clicked_positions FROM {$p}uampro_pageviews WHERE clicked=1");
        uampro_export_json("heatmap-click",$rows);
    }
});


/* ========================================================
   11) ADVANCED UI SECTIONS (Heatmap, Flow, OS, Browser)
======================================================== */
add_action("admin_menu",function(){
    add_submenu_page(
        "uampro",
        "Advanced Analytics",
        "Advanced Analytics",
        "manage_options",
        "uampro-advanced",
        "uampro_advanced_ui"
    );
});

function uampro_advanced_ui(){
    global $wpdb;
    $p=$wpdb->prefix;

?>
<div class="wrap">
<h1>Advanced Analytics</h1>

<style>
 
.adv-chart-box {
    max-width: 450px;
    margin: 0 auto 40px auto;
    padding: 20px;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.08);
}

.adv-chart-box canvas {
    max-width: 450px;
    height: 260px;
    margin: 0 auto 40px auto;
    padding: 20px;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.08);
    display: flex;
    justify-content: center;
    align-items: center;
}

    
.sec-box{
 background:#fff;padding:20px;margin:25px 0;border-radius:12px;
 box-shadow:0 2px 10px rgba(0,0,0,0.07);
}
table{width:100%;border-collapse:collapse;margin-top:20px;}
th,td{padding:10px;border-bottom:1px solid #eee;}
th{background:#fafafa;text-align:left;}
</style>

<!-- ============================ -->
<!-- 1) NEW vs RETURNING          -->
<!-- ============================ -->
<div class="sec-box">
<h2>New vs Returning Users</h2>

<?php
$new_users=$wpdb->get_var("SELECT COUNT(*) FROM {$p}uampro_visits WHERE TIMESTAMPDIFF(DAY,first_seen,last_seen)=0");
$returning=$wpdb->get_var("SELECT COUNT(*) FROM {$p}uampro_visits WHERE TIMESTAMPDIFF(DAY,first_seen,last_seen)>0");
?>

<p><strong>New Visitors:</strong> <?= $new_users ?></p>
<p><strong>Returning Visitors:</strong> <?= $returning ?></p>
</div>


<!-- ============================ -->
<!-- 2) BROWSER CHART            -->
<!-- ============================ -->
<div class="sec-box">
<h2>Browser Analytics</h2>
<div class="adv-chart-box">
   <canvas id="browserChart"></canvas>
</div>
</div>


<!-- ============================ -->
<!-- 3) OS CHART                 -->
<!-- ============================ -->
<div class="sec-box">
<h2>Operating System Analytics</h2>
<div class="adv-chart-box">
   <canvas id="osChart"></canvas>
</div>
</div>


<?php
$browsers=$wpdb->get_results("SELECT browser b, COUNT(*) c FROM {$p}uampro_visits GROUP BY browser");
$os=$wpdb->get_results("SELECT os o, COUNT(*) c FROM {$p}uampro_visits GROUP BY os");
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(browserChart, {
    type: "pie",
    data: {
        labels: [<?= implode(",", array_map(fn($d)=>"'".$d->b."'", $browsers)); ?>],
        datasets: [{
            data: [<?= implode(",", array_map(fn($d)=>$d->c, $browsers)); ?>]
        }]
    },
    options: {
        responsive: false,
        maintainAspectRatio: false
    }
});


new Chart(osChart, {
    type: "pie",
    data: {
        labels: [<?= implode(",", array_map(fn($d)=>"'".$d->o."'", $os)); ?>],
        datasets: [{
            data: [<?= implode(",", array_map(fn($d)=>$d->c, $os)); ?>]
        }]
    },
    options: {
        responsive: false,
        maintainAspectRatio: false
    }
});


</script>


<!-- ============================ -->
<!-- 4) VISITOR FLOW TABLE       -->
<!-- ============================ -->
<div class="sec-box">
<h2>User Flow (Page Transitions)</h2>
<table>
<tr><th>From</th><th>To</th><th>When</th></tr>
<?php
$flow=$wpdb->get_results("SELECT * FROM {$p}uampro_flow ORDER BY moved_at DESC LIMIT 100");
foreach($flow as $f):
?>
<tr>
<td><?= $f->from_page ?></td>
<td><?= $f->to_page ?></td>
<td><?= $f->moved_at ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>


<!-- ============================ -->
<!-- 5) HEATMAP VIEWER (CLICK)   -->
<!-- ============================ -->
<div class="sec-box">
<h2>Click Heatmap (Raw Data)</h2>
<p>Your frontend heatmap JS can use this endpoint to visualize:</p>

<table>
<tr><th>URL</th><th>Click Points</th></tr>
<?php
$heat=$wpdb->get_results("SELECT url, clicked_positions FROM {$p}uampro_pageviews WHERE clicked=1 ORDER BY viewed_at DESC LIMIT 50");
foreach($heat as $h):
?>
<tr>
<td><?= $h->url ?></td>
<td><textarea style="width:100%;height:120px;"><?= $h->clicked_positions ?></textarea></td>
</tr>
<?php endforeach; ?>
</table>
</div>


<!-- ============================ -->
<!-- 6) EXIT PAGES               -->
<!-- ============================ -->
<div class="sec-box">
<h2>Top Exit Pages</h2>
<table>
<tr><th>Page</th><th>Exits</th></tr>
<?php
$exit=$wpdb->get_results("
 SELECT url, COUNT(*) c
 FROM {$p}uampro_pageviews
 WHERE time_spent < 5
 GROUP BY url ORDER BY c DESC LIMIT 20
");
foreach($exit as $e):
?>
<tr>
<td><?= $e->url ?></td>
<td><?= $e->c ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>

    
/* ========================================================
   CRON SCHEDULE (every 10 minutes)
======================================================== */
add_filter('cron_schedules', function($schedules){
    if(!isset($schedules['every_10_minutes'])){
        $schedules['every_10_minutes'] = [
            'interval' => 600, // 10 minutes
            'display'  => 'Every 10 Minutes'
        ];
    }
    return $schedules;
});

    
/* ========================================================
   REALTIME CLEANUP FUNCTION
======================================================== */
add_action('uampro_realtime_cleanup', function() {
    global $wpdb;
    $p = $wpdb->prefix;

    // remove sessions inactive for more than 2 minutes
    $wpdb->query("
        DELETE FROM {$p}uampro_realtime
        WHERE last_activity < (NOW() - INTERVAL 2 MINUTE)
    ");
});
    
    
    

<!-- ============================ -->
<!-- 7) EXPORT OPTIONS           -->
<!-- ============================ -->
<div class="sec-box">
<h2>Export Analytics</h2>

<a class="button button-primary" href="<?= admin_url('admin-post.php?action=uampro_export&type=visitors') ?>">Export Visitors (JSON)</a>
<a class="button button-secondary" href="<?= admin_url('admin-post.php?action=uampro_export&type=pageviews') ?>">Export Pageviews (CSV)</a>
<a class="button" href="<?= admin_url('admin-post.php?action=uampro_export&type=heatmap') ?>">Export Heatmap Clicks (JSON)</a>

</div>

</div>

<?php
}
