<?php
/**
 * Plugin Name: Movie Download Pro Ultimate
 * Plugin URI: https://yourwebsite.com
 * Description: Auto Clean URL + Neon Timer + 4-Step Download System + External Auto Open + Final Download UI + Admin Movie List + Advanced Security.
 * Version: 16.1
 * Author: You
 * License: GPL v2 or later
 * Text Domain: movie-download-pro
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MDP_VERSION', '16.1');
define('MDP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MDP_PLUGIN_URL', plugin_dir_url(__FILE__));



add_filter("tiny_mce_before_init", function($init){
    $init["extended_valid_elements"] = "*[*]";
    $init["valid_children"] = "+body[style|script],+div[style|script],+p[style|script]";
    return $init;
});

/**
 * Main Plugin Class
 */
class MovieDownloadProUltimate {
    
    private static $instance = null;
    private $session_key = 'mdp_secure_';
    private $cookie_name = 'mdp_download_';
    private $rate_limiter;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->ensure_session_table_columns(); 
        $this->init_hooks();
        $this->rate_limiter = new MDP_Rate_Limiter();
    }
    
    private function init_hooks() {
        // Plugin activation/deactivation
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
        
        // Initialize plugin
        add_action('init', [$this, 'init']);
        
        // Start session
        add_action('init', [$this, 'start_session'], 1);
        
        // Add security headers
        add_action('send_headers', [$this, 'add_security_headers']);
        
        // Admin hooks
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);
        add_action('save_post', [$this, 'save_post_meta']);
        add_action('admin_enqueue_scripts', [$this, 'admin_scripts']);
        
        // Frontend hooks
        add_filter('the_content', [$this, 'display_download_timer']);
        add_filter('query_vars', [$this, 'add_query_vars']);
        add_action('template_redirect', [$this, 'handle_step_pages']);
        
        // Add hits counter
        add_action('template_redirect', [$this, 'track_hits']);
        
        // Flush rules on plugin activation
        add_action('wp_loaded', [$this, 'flush_rewrite_rules']);
        
        // AJAX handlers
        add_action('wp_ajax_mdp_verify_step', [$this, 'ajax_verify_step']);
        add_action('wp_ajax_nopriv_mdp_verify_step', [$this, 'ajax_verify_step']);
        
        // Clean expired sessions
        add_action('wp', [$this, 'clean_expired_sessions']);
    }
    
    /**
     * Start session for tracking
     */
    public function start_session() {
        if (!session_id() && !headers_sent()) {
            session_start([
                'cookie_lifetime' => 86400, // 24 hours
                'cookie_secure'   => is_ssl(), // Auto-detect SSL
                'cookie_httponly' => true,
                'use_strict_mode' => true,
                'cookie_samesite' => 'Strict'
            ]);
        }
    }
    
    /**
     * Add security headers
     */
    public function add_security_headers() {
        if (!headers_sent()) {
            // Content Security Policy
            header("Content-Security-Policy: default-src * 'unsafe-inline' 'unsafe-eval' data: blob:; script-src * 'unsafe-inline' 'unsafe-eval' data: blob:; style-src * 'unsafe-inline'; img-src * data: blob:;");
            header("X-Content-Type-Options: nosniff");
            header("X-Frame-Options: DENY");
            header("X-XSS-Protection: 1; mode=block");
            header("Referrer-Policy: strict-origin-when-cross-origin");
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Set default options
        $this->set_default_options();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Create database table for sessions
        $this->create_sessions_table();
        $this->create_logs_table();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        $this->clean_all_sessions();
        flush_rewrite_rules();
    }
    
    /**
     * Create sessions table
     */
    private function create_sessions_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mdp_sessions';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            session_id varchar(64) NOT NULL,
            post_id bigint(20) NOT NULL,
            current_step tinyint(1) DEFAULT 1,
            completed_steps varchar(20) DEFAULT '',
            ip_address varchar(45),
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime,
            download_token varchar(255),
            token_expires_at datetime,
            PRIMARY KEY (session_id),
            KEY post_id (post_id),
            KEY expires_at (expires_at),
            KEY download_token (download_token(64))
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    private function ensure_session_table_columns() {
    global $wpdb;
    $table = $wpdb->prefix . 'mdp_sessions';

    // Get existing columns
    $columns = $wpdb->get_col("DESC $table", 0);

    // Add download_token column if missing
    if (!in_array('download_token', $columns)) {
        $wpdb->query("ALTER TABLE $table ADD download_token LONGTEXT NULL");
    }

    // Add token_expires_at column if missing
    if (!in_array('token_expires_at', $columns)) {
        $wpdb->query("ALTER TABLE $table ADD token_expires_at DATETIME NULL");
    }
}

    
    /**
     * Create logs table
     */
    private function create_logs_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mdp_security_logs';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            log_type varchar(50) NOT NULL,
            ip_address varchar(45),
            user_agent text,
            details text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY log_type (log_type),
            KEY ip_address (ip_address),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Log security event
     */
    private function log_security_event($event_type, $details) {
        global $wpdb;
        
        if (!get_option('mdp_enable_logging', true)) {
            return;
        }
        
        $table_name = $wpdb->prefix . 'mdp_security_logs';
        
        $wpdb->insert(
            $table_name,
            [
                'log_type' => sanitize_text_field($event_type),
                'ip_address' => $this->get_client_ip(),
                'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
                'details' => wp_json_encode($details)
            ],
            ['%s', '%s', '%s', '%s']
        );
    }
    
    /**
     * Clean all sessions
     */
    private function clean_all_sessions() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        $wpdb->query(
            $wpdb->prepare("DELETE FROM %i WHERE expires_at < NOW()", $table_name)
        );
    }
    
    /**
     * Set default options
     */
    private function set_default_options() {
        $defaults = [
            'mdp_s1_time' => 10,
            'mdp_s2_time' => 15,
            'mdp_s3_time' => 20,
            'mdp_s4_time' => 25,
            'mdp_s1' => '<h3>Step 1: Processing Your Request</h3>
<p>Please wait while we verify your download request. This step ensures that your download is secure and ready.</p>
<p>You are <strong>4 steps away</strong> from downloading your movie.</p>',
            'mdp_s2' => '<h3>Step 2: Preparing Your File</h3>
<p>Your movie file is being prepared for download. Please wait while we optimize the file for your device.</p>
<p>You are <strong>3 steps away</strong> from downloading your movie.</p>',
            'mdp_s3' => '<h3>Step 3: Finalizing Download</h3>
<p>Almost there! We are creating your download link and preparing the final file for you.</p>
<p>You are <strong>2 steps away</strong> from downloading your movie.</p>',
            'mdp_s4' => '<h3>Step 4: Download Ready!</h3>
<p>Congratulations! Your download is now ready. Click the download button below to get your movie.</p>
<p>You are <strong>1 step away</strong> from downloading your movie.</p>',
            'mdp_s1_link' => 'https://example.com/step1',
            'mdp_s2_link' => 'https://example.com/step2',
            'mdp_s3_link' => 'https://example.com/step3',
            'mdp_s4_link' => 'https://example.com/step4',
            'mdp_step_heading' => 'You are {steps} steps away from downloading your movie',
            'mdp_security_level' => 'high',
            'mdp_session_duration' => 3600,
            'mdp_enable_csrf' => true,
            'mdp_enable_rate_limit' => true,
            'mdp_enable_logging' => true,
            'mdp_download_token_expiry' => 300 // 5 minutes
        ];
        
        foreach ($defaults as $key => $value) {
            if (false === get_option($key)) {
                add_option($key, $value);
            }
        }
        
        update_option('mdp_flush_rewrite_rules', true);
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain
        load_plugin_textdomain('movie-download-pro', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Register rewrite rules
        $this->register_rewrite_rules();
    }
    
    /**
     * Register rewrite rules
     */
    private function register_rewrite_rules() {
        // Start download (creates session)
        add_rewrite_rule(
            '^movie-download/([0-9]+)/start/?$',
            'index.php?mdp_action=start&movie_id=$matches[1]',
            'top'
        );
        
        // Step pages (requires valid session)
        add_rewrite_rule(
            '^movie-download/([0-9]+)/step-([1-4])/?$',
            'index.php?mdp_action=step&movie_id=$matches[1]&step=$matches[2]',
            'top'
        );
        
        // Download endpoint with token
        add_rewrite_rule(
            '^movie-download/([0-9]+)/download/([a-zA-Z0-9_-]+)/?$',
            'index.php?mdp_action=download&movie_id=$matches[1]&token=$matches[2]',
            'top'
        );
    }
    
    /**
     * Add query variables
     */
    public function add_query_vars($vars) {
        $vars[] = 'mdp_action';
        $vars[] = 'movie_id';
        $vars[] = 'step';
        $vars[] = 'token';
        return $vars;
    }
    
    /**
     * Handle step pages with security validation
     */
    public function handle_step_pages() {
        $action = get_query_var('mdp_action');
        
        if (!$action) {
            return;
        }
        
        $post_id = intval(get_query_var('movie_id'));
        
        // Check rate limiting
        if (get_option('mdp_enable_rate_limit', true) && !$this->rate_limiter->check_limit()) {
            $this->log_security_event('rate_limit_exceeded', [
                'post_id' => $post_id,
                'action' => $action,
                'ip' => $this->get_client_ip()
            ]);
            $this->show_error_page(__('Too many requests. Please try again later.', 'movie-download-pro'));
            return;
        }
        
        // Validate post access
        if (!$this->validate_post_access($post_id)) {
            $this->log_security_event('unauthorized_access', [
                'post_id' => $post_id,
                'action' => $action,
                'ip' => $this->get_client_ip()
            ]);
            $this->show_error_page(__('Movie not found or access denied.', 'movie-download-pro'));
            return;
        }
        
        switch ($action) {
            case 'start':
                $this->start_download_process($post_id);
                break;
                
            case 'step':
                $step = intval(get_query_var('step'));
                $this->validate_and_show_step($post_id, $step);
                break;
                
            case 'download':
                $token = sanitize_text_field(get_query_var('token'));
                $this->handle_download($post_id, $token);
                break;
                
            default:
                $this->show_error_page(__('Invalid action.', 'movie-download-pro'));
                break;
        }
        
        exit;
    }
    
    /**
     * Validate post access
     */
    private function validate_post_access($post_id) {
        // Check if post exists and is published
        $post = get_post($post_id);
        if (!$post || $post->post_status !== 'publish') {
            return false;
        }
        
        // Check if download is enabled for this post
        $download_link = get_post_meta($post_id, 'mdp_download_link', true);
        if (empty($download_link)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Start download process (creates secure session)
     */
    private function start_download_process($post_id) {
        // Create secure session
        $session_id = $this->create_secure_session($post_id);
        
        // Set session cookie
        $this->set_session_cookie($session_id);
        
        // Store in database
        $this->store_session_in_db($session_id, $post_id);
        
        // Generate CSRF token
        $this->generate_csrf_token($session_id);
        
        // Log successful start
        $this->log_security_event('download_started', [
            'post_id' => $post_id,
            'session_id' => substr($session_id, 0, 16),
            'ip' => $this->get_client_ip()
        ]);
        
        // Redirect to step 1 with session
        $redirect_url = add_query_arg(['session' => $session_id], 
                         site_url("/movie-download/{$post_id}/step-1/"));
        wp_redirect($redirect_url);
        exit;
    }
    
    /**
     * Create secure session
     */
    private function create_secure_session($post_id) {
        // Generate cryptographically secure session ID
        $session_id = bin2hex(random_bytes(32));
        
        // Store in session
        $_SESSION[$this->session_key . $session_id] = [
            'post_id' => $post_id,
            'current_step' => 1,
            'completed_steps' => [1 => false, 2 => false, 3 => false, 4 => false],
            'created_at' => time(),
            'ip_address' => $this->get_client_ip(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'last_activity' => time()
        ];
        
        return $session_id;
    }
    
    /**
     * Generate CSRF token
     */
    private function generate_csrf_token($session_id) {
        if (get_option('mdp_enable_csrf', true)) {
            $csrf_token = bin2hex(random_bytes(32));
            $_SESSION['mdp_csrf_' . $session_id] = [
                'token' => $csrf_token,
                'expires' => time() + 3600 // 1 hour
            ];
            return $csrf_token;
        }
        return '';
    }
    
    /**
     * Validate CSRF token
     */
    private function validate_csrf_token($session_id, $token) {
        if (!get_option('mdp_enable_csrf', true)) {
            return true;
        }
        
        if (!isset($_SESSION['mdp_csrf_' . $session_id])) {
            return false;
        }
        
        $csrf_data = $_SESSION['mdp_csrf_' . $session_id];
        
        // Check expiry
        if (time() > $csrf_data['expires']) {
            unset($_SESSION['mdp_csrf_' . $session_id]);
            return false;
        }
        
        // Compare tokens
        return hash_equals($csrf_data['token'], $token);
    }
    
    /**
     * Set session cookie
     */
    private function set_session_cookie($session_id) {
        $cookie_name = $this->cookie_name . COOKIEHASH;
        $expiry = time() + get_option('mdp_session_duration', 3600);
        
        // Generate signature for additional security
        $signature = hash_hmac('sha256', $session_id . $expiry, AUTH_KEY);
        
        setcookie(
            $cookie_name,
            $session_id . '|' . $expiry . '|' . $signature,
            [
                'expires' => $expiry,
                'path' => '/',
                'domain' => COOKIE_DOMAIN,
                'secure' => is_ssl(),
                'httponly' => true,
                'samesite' => 'Strict'
            ]
        );
    }
    
    /**
     * Store session in database
     */
    private function store_session_in_db($session_id, $post_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        $expires_at = date('Y-m-d H:i:s', time() + get_option('mdp_session_duration', 3600));
        
        $wpdb->insert(
            $table_name,
            [
                'session_id' => $session_id,
                'post_id' => $post_id,
                'current_step' => 1,
                'ip_address' => $this->get_client_ip(),
                'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
                'expires_at' => $expires_at
            ],
            ['%s', '%d', '%d', '%s', '%s', '%s']
        );
    }
    
    /**
     * Validate and show step
     */
    private function validate_and_show_step($post_id, $requested_step) {
        // Validate step number
        if ($requested_step < 1 || $requested_step > 4) {
            $this->show_error_page(__('Invalid step number.', 'movie-download-pro'));
            return;
        }
        
        // Get session ID from cookie or URL
        $session_id = $this->get_valid_session_id();
        if (!$session_id) {
            $this->show_error_page(__('Session expired or invalid. Please start over.', 'movie-download-pro'));
            return;
        }
        
        // Verify session from database
        if (!$this->verify_session_from_db($session_id, $post_id)) {
            $this->log_security_event('invalid_session', [
                'post_id' => $post_id,
                'session_id' => substr($session_id, 0, 16),
                'step' => $requested_step,
                'ip' => $this->get_client_ip()
            ]);
            $this->show_error_page(__('Invalid session. Please start over.', 'movie-download-pro'));
            return;
        }
        
        // Get current allowed step from session
        $allowed_step = $this->get_allowed_step($session_id);
        
        // Check if user can access requested step
        
        $allowed_step = (int) $this->get_allowed_step($session_id);

// Hard sync (force refresh)
if ($allowed_step < $requested_step - 1) {
    $this->show_error_page("Please complete step " . ($requested_step - 1) . " first.");
    exit;
}
        
        // If accessing a previous step, update current step
        if ($requested_step < $allowed_step) {
            $this->update_current_step($session_id, $requested_step);
        }
        
        // Update last activity
        $this->update_last_activity($session_id);
        
        // Display the step
        $this->display_step_page($post_id, $requested_step, $session_id);
    }
    
    /**
     * Get valid session ID
     */
    private function get_valid_session_id() {
        // Check cookie first
        $cookie_name = $this->cookie_name . COOKIEHASH;
        if (isset($_COOKIE[$cookie_name])) {
            $cookie_data = sanitize_text_field($_COOKIE[$cookie_name]);
            $parts = explode('|', $cookie_data);
            
            if (count($parts) === 3) {
                list($session_id, $expiry, $signature) = $parts;
                
                // Validate signature
                $expected = hash_hmac('sha256', $session_id . $expiry, AUTH_KEY);
                if (hash_equals($expected, $signature) && time() < $expiry) {
                    return $session_id;
                }
            }
        }
             
        return false;
    }
    
    /**
     * Validate session ID format
     */
    private function validate_session_id($session_id) {
        return preg_match('/^[a-f0-9]{64}$/', $session_id);
    }
    
    /**
     * Verify session from database
     */
    private function verify_session_from_db($session_id, $post_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name 
             WHERE session_id = %s 
             AND post_id = %d 
             AND expires_at > NOW()",
            $session_id,
            $post_id
        ));
        
        return $result !== null;
    }
    
    /**
     * Get allowed step from session
     */
    private function get_allowed_step($session_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT current_step FROM $table_name WHERE session_id = %s",
            $session_id
        ));
        
        return $result ? intval($result) : 1;
    }
    
    /**
     * Update current step in database
     */
    private function update_current_step($session_id, $step) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        $wpdb->update(
            $table_name,
            ['current_step' => $step],
            ['session_id' => $session_id],
            ['%d'],
            ['%s']
        );
    }
    
    /**
     * Update last activity
     */
    private function update_last_activity($session_id) {
        if (isset($_SESSION[$this->session_key . $session_id])) {
            $_SESSION[$this->session_key . $session_id]['last_activity'] = time();
        }
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        }
        
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
    }
    
    /**
     * Generate download token
     */
    private function generate_download_token($session_id, $post_id) {
        $expiry = time() + get_option('mdp_download_token_expiry', 300); // 5 minutes
        $data = $session_id . '|' . $post_id . '|' . $expiry;
        $signature = hash_hmac('sha256', $data, AUTH_KEY);
        
        $token = base64_encode($data . '|' . $signature);
        
        // Store in database
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        $token_expires = date('Y-m-d H:i:s', $expiry);
        
        $wpdb->update(
            $table_name,
            [
                'download_token' => $token,
                'token_expires_at' => $token_expires
            ],
            ['session_id' => $session_id],
            ['%s', '%s'],
            ['%s']
        );
        
        return $token;
    }
    
    /**
     * Validate download token
     */
    private function validate_download_token($token, $post_id) {
        $decoded = base64_decode($token);
        if (!$decoded) {
            return false;
        }
        
        $parts = explode('|', $decoded);
        if (count($parts) !== 4) {
            return false;
        }
        
        list($session_id, $token_post_id, $expiry, $signature) = $parts;
        
        // Check expiry
        if (time() > $expiry) {
            return false;
        }
        
        // Check post ID matches
        if ($token_post_id != $post_id) {
            return false;
        }
        
        // Verify signature
        $data = $session_id . '|' . $post_id . '|' . $expiry;
        $expected = hash_hmac('sha256', $data, AUTH_KEY);
        
        if (!hash_equals($expected, $signature)) {
            return false;
        }
        
        // Verify from database
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name 
             WHERE session_id = %s 
             AND post_id = %d 
             AND download_token = %s 
             AND token_expires_at > NOW()",
            $session_id,
            $post_id,
            $token
        ));
        
        return $result > 0;
    }
    
    /**
     * Handle download with token
     */
    private function handle_download($post_id, $token) {
        if (!$this->validate_download_token($token, $post_id)) {
            $this->log_security_event('invalid_download_token', [
                'post_id' => $post_id,
                'token' => substr($token, 0, 50),
                'ip' => $this->get_client_ip()
            ]);
            $this->show_error_page(__('Invalid or expired download link.', 'movie-download-pro'));
            return;
        }
        
        $download_link = get_post_meta($post_id, 'mdp_download_link', true);
        
        if (empty($download_link)) {
            $this->show_error_page(__('Download link not found.', 'movie-download-pro'));
            return;
        }
        
        // Log successful download
        $this->log_security_event('download_completed', [
            'post_id' => $post_id,
            'ip' => $this->get_client_ip()
        ]);
        
        // Redirect to download link
        wp_redirect($download_link);
        exit;
    }
    
    /**
     * Track download hits
     */
    public function track_hits() {
        if (get_query_var('mdp_action') === 'step' && get_query_var('step') == 4) {
            $post_id = intval(get_query_var('movie_id'));
            
            if ($post_id > 0) {
                $current_hits = get_post_meta($post_id, 'mdp_hits', true);
                $current_hits = $current_hits ? intval($current_hits) + 1 : 1;
                update_post_meta($post_id, 'mdp_hits', $current_hits);
            }
        }
    }
    
    /**
     * Clean expired sessions
     */
    public function clean_expired_sessions() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        // Clean sessions older than 24 hours
        $wpdb->query(
            $wpdb->prepare("DELETE FROM %i WHERE expires_at < DATE_SUB(NOW(), INTERVAL 1 DAY)", $table_name)
        );
        
        // Clean old logs (keep 30 days)
        $logs_table = $wpdb->prefix . 'mdp_security_logs';
        $wpdb->query(
            $wpdb->prepare("DELETE FROM %i WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)", $logs_table)
        );
    }
    
    /**
     * AJAX verify step
     */
    public function ajax_verify_step() {
        // Verify nonce
        if (!check_ajax_referer('mdp_ajax_nonce', 'security', false)) {
            wp_send_json_error('Invalid nonce');
        }
        
        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        $post_id = intval($_POST['post_id'] ?? 0);
        $step = intval($_POST['step'] ?? 0);
        $csrf_token = sanitize_text_field($_POST['csrf_token'] ?? '');
        
 
    
    // Validate CSRF token
    if (!$this->validate_csrf_token($session_id, $csrf_token)) {
        wp_send_json_error('Invalid CSRF token');
    }
    
       
        if (!$this->validate_session_id($session_id) || $step < 1 || $step > 4) {
           wp_send_json_error('Invalid parameters');
        }
        
        // Update step completion in database
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_sessions';
        
        // Get current completed steps
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT completed_steps FROM $table_name WHERE session_id = %s",
            $session_id
        ));
        
$completed_steps = [];

if (!empty($result)) {
    $parts = explode(',', $result);
    foreach ($parts as $p) {
        if (ctype_digit($p)) {
            $completed_steps[] = intval($p);
        }
    }
}

        
        // Add current step if not already completed
        if (!in_array($step, $completed_steps)) {
            $completed_steps[] = $step;
            $completed_steps_str = implode(',', $completed_steps);
            
            // Update database
            $wpdb->update(
                $table_name,
                [
                    'completed_steps' => $completed_steps_str,
                    'current_step' => $step + 1
                ],
                ['session_id' => $session_id],
                ['%s', '%d'],
                ['%s']
            );
        }
        
        // If this is step 4, generate download token
        $download_token = '';
        if ($step == 4) {
            $download_token = $this->generate_download_token($session_id, $post_id);
        }
        
wp_send_json([
    'status' => 'success',
    'download_token' => $download_token,
    'next_step' => $step + 1
]);

    }
    
    /**
     * Show error page
     */
    private function show_error_page($message) {
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php _e('Error - Movie Download', 'movie-download-pro'); ?></title>
            <style>
                body { 
                    background: #0d0d0d; 
                    color: white; 
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                    display: flex; 
                    align-items: center; 
                    justify-content: center; 
                    height: 100vh; 
                    margin: 0; 
                    text-align: center; 
                    padding: 20px; 
                }
                .error-container { 
                    max-width: 600px; 
                    width: 100%; 
                }
                .error-box { 
                    background: rgba(255, 68, 68, 0.1); 
                    border: 2px solid #ff4444; 
                    padding: 40px; 
                    border-radius: 15px; 
                    margin-bottom: 20px; 
                }
                h1 { 
                    color: #ff4444; 
                    margin-bottom: 20px; 
                    font-size: 32px; 
                }
                p { 
                    font-size: 18px; 
                    line-height: 1.6; 
                    margin-bottom: 20px; 
                }
                .btn { 
                    display: inline-block; 
                    background: linear-gradient(90deg, #00ff99, #00eaff); 
                    color: black; 
                    padding: 15px 40px; 
                    text-decoration: none; 
                    border-radius: 8px; 
                    font-weight: bold; 
                    font-size: 18px; 
                    transition: all 0.3s ease; 
                }
                .btn:hover { 
                    transform: translateY(-2px); 
                    box-shadow: 0 5px 15px rgba(0, 255, 153, 0.4); 
                }
                .security-info { 
                    background: rgba(0, 255, 153, 0.1); 
                    border: 1px solid rgba(0, 255, 153, 0.3); 
                    padding: 15px; 
                    border-radius: 10px; 
                    margin-top: 20px; 
                    color: #00ff99; 
                    font-size: 14px; 
                }
            </style>
        </head>
        <body>
            <div class="error-container">
                <div class="error-box">
                    <h1>🔒 <?php _e('Access Restricted', 'movie-download-pro'); ?></h1>
                    <p><?php echo esc_html($message); ?></p>
                    <p><?php _e('Please follow the download process step by step.', 'movie-download-pro'); ?></p>
                </div>
                
                <a href="<?php echo home_url(); ?>" class="btn">
                    <?php _e('← Return to Homepage', 'movie-download-pro'); ?>
                </a>
                
                <div class="security-info">
                    🔐 <?php _e('For security reasons, you cannot skip steps in the download process.', 'movie-download-pro'); ?>
                </div>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
    
    /**
     * Flush rewrite rules if needed
     */
    public function flush_rewrite_rules() {
        if (get_option('mdp_flush_rewrite_rules')) {
            delete_option('mdp_flush_rewrite_rules');
            flush_rewrite_rules();
        }
    }
    
    /**
     * Display download timer on single posts
     */
    public function display_download_timer($content) {
        if (!is_singular('post')) {
            return $content;
        }
        
        global $post;
        $post_id = $post->ID;
        $timer = get_post_meta($post_id, 'mdp_main_timer', true);
        
        if (empty($timer)) {
            return $content;
        }
        
        $start_url = site_url("/movie-download/{$post_id}/start/");
        
        ob_start();
        ?>
        <div id="mdp-download-section" style="margin: 40px 0; padding: 30px; background: linear-gradient(135deg, #0d0d0d 0%, #1a1a1a 100%); border-radius: 15px; border: 2px solid #00ff99; box-shadow: 0 0 30px rgba(0, 255, 153, 0.3); text-align: center; color: white;">
            <h2 style="color: #00ff99; margin-bottom: 20px; font-size: 28px;">🎬 <?php _e('Download This Movie', 'movie-download-pro'); ?></h2>
            
            <p style="font-size: 18px; margin-bottom: 25px; color: #ddd;">
                <?php _e('Click the button below to start the secure 4-step download process after the timer ends', 'movie-download-pro'); ?>
            </p>
            
            <div style="margin: 30px 0;">
                <div id="mdp-timer-circle" style="width: 160px; height: 160px; border-radius: 50%; border: 10px solid #00ff99; box-shadow: 0 0 25px #00ff99, inset 0 0 25px rgba(0, 255, 153, 0.3); display: inline-flex; align-items: center; justify-content: center; font-size: 48px; font-weight: bold; color: #00ff99; background: rgba(0, 0, 0, 0.5); margin: 0 auto; animation: pulse 2s infinite;">
                    <?php echo esc_html($timer); ?>
                </div>
            </div>
            

            
            <br>
            
            <a href="<?php echo esc_url($start_url); ?>" id="mdp-download-btn" 
               style="display: inline-block; padding: 18px 50px; background: linear-gradient(90deg, #00ff99, #00eaff); border: none; border-radius: 10px; font-size: 22px; font-weight: bold; color: #000; text-decoration: none; margin-top: 20px; cursor: pointer; opacity: 0.4; pointer-events: none; transition: all 0.3s ease;">
               🚀 <?php _e('Start Secure Download Process', 'movie-download-pro'); ?>
            </a>
        </div>
        
        <style>
            @keyframes pulse {
                0% { box-shadow: 0 0 25px #00ff99, inset 0 0 25px rgba(0, 255, 153, 0.3); }
                50% { box-shadow: 0 0 35px #00ff99, inset 0 0 35px rgba(0, 255, 153, 0.5); }
                100% { box-shadow: 0 0 25px #00ff99, inset 0 0 25px rgba(0, 255, 153, 0.3); }
            }
        </style>
        
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            var timer = <?php echo intval($timer); ?>;
            var timerElement = document.getElementById("mdp-timer-circle");
            var button = document.getElementById("mdp-download-btn");
            
            if (timer > 0) {
                var countdown = setInterval(function() {
                    timer--;
                    timerElement.textContent = timer;
                    
                    if (timer <= 0) {
                        clearInterval(countdown);
                        button.style.opacity = "1";
                        button.style.pointerEvents = "auto";
                        button.style.boxShadow = "0 5px 15px rgba(0, 255, 153, 0.4)";
                        timerElement.style.animation = "none";
                        timerElement.style.borderColor = "#00eaff";
                        timerElement.style.boxShadow = "0 0 25px #00eaff, inset 0 0 25px rgba(0, 234, 255, 0.3)";
                    }
                }, 1000);
            } else {
                button.style.opacity = "1";
                button.style.pointerEvents = "auto";
            }
        });
        </script>
        <?php
        return $content . ob_get_clean();
    }
    
    /**
     * Display step page
     */
    private function display_step_page($post_id, $step, $session_id) {
        $post = get_post($post_id);
        if (!$post) {
            $this->show_error_page(__('Movie not found.', 'movie-download-pro'));
            return;
        }
        
        // Get step data
        $content = get_option("mdp_s{$step}", '');
        $time = intval(get_option("mdp_s{$step}_time", 10));
        $external_link = esc_url(get_option("mdp_s{$step}_link", ''));
        
        // Get step heading template
        $step_heading = get_option('mdp_step_heading', 'You are {steps} steps away from downloading your movie');
        $steps_remaining = 4 - $step;
        $heading_text = str_replace('{steps}', $steps_remaining, $step_heading);
        
        // Get next URL
        $next_url = '';
        if ($step < 4) {
            $next_url = add_query_arg(['session' => $session_id], 
                         site_url("/movie-download/{$post_id}/step-" . ($step + 1) . "/"));
        }
        
         
        // Use existing CSRF token instead of regenerating
$csrf_session_key = 'mdp_csrf_' . $session_id;

// Always refresh CSRF token on step 4 (fix)
if ($step == 4) {
    $csrf_token = $this->generate_csrf_token($session_id);
} else {
    if (isset($_SESSION[$csrf_session_key])) {
        $csrf_token = $_SESSION[$csrf_session_key]['token'] ?? '';
    } else {
        $csrf_token = $this->generate_csrf_token($session_id);
    }
}



        
        // Display the step page
        $this->render_step_page_html($post_id, $step, $content, $time, $external_link, 
                                    $next_url, $post->post_title, $session_id, $heading_text, $csrf_token);
    }
    
    /**
     * Render step page HTML (Fixed for proper HTML/CSS/JS display)
     */
    private function render_step_page_html($post_id, $step, $content, $time, $external_link, 
                                          $next_url, $movie_title, $session_id, $heading_text, $csrf_token) {
        // Clean content
        $content = stripslashes($content);
        
        
        // Add steps remaining message to content
        $steps_message = '<div class="steps-remaining" style="background: rgba(0, 255, 153, 0.1); padding: 15px; border-radius: 10px; margin: 20px 0; color: #00ff99;">';
        $steps_message .= '<strong>' . esc_html($heading_text) . '</strong>';
        $steps_message .= '</div>';
             
        // AJAX nonce for step verification
        $ajax_nonce = wp_create_nonce('mdp_ajax_nonce');
        
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php printf(__('Step %d - %s', 'movie-download-pro'), $step, $movie_title); ?></title>
            
            <style>
            /* Reset and Base Styles */
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                background: linear-gradient(135deg, #0a0a0a 0%, #151515 100%);
                color:  #ffffff !important;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padd ing: 20px;
                line-height: 1.6;
               }
                         
           
           
            
            .container {
                max-width: 900px;
                width: 100%;
                background: rgba(255, 255, 255, 0.03);
                border-radius: 20px;
                padding: 40px;
                margin : 20px 0px 10px 0px;
                border: 2px solid rgba(0, 255, 153, 0.2);
                box-shadow: 0 15px 40px rgba(0, 0, 0, 0.7);
                backdrop-filter: blur(10px);
                position: relative;
                overflow: hidden;
              }
            
                
                @media (max-width: 600px) {
    .container {
        margin: 5 !important;
        width: 100% !important;
        max-width: 100% !important;
        border-radius: 10 !important;
        padding-left: 10px !important;
        padding-right: 10px !important;

    }
}

                
                
                .steps-remaining strong {
                 font-size: 24px !important;
                 font-weight: 700 !important;
                 color: #00ffcc !important;
                 text-shadow: 0 0 10px rgba(0,255,204,0.5);
             }
                
                
                
                
            /* Security Header */
            .security-header {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                background: linear-gradient(90deg, rgba(0, 255, 153, 0.2), rgba(0, 234, 255, 0.2));
                padding: 0px 20px;
                text-align: center;
                font-size: 14px;
                color: #00ff99;
                border-bottom: 1px solid rgba(0, 255, 153, 0.3);
            }
            
            .security-header span {
                display: inline-flex;
                align-items: center;
                gap: 8px;
            }
            
            /* Main Header */
            .main-header {
                text-align: center;
                margin: 40px 0 30px 0;
            }
            
            .main-header h1 {
                color: #00ff99;
                font-size: 30px;
                margin-top: 70px; 
                margin-bottom: 10px;
                background: linear-gradient(90deg, #00ff99, #00eaff);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                text-shadow: 0 0 20px rgba(0, 255, 153, 0.3);
            }
            
                
                
                @media (max-width: 600px) {
                .main-header h1 {
                
                 font-size: 20px;
                 margin-top: 130px; 
                 } }
                
                
                
            .movie-title {
                color: #00eaff;
                font-size: 22px;
                opacity: 0.9;
                font-weight: 500;
            }
            
            /* Progress Bar */
            .progress-container {
                margin: 40px 0;
            }
            
            .progress-steps {
                display: flex;
                justify-content: space-between;
                position: relative;
                margin-bottom: 10px;
            }
            
            .progress-steps:before {
                content: '';
                position: absolute;
                top: 24px;
                left: 0;
                right: 0;
                height: 4px;
                background: rgba(255, 255, 255, 0.1);
                z-index: 1;
            }
            
            .progress-line {
                position: absolute;
                top: 24px;
                left: 0;
                height: 4px;
                background: linear-gradient(90deg, #00ff99, #00eaff);
                width: <?php echo (($step - 1) / 3 * 100); ?>%;
                z-index: 2;
                transition: width 0.5s ease;
            }
            
            .step-indicator {
                position: relative;
                z-index: 3;
                text-align: center;
                flex: 1;
            }
            
            .step-circle {
                width: 48px;
                height: 48px;
                border-radius: 50%;
                background: <?php echo ($step >= 1) ? 'linear-gradient(135deg, #00ff99, #00eaff)' : 'rgba(255, 255, 255, 0.1)'; ?>;
                color: <?php echo ($step >= 1) ? '#000' : 'rgba(255, 255, 255, 0.5)'; ?>;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 10px;
                font-weight: bold;
                font-size: 20px;
                border: 3px solid <?php echo ($step >= 1) ? '#00ff99' : 'transparent'; ?>;
                box-shadow: <?php echo ($step >= 1) ? '0 0 15px rgba(0, 255, 153, 0.5)' : 'none'; ?>;
                transition: all 0.3s ease;
            }
            
            .step-label {
                font-size: 14px;
                color: <?php echo ($step >= 1) ? '#00ff99' : 'rgba(255, 255, 255, 0.5)'; ?>;
                font-weight: <?php echo ($step >= 1) ? '600' : '400'; ?>;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            
            /* Timer */
            .timer-container {
                text-align: center;
                margin: 40px 0;
            }
            
            .timer-circle {
                width: 200px;
                height: 200px;
                border-radius: 50%;
                border: 15px solid #00ff99;
                box-shadow: 0 0 40px #00ff99, inset 0 0 40px rgba(0, 255, 153, 0.3);
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font-size: 64px;
                font-weight: bold;
                color: #00ff99;
                margin: 0 auto;
                background: rgba(0, 0, 0, 0.7);
                animation: timerPulse 2s infinite;
            }
            
            @keyframes timerPulse {
                0% { 
                    box-shadow: 0 0 40px #00ff99, inset 0 0 40px rgba(0, 255, 153, 0.3);
                    border-color: #00ff99;
                }
                50% { 
                    box-shadow: 0 0 60px #00ff99, inset 0 0 60px rgba(0, 255, 153, 0.5);
                    border-color: #00eaff;
                }
                100% { 
                    box-shadow: 0 0 40px #00ff99, inset 0 0 40px rgba(0, 255, 153, 0.3);
                    border-color: #00ff99;
                }
            }
            
            .timer-label {
                margin-top: 15px;
                color: #00eaff;
                font-size: 14px;
                text-transform: uppercase;
                letter-spacing: 2px;
            }
            
            /* Content Box */
            .content-box {
                background: rgba(255, 255, 255, 0.05);
                border-radius: 15px;
                padding: 40px;
                margin: 40px 0;
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            
            .content-box h1,
            .content-box h2,
            .content-box h3,
            .content-box h4,
            .content-box h5,
            .content-box h6 {
                color: #00ff99;
                margin-bottom: 20px;
                line-height: 1.3;
            }
            
            .content-box h1 { font-size: 32px; }
            .content-box h2 { font-size: 28px; }
            .content-box h3 { font-size: 24px; }
            .content-box h4 { font-size: 20px; }
            
            .content-box p {
                font-size: 18px;
                margin-bottom: 20px;
                color: #ddd;
            }
            
            .content-box ul,
            .content-box ol {
                margin-left: 20px;
                margin-bottom: 20px;
                color: #ddd;
            }
            
            .content-box li {
                margin-bottom: 10px;
                font-size: 17px;
            }
            
            .content-box strong {
                color: #00ff99;
            }
            
            .content-box em {
                color: #00eaff;
            }
            
            .content-box a {
                color: #00ff99;
                text-decoration: none;
                border-bottom: 1px dotted #00ff99;
                transition: all 0.3s ease;
            }
            
            .content-box a:hover {
                color: #00eaff;
                border-bottom: 1px solid #00eaff;
            }
            
            .content-box img {
                max-width: 100%;
                height: auto;
                border-radius: 10px;
                margin: 20px 0;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            }
            
            .content-box pre,
            .content-box code {
                background: rgba(0, 0, 0, 0.5);
                border: 1px solid rgba(0, 255, 153, 0.3);
                border-radius: 5px;
                padding: 15px;
                margin: 20px 0;
                overflow-x: auto;
                font-family: 'Courier New', monospace;
                color: #00ff99;
            }
            
            .content-box blockquote {
                border-left: 4px solid #00ff99;
                padding-left: 20px;
                margin: 20px 0;
                font-style: italic;
                color: #aaa;
            }
                
               @media (max-width: 600px) {
    .content-box {
        padding: 1px 2px !important;
        margin: 0 !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
}
 
            
            /* Buttons */
            .button-container {
                text-align: center;
                margin-top: 40px;
            }
            
            .next-btn {
                padding: 20px 50px;
                background: linear-gradient(90deg, #00ff99, #00eaff);
                border: none;
                border-radius: 12px;
                font-size: 22px;
                font-weight: bold;
                color: #000;
                text-decoration: none;
                cursor: pointer;
                transition: all 0.3s ease;
                display: inline-block;
                opacity: 0.4;
                pointer-events: none;
                position: relative;
                overflow: hidden;
            }
            
            .next-btn:after {
                content: "";
                position: absolute;
                top: -50%;
                left: -60%;
                width: 40px;
                height: 200%;
                background: rgba(255, 255, 255, 0.3);
                transform: rotate(30deg);
                transition: all 0.6s;
            }
            
            .next-btn.active {
                opacity: 1;
                pointer-events: auto;
            }
            
            .next-btn.active:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 25px rgba(0, 255, 153, 0.5);
            }
            
            .next-btn.active:hover:after {
                left: 120%;
            }
            
            /* Download Box */
            .download-box {
                background: linear-gradient(135deg, rgba(0, 255, 153, 0.1), rgba(0, 234, 255, 0.1));
                border-radius: 15px;
                padding: 50px;
                text-align: center;
                margin-top: 40px;
                border: 2px solid #00ff99;
                box-shadow: 0 10px 30px rgba(0, 255, 153, 0.2);
            }
            
            .download-box h2 {
                color: #00ff99;
                margin-bottom: 25px;
                font-size: 36px;
                text-shadow: 0 0 15px rgba(0, 255, 153, 0.5);
            }
            
            .download-box p {
                font-size: 20px;
                margin-bottom: 30px;
                color: #ddd;
                line-height: 1.6;
            }
            
            .download-btn {
                padding: 20px 60px;
                background: linear-gradient(90deg, #00ff99, #00eaff);
                border: none;
                border-radius: 12px;
                font-size: 26px;
                font-weight: bold;
                color: #000;
                text-decoration: none;
                display: inline-block;
                margin-top: 10px;
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
                opacity: 0.4;
                pointer-events: none;
                cursor: not-allowed;
            }
            
            .download-btn:after {
                content: "";
                position: absolute;
                top: -50%;
                left: -60%;
                width: 40px;
                height: 200%;
                background: rgba(255, 255, 255, 0.3);
                transform: rotate(30deg);
                transition: all 0.6s;
            }
            
            .download-btn.active {
                opacity: 1;
                pointer-events: auto;
                cursor: pointer;
            }
            
            .download-btn.active:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 25px rgba(0, 255, 153, 0.5);
            }
            
            .download-btn.active:hover:after {
                left: 120%;
            }
            
            /* Notices */
            .external-notice {
                background: rgba(255, 215, 0, 0.1);
                border: 1px solid rgba(255, 215, 0, 0.3);
                border-radius: 10px;
                padding: 15px;
                margin-top: 20px;
                color: #ffd700;
                font-size: 14px;
                text-align: center;
            }
            
            .session-info {
                background: rgba(0, 255, 153, 0.05);
                border: 1px solid rgba(0, 255, 153, 0.2);
                border-radius: 10px;
                padding: 10px 15px;
                margin-top: 15px;
                color: #00ff99;
                font-size: 12px;
                text-align: center;
            }
            
            /* Responsive */
            @media (max-width: 768px) {
                .container {
                    padding: 25px 15px;
                    margin: 10px;
                }
                
                .main-header h1 {
                    font-size: 32px;
                }
                
                .timer-circle {
                    width: 150px;
                    height: 150px;
                    font-size: 48px;
                    border-width: 10px;
                }
                
                .step-circle {
                    width: 36px;
                    height: 36px;
                    font-size: 16px;
                }
                
                .content-box {
                    padding: 25px;
                }
                
                .next-btn, .download-btn {
                    padding: 15px 30px;
                    font-size: 18px;
                    width: 100%;
                    max-width: 300px;
                }
                
                .download-box {
                    padding: 30px 20px;
                }
                
                .download-box h2 {
                    font-size: 28px;
                }
            }
            
            @media (max-width: 480px) {
                .progress-steps:before {
                    top: 18px;
                }
                
                .progress-line {
                    top: 18px;
                }
                
                .step-circle {
                    width: 32px;
                    height: 32px;
                    font-size: 14px;
                }
                
                .step-label {
                    font-size: 11px;
                }
                
                .timer-circle {
                    width: 120px;
                    height: 120px;
                    font-size: 36px;
                }
                
                .content-box h3 {
                    font-size: 20px;
                }
                
                .content-box p {
                    font-size: 16px;
                }
            }
            </style>
        </head>
        <body>
            <div class="container">
                <!-- Security Header -->
                <div class="security-header">
 <?php echo $steps_message; ?>
                </div>
                
               

                
                <!-- Main Header -->
                <div class="main-header">
                    <h1><?php printf(__('Step %d of 4', 'movie-download-pro'), $step); ?></h1>
                    <div class="movie-title"><?php echo esc_html($movie_title); ?></div>
                </div>
                
                <!-- Progress Bar -->
                <div class="progress-container">
                    <div class="progress-steps">
                        <div class="progress-line"></div>
                        <?php for ($i = 1; $i <= 4; $i++): ?>
                            <div class="step-indicator">
                                <div class="step-circle">
                                    <?php echo $i; ?>
                                </div>
                                <div class="step-label">
                                    <?php printf(__('Step %d', 'movie-download-pro'), $i); ?>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
                
                <!-- Timer -->
                <div class="timer-container">
                    <div class="timer-circle" id="stepTimer">
                        <?php echo $time; ?>
                    </div>
                    <div class="timer-label"><?php _e('Seconds Remaining', 'movie-download-pro'); ?></div>
                </div>
                
                <!-- Content -->
                <div class="content-box" id="stepContent">
                    <?php echo $content; ?>
                </div>
                
                <!-- Hidden CSRF Token -->
                <input type="hidden" id="csrf_token" value="<?php echo esc_attr($csrf_token); ?>">
                
                <?php if ($step < 4): ?>
                    <!-- Next Step Button -->
                    <div class="button-container">
                        <a href="<?php echo esc_url($next_url); ?>" 
                           class="next-btn" 
                           id="nextStepBtn">
                           <?php printf(__('Continue to Step %d →', 'movie-download-pro'), $step + 1); ?>
                        </a>
                        
                        <?php if (!empty($external_link)): ?>
                        <div class="external-notice">
                            ⚠️ <?php _e('An external link will open automatically when timer ends', 'movie-download-pro'); ?>
                        </div>
                        <?php endif; ?>
                        
                    </div>
                <?php else: ?>
                    <!-- Final Download -->
                    <div class="download-box">
                        <h2><?php _e('Your Download Is Ready!', 'movie-download-pro'); ?></h2>
                       
                        
<a href="<?php echo esc_url(get_post_meta($post_id, 'mdp_download_link', true)); ?>"
   class="download-btn active"
   id="downloadBtn"
   target="_blank"
   style="opacity:0.4; pointer-events:none;">
   <?php _e('Download Your Movie Now', 'movie-download-pro'); ?>
</a>

                        
                        <div class="session-info">
                            <?php _e('Secure Session:', 'movie-download-pro'); ?> 
                            <code><?php echo substr($session_id, 0, 16); ?>...</code>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <script>
            document.addEventListener("DOMContentLoaded", function() {
                let time = <?php echo $time; ?>;
                let timerEl = document.getElementById("stepTimer");
                let nextBtn = document.getElementById("nextStepBtn");
                let downloadBtn = document.getElementById("downloadBtn");
                let sessionId = "<?php echo esc_js($session_id); ?>";
                let postId = <?php echo $post_id; ?>;
                let currentStep = <?php echo $step; ?>;
                let ajaxNonce = "<?php echo $ajax_nonce; ?>";
                let csrfToken = document.getElementById("csrf_token").value;
                <?php if (!empty($external_link)): ?>
                let externalLink = "<?php echo esc_js($external_link); ?>";
                <?php endif; ?>
                
                let timerInterval;
                
                function startTimer() {
                    if (time > 0) {
                        timerInterval = setInterval(function() {
                            time--;
                            timerEl.textContent = time;
                            
                            if (time <= 0) {
                                clearInterval(timerInterval);
                                timerEnded();
                            }
                        }, 1000);
                    } else {
                        timerEnded();
                    }
                }
                
                function timerEnded() {
                    // Stop timer animation
                    timerEl.style.animation = "none";
                    timerEl.style.borderColor = "#00eaff";
                    timerEl.style.boxShadow = "0 0 30px #00eaff, inset 0 0 30px rgba(0, 234, 255, 0.3)";
                    
                    <?php if (!empty($external_link)): ?>
                    // Open external link in new tab
                    setTimeout(function() {
                        window.open(externalLink, "_blank");
                    }, 500);
                    <?php endif; ?>
                    
                    // Enable buttons and mark step as completed
                    if (nextBtn) {
                        nextBtn.classList.add("active");
                    }
                    
                    if (downloadBtn) {
                        downloadBtn.classList.add("active");
                        
                        
                            // STOP AJAX for Step-4 → Enable direct download
    if (currentStep == 4) {
        let finalLink = "<?php echo esc_url(get_post_meta($post_id, 'mdp_download_link', true)); ?>";

        downloadBtn.href = finalLink;
        downloadBtn.target = "_blank";
        downloadBtn.style.opacity = "1";
        downloadBtn.style.pointerEvents = "auto";

        return; // BLOCK AJAX completely on Step-4
    }
                        
                        
                        
                        
                        
                        
                        // Make download button functional
                                           
                        
                        downloadBtn.addEventListener("click", function(e) {
    e.preventDefault();

    let formData = new FormData();
    formData.append('action', 'mdp_verify_step');
    formData.append('security', ajaxNonce);   // REQUIRED FIX
    formData.append('session_id', sessionId);
    formData.append('post_id', postId);
    formData.append('step', currentStep);
    formData.append('csrf_token', csrfToken); // REQUIRED


  
                            fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                                method: "POST",
                                body: formData
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status === 'success' && data.download_token) {
                                    // Redirect to download page with token
                                    window.location.href =
    "<?php echo site_url("/movie-download/{$post_id}/download/"); ?>" +
    data.download_token + "/";

                                } else {
                                    alert("Error: " + (data.message || "Unknown error"));
                                }
                            })
                            .catch(error => {
                                console.error("Error:", error);
                                alert("An error occurred. Please try again.");
                            });
                        });
                    }
                    
                    // Mark step as completed via AJAX (for steps 1-3)
                    if (currentStep < 4) {
                        let formData = new FormData();
                        formData.append('action', 'mdp_verify_step');
                        formData.append('security', ajaxNonce);
                        formData.append('session_id', sessionId);
                        formData.append('post_id', postId);
                        formData.append('step', currentStep);
                        
                        
                        fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                            method: "POST",
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            console.log("Step verified:", data);
                        });
                    }
                }
                
                // Start the timer
                startTimer();
                
                // Prevent right-click and F12
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                });
                
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'F12' || 
                        (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) ||
                        (e.ctrlKey && e.key === 'U')) {
                        e.preventDefault();
                        return false;
                    }
                });
            });
            </script>
        </body>
        </html>
        <?php
    }
    
    /**
     * Admin menu
     */
    public function admin_menu() {
        add_menu_page(
            __('Movie Download Pro', 'movie-download-pro'),
            __('Movie Download', 'movie-download-pro'),
            'manage_options',
            'mdp_main',
            [$this, 'render_movie_list'],
            'dashicons-video-alt3',
            6
        );
        
        add_submenu_page(
            'mdp_main',
            __('All Movies', 'movie-download-pro'),
            __('All Movies', 'movie-download-pro'),
            'manage_options',
            'mdp_main',
            [$this, 'render_movie_list']
        );
        
        add_submenu_page(
            'mdp_main',
            __('Step Settings', 'movie-download-pro'),
            __('Step Settings', 'movie-download-pro'),
            'manage_options',
            'mdp_steps',
            [$this, 'render_step_settings']
        );
        
        add_submenu_page(
            'mdp_main',
            __('Security Settings', 'movie-download-pro'),
            __('Security', 'movie-download-pro'),
            'manage_options',
            'mdp_security',
            [$this, 'render_security_settings']
        );
        
        add_submenu_page(
            'mdp_main',
            __('Security Logs', 'movie-download-pro'),
            __('Security Logs', 'movie-download-pro'),
            'manage_options',
            'mdp_logs',
            [$this, 'render_security_logs']
        );
    }
    
    /**
     * Add meta boxes
     */
    public function add_meta_boxes() {
        add_meta_box(
            'mdp_download',
            __('Movie Download Settings', 'movie-download-pro'),
            [$this, 'render_meta_box'],
            'post',
            'normal',
            'high'
        );
    }
    
    /**
     * Render meta box
     */
    public function render_meta_box($post) {
        wp_nonce_field('mdp_save_main', 'mdp_nonce_main');
        
        $main_time = get_post_meta($post->ID, 'mdp_main_timer', true);
        $download = get_post_meta($post->ID, 'mdp_download_link', true);
        $hits = get_post_meta($post->ID, 'mdp_hits', true);
        
        ?>
        <div style="padding: 10px 0;">
            <div style="margin-bottom: 15px;">
                <label for="mdp_main_timer" style="display: block; margin-bottom: 5px; font-weight: bold;">
                    <?php _e('Main Countdown Time (Seconds)', 'movie-download-pro'); ?>
                </label>
                <input type="number" 
                       id="mdp_main_timer" 
                       name="mdp_main_timer" 
                       value="<?php echo esc_attr($main_time); ?>" 
                       min="0" 
                       max="300"
                       style="width: 200px; padding: 5px;">
                <p class="description"><?php _e('Timer duration before download button activates (0-300 seconds)', 'movie-download-pro'); ?></p>
            </div>
            
            <div style="margin-bottom: 15px;">
                <label for="mdp_download_link" style="display: block; margin-bottom: 5px; font-weight: bold;">
                    <?php _e('Final Download Link', 'movie-download-pro'); ?>
                </label>
                <input type="url" 
                       id="mdp_download_link" 
                       name="mdp_download_link" 
                       value="<?php echo esc_url($download); ?>" 
                       placeholder="https://example.com/your-movie.mp4"
                       style="width: 100%; padding: 5px;">
                <p class="description"><?php _e('Enter the direct download link for Step 4', 'movie-download-pro'); ?></p>
            </div>
            
            <?php if ($hits): ?>
            <div style="background: #f5f5f5; padding: 10px; border-radius: 3px;">
                <strong><?php _e('Total Downloads:', 'movie-download-pro'); ?></strong> 
                <?php echo intval($hits); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Save post meta
     */
    public function save_post_meta($post_id) {
        if (!isset($_POST['mdp_nonce_main']) || !wp_verify_nonce($_POST['mdp_nonce_main'], 'mdp_save_main')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        if (isset($_POST['mdp_main_timer'])) {
            $timer = intval($_POST['mdp_main_timer']);
            $timer = max(0, min(300, $timer));
            update_post_meta($post_id, 'mdp_main_timer', $timer);
        }
        
        if (isset($_POST['mdp_download_link'])) {
            $link = esc_url_raw($_POST['mdp_download_link']);
            update_post_meta($post_id, 'mdp_download_link', $link);
        }
    }
    
    /**
     * Admin scripts
     */
    public function admin_scripts($hook) {
        if (strpos($hook, 'mdp_') !== false) {
            wp_enqueue_style('mdp-admin', MDP_PLUGIN_URL . 'assets/admin.css', [], MDP_VERSION);
            wp_enqueue_script('mdp-admin', MDP_PLUGIN_URL . 'assets/admin.js', ['jquery'], MDP_VERSION, true);
        }
    }
    
    /**
     * Render movie list
     */
    public function render_movie_list() {
        global $wpdb;
        
        // Get all posts with download settings
        $args = [
            'post_type' => 'post',
            'posts_per_page' => -1,
            'meta_key' => 'mdp_download_link',
            'meta_compare' => 'EXISTS'
        ];
        
        $movies = new WP_Query($args);
        
        ?>
        <div class="wrap">
            <h1><?php _e('Movie Download List', 'movie-download-pro'); ?></h1>
            
            <div class="notice notice-info">
                <p><?php _e('List of all posts with download settings.', 'movie-download-pro'); ?></p>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('ID', 'movie-download-pro'); ?></th>
                        <th><?php _e('Title', 'movie-download-pro'); ?></th>
                        <th><?php _e('Timer', 'movie-download-pro'); ?></th>
                        <th><?php _e('Downloads', 'movie-download-pro'); ?></th>
                        <th><?php _e('Status', 'movie-download-pro'); ?></th>
                        <th><?php _e('Actions', 'movie-download-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($movies->have_posts()): ?>
                        <?php while ($movies->have_posts()): $movies->the_post(); ?>
                            <?php
                            $post_id = get_the_ID();
                            $timer = get_post_meta($post_id, 'mdp_main_timer', true);
                            $hits = get_post_meta($post_id, 'mdp_hits', true);
                            $status = get_post_status();
                            $edit_url = get_edit_post_link();
                            $view_url = get_permalink();
                            ?>
                            <tr>
                                <td><?php echo $post_id; ?></td>
                                <td><strong><?php the_title(); ?></strong></td>
                                <td><?php echo $timer ?: '0'; ?>s</td>
                                <td><?php echo $hits ?: '0'; ?></td>
                                <td>
                                    <span class="status-<?php echo $status; ?>">
                                        <?php echo $status; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo $edit_url; ?>" class="button button-small">
                                        <?php _e('Edit', 'movie-download-pro'); ?>
                                    </a>
                                    <a href="<?php echo $view_url; ?>" class="button button-small" target="_blank">
                                        <?php _e('View', 'movie-download-pro'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">
                                <?php _e('No movies found with download settings.', 'movie-download-pro'); ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
        
        wp_reset_postdata();
    }
    
    /**
     * Render step settings
     */
    public function render_step_settings() {
        if (isset($_POST['mdp_save_steps']) && check_admin_referer('mdp_save_steps_action', 'mdp_steps_nonce')) {
            for ($i = 1; $i <= 4; $i++) {
                if (isset($_POST["mdp_s{$i}_time"])) {
                    $time = intval($_POST["mdp_s{$i}_time"]);
                    update_option("mdp_s{$i}_time", max(0, min(300, $time)));
                }
                
                if (isset($_POST["mdp_s{$i}_link"])) {
                    $link = esc_url_raw($_POST["mdp_s{$i}_link"]);
                    update_option("mdp_s{$i}_link", $link);
                }
                
                if (isset($_POST["mdp_s{$i}"])) {
                    $content = stripslashes($_POST["mdp_s{$i}"]);
                    update_option("mdp_s{$i}", $content);
                }
            }
            
            if (isset($_POST['mdp_step_heading'])) {
                update_option('mdp_step_heading', sanitize_text_field($_POST['mdp_step_heading']));
            }
            
            echo '<div class="notice notice-success is-dismissible"><p>' . 
                 __('Settings saved successfully!', 'movie-download-pro') . 
                 '</p></div>';
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('4 Step Download Settings', 'movie-download-pro'); ?></h1>
            
            <div class="notice notice-info">
                <p><strong>✅ HTML/CSS/JS Support:</strong> <?php _e('You can use HTML, CSS, and JavaScript in step content. It will display exactly as you write it.', 'movie-download-pro'); ?></p>
                <p><strong>🔒 Security:</strong> <?php _e('Users cannot skip steps by editing URLs. They must complete each step in order.', 'movie-download-pro'); ?></p>
                <p><strong>⚠️ IMPORTANT FIX:</strong> <?php _e('Download button in Step 4 will only activate AFTER timer ends.', 'movie-download-pro'); ?></p>
            </div>
            
            <form method="post" action="">
                <?php wp_nonce_field('mdp_save_steps_action', 'mdp_steps_nonce'); ?>
                
                <div style="background: #fff; padding: 20px; margin-bottom: 20px; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h2><?php _e('Step Heading Template', 'movie-download-pro'); ?></h2>
                    <p><?php _e('Use {steps} to show remaining steps count. Example: "You are {steps} steps away from download"', 'movie-download-pro'); ?></p>
                    <input type="text" 
                           name="mdp_step_heading" 
                           value="<?php echo esc_attr(get_option('mdp_step_heading', 'You are {steps} steps away from downloading your movie')); ?>" 
                           style="width: 100%; padding: 10px; font-size: 16px; margin-top: 10px;">
                </div>
                
                <?php for ($i = 1; $i <= 4; $i++): ?>
                    <div style="background: #fff; padding: 20px; margin-bottom: 20px; border: 1px solid #ccd0d4; border-radius: 4px;">
                        <h2 style="color: #2271b1; border-bottom: 2px solid #2271b1; padding-bottom: 10px;">
                            <?php printf(__('Step %d', 'movie-download-pro'), $i); ?>
                        </h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="mdp_s<?php echo $i; ?>_time">
                                        <?php _e('Timer (Seconds)', 'movie-download-pro'); ?>
                                    </label>
                                </th>
                                <td>
                                    <input type="number" 
                                           id="mdp_s<?php echo $i; ?>_time" 
                                           name="mdp_s<?php echo $i; ?>_time" 
                                           value="<?php echo esc_attr(get_option("mdp_s{$i}_time", 10)); ?>" 
                                           min="0" 
                                           max="300" 
                                           style="width: 100px;">
                                    <p class="description">
                                        <?php _e('Timer duration for this step (0-300 seconds)', 'movie-download-pro'); ?>
                                    </p>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row">
                                    <label for="mdp_s<?php echo $i; ?>_link">
                                        <?php _e('External Link', 'movie-download-pro'); ?>
                                    </label>
                                </th>
                                <td>
                                    <input type="url" 
                                           id="mdp_s<?php echo $i; ?>_link" 
                                           name="mdp_s<?php echo $i; ?>_link" 
                                           value="<?php echo esc_url(get_option("mdp_s{$i}_link", '')); ?>" 
                                           placeholder="https://example.com/step<?php echo $i; ?>"
                                           style="width: 100%;">
                                    <p class="description">
                                        <?php _e('This link will open automatically in new tab when timer ends', 'movie-download-pro'); ?>
                                    </p>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="row">
                                    <label for="mdp_s<?php echo $i; ?>">
                                        <?php _e('Content (HTML/CSS/JS allowed)', 'movie-download-pro'); ?>
                                    </label>
                                </th>
                                <td>
                                    <?php
                                    $content = get_option("mdp_s{$i}", '');
                                    $editor_id = "mdp_s{$i}";
                                    $settings = [
                                        'textarea_name' => "mdp_s{$i}",
                                        'textarea_rows' => 15,
                                        'media_buttons' => true,
                                        'tinymce' => [
                                            'toolbar1' => 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,forecolor,backcolor,code',
                                            'toolbar2' => 'fontsizeselect,undo,redo,removeformat,paste,fullscreen',
                                            'content_css' => MDP_PLUGIN_URL . 'assets/editor-style.css'
                                        ],
                                        'quicktags' => true
                                    ];
                                    
                                    wp_editor($content, $editor_id, $settings);
                                    ?>
                                    <p class="description">
                                        <?php _e('You can use HTML, CSS, and JavaScript. Content will display exactly as written.', 'movie-download-pro'); ?>
                                    </p>
                                    <div style="background: #f5f5f5; padding: 10px; border-radius: 3px; margin-top: 10px;">
                                        <strong><?php _e('Example:', 'movie-download-pro'); ?></strong>
                                        <code>&lt;h3&gt;Step Title&lt;/h3&gt;&lt;p&gt;Content here&lt;/p&gt;&lt;style&gt;.custom { color: red; }&lt;/style&gt;&lt;script&gt;console.log('test');&lt;/script&gt;</code>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                <?php endfor; ?>
                
                <p class="submit">
                    <input type="submit" 
                           name="mdp_save_steps" 
                           class="button button-primary" 
                           value="<?php esc_attr_e('Save All Settings', 'movie-download-pro'); ?>">
                </p>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render security settings
     */
    public function render_security_settings() {
        if (isset($_POST['mdp_save_security']) && check_admin_referer('mdp_save_security_action', 'mdp_security_nonce')) {
            $settings = [
                'mdp_security_level' => sanitize_text_field($_POST['mdp_security_level'] ?? 'high'),
                'mdp_session_duration' => intval($_POST['mdp_session_duration'] ?? 3600),
                'mdp_download_token_expiry' => intval($_POST['mdp_download_token_expiry'] ?? 300),
                'mdp_enable_csrf' => isset($_POST['mdp_enable_csrf']) ? 1 : 0,
                'mdp_enable_rate_limit' => isset($_POST['mdp_enable_rate_limit']) ? 1 : 0,
                'mdp_enable_logging' => isset($_POST['mdp_enable_logging']) ? 1 : 0
            ];
            
            foreach ($settings as $key => $value) {
                update_option($key, $value);
            }
            
            echo '<div class="notice notice-success is-dismissible"><p>' . 
                 __('Security settings saved successfully!', 'movie-download-pro') . 
                 '</p></div>';
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Security Settings', 'movie-download-pro'); ?></h1>
            
            <div class="notice notice-info">
                <p><strong>🔒 Enhanced Security Features:</strong> <?php _e('All security vulnerabilities have been fixed in this version.', 'movie-download-pro'); ?></p>
            </div>
            
            <form method="post" action="">
                <?php wp_nonce_field('mdp_save_security_action', 'mdp_security_nonce'); ?>
                
                <div style="background: #fff; padding: 20px; margin-bottom: 20px; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h2><?php _e('Session Settings', 'movie-download-pro'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="mdp_security_level">
                                    <?php _e('Security Level', 'movie-download-pro'); ?>
                                </label>
                            </th>
                            <td>
                                <select id="mdp_security_level" name="mdp_security_level" style="width: 200px;">
                                    <option value="low" <?php selected(get_option('mdp_security_level', 'high'), 'low'); ?>>
                                        <?php _e('Low', 'movie-download-pro'); ?>
                                    </option>
                                    <option value="medium" <?php selected(get_option('mdp_security_level', 'high'), 'medium'); ?>>
                                        <?php _e('Medium', 'movie-download-pro'); ?>
                                    </option>
                                    <option value="high" <?php selected(get_option('mdp_security_level', 'high'), 'high'); ?>>
                                        <?php _e('High', 'movie-download-pro'); ?>
                                    </option>
                                </select>
                                <p class="description">
                                    <?php _e('Higher security means stricter validation but may affect user experience.', 'movie-download-pro'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="mdp_session_duration">
                                    <?php _e('Session Duration (seconds)', 'movie-download-pro'); ?>
                                </label>
                            </th>
                            <td>
                                <input type="number" 
                                       id="mdp_session_duration" 
                                       name="mdp_session_duration" 
                                       value="<?php echo esc_attr(get_option('mdp_session_duration', 3600)); ?>" 
                                       min="300" 
                                       max="86400" 
                                       style="width: 150px;">
                                <p class="description">
                                    <?php _e('How long a download session remains valid (300-86400 seconds)', 'movie-download-pro'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="mdp_download_token_expiry">
                                    <?php _e('Download Token Expiry (seconds)', 'movie-download-pro'); ?>
                                </label>
                            </th>
                            <td>
                                <input type="number" 
                                       id="mdp_download_token_expiry" 
                                       name="mdp_download_token_expiry" 
                                       value="<?php echo esc_attr(get_option('mdp_download_token_expiry', 300)); ?>" 
                                       min="60" 
                                       max="3600" 
                                       style="width: 150px;">
                                <p class="description">
                                    <?php _e('How long download links remain valid after completion (60-3600 seconds)', 'movie-download-pro'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div style="background: #fff; padding: 20px; margin-bottom: 20px; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h2><?php _e('Security Features', 'movie-download-pro'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <?php _e('CSRF Protection', 'movie-download-pro'); ?>
                            </th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="mdp_enable_csrf" 
                                           value="1" 
                                           <?php checked(get_option('mdp_enable_csrf', 1), 1); ?>>
                                    <?php _e('Enable CSRF (Cross-Site Request Forgery) protection', 'movie-download-pro'); ?>
                                </label>
                                <p class="description">
                                    <?php _e('Prevents unauthorized form submissions. Recommended: ON', 'movie-download-pro'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <?php _e('Rate Limiting', 'movie-download-pro'); ?>
                            </th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="mdp_enable_rate_limit" 
                                           value="1" 
                                           <?php checked(get_option('mdp_enable_rate_limit', 1), 1); ?>>
                                    <?php _e('Enable rate limiting', 'movie-download-pro'); ?>
                                </label>
                                <p class="description">
                                    <?php _e('Prevents brute force attacks by limiting requests per IP. Recommended: ON', 'movie-download-pro'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <?php _e('Security Logging', 'movie-download-pro'); ?>
                            </th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="mdp_enable_logging" 
                                           value="1" 
                                           <?php checked(get_option('mdp_enable_logging', 1), 1); ?>>
                                    <?php _e('Enable security logging', 'movie-download-pro'); ?>
                                </label>
                                <p class="description">
                                    <?php _e('Logs security events for monitoring and debugging. Recommended: ON', 'movie-download-pro'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div style="background: #fff; padding: 20px; margin-bottom: 20px; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <h2><?php _e('Security Status', 'movie-download-pro'); ?></h2>
                    
                    <div style="background: #f5f5f5; padding: 15px; border-radius: 3px;">
                        <h3><?php _e('Current Security Measures:', 'movie-download-pro'); ?></h3>
                        <ul style="list-style-type: disc; margin-left: 20px;">
                            <li><?php _e('✅ Secure session cookies with HMAC signatures', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ CSRF protection enabled', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ Rate limiting enabled', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ Download token system with expiry', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ SQL injection protection', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ XSS protection with output escaping', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ Security headers (CSP, X-Frame-Options, etc.)', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ Session hijacking protection', 'movie-download-pro'); ?></li>
                            <li><?php _e('✅ FIXED: Step 4 download button only activates after timer', 'movie-download-pro'); ?></li>
                        </ul>
                    </div>
                </div>
                
                <p class="submit">
                    <input type="submit" 
                           name="mdp_save_security" 
                           class="button button-primary" 
                           value="<?php esc_attr_e('Save Security Settings', 'movie-download-pro'); ?>">
                </p>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render security logs
     */
    public function render_security_logs() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mdp_security_logs';
        
        // Get logs
        $logs = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 100"
        );
        
        // Clear logs if requested
        if (isset($_POST['clear_logs']) && check_admin_referer('mdp_clear_logs_action', 'mdp_clear_logs_nonce')) {
            $wpdb->query("TRUNCATE TABLE $table_name");
            echo '<div class="notice notice-success is-dismissible"><p>' . 
                 __('Security logs cleared successfully!', 'movie-download-pro') . 
                 '</p></div>';
            $logs = [];
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Security Logs', 'movie-download-pro'); ?></h1>
            
            <div class="notice notice-info">
                <p><strong>📊 Security Monitoring:</strong> <?php _e('View security events and potential threats.', 'movie-download-pro'); ?></p>
            </div>
            
            <form method="post" action="" style="margin-bottom: 20px;">
                <?php wp_nonce_field('mdp_clear_logs_action', 'mdp_clear_logs_nonce'); ?>
                <input type="submit" 
                       name="clear_logs" 
                       class="button" 
                       value="<?php esc_attr_e('Clear All Logs', 'movie-download-pro'); ?>"
                       onclick="return confirm('<?php esc_attr_e('Are you sure you want to clear all security logs?', 'movie-download-pro'); ?>');">
            </form>
            
            <?php if ($logs): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('ID', 'movie-download-pro'); ?></th>
                            <th><?php _e('Time', 'movie-download-pro'); ?></th>
                            <th><?php _e('Type', 'movie-download-pro'); ?></th>
                            <th><?php _e('IP Address', 'movie-download-pro'); ?></th>
                            <th><?php _e('Details', 'movie-download-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                            <?php
                            $details = json_decode($log->details, true);
                            $details_text = '';
                            if ($details && is_array($details)) {
                                $details_text = implode(', ', array_map(
                                    function($k, $v) { return "$k: $v"; },
                                    array_keys($details),
                                    $details
                                ));
                            }
                            ?>
                            <tr>
                                <td><?php echo $log->id; ?></td>
                                <td><?php echo date_i18n('Y-m-d H:i:s', strtotime($log->created_at)); ?></td>
                                <td>
                                    <span class="log-type log-type-<?php echo esc_attr($log->log_type); ?>">
                                        <?php echo esc_html($log->log_type); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html($log->ip_address); ?></td>
                                <td><?php echo esc_html($details_text); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="notice notice-warning">
                    <p><?php _e('No security logs found.', 'movie-download-pro'); ?></p>
                </div>
            <?php endif; ?>
        </div>
        
        <style>
        .log-type {
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .log-type-unauthorized_access,
        .log-type-invalid_session,
        .log-type-invalid_download_token {
            background: #ffeaea;
            color: #d63638;
        }
        .log-type-rate_limit_exceeded {
            background: #fff3cd;
            color: #856404;
        }
        .log-type-download_started,
        .log-type-download_completed {
            background: #d1ecf1;
            color: #0c5460;
        }
        </style>
        <?php
    }
}

/**
 * Rate Limiter Class
 */
class MDP_Rate_Limiter {
    private $ip;
    private $limit = 10; // requests per hour
    private $time_window = 3600;
    
    public function __construct() {
        $this->ip = $this->get_client_ip();
    }
    
    private function get_client_ip() {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        }
        
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'unknown';
    }
    
    public function check_limit() {
        if (!get_option('mdp_enable_rate_limit', true)) {
            return true;
        }
        
        $transient_key = 'mdp_rate_' . md5($this->ip);
        $attempts = get_transient($transient_key) ?: 0;
        
        if ($attempts >= $this->limit) {
            return false;
        }
        
        set_transient($transient_key, $attempts + 1, $this->time_window);
        return true;
    }
    
    public function reset_limit() {
        $transient_key = 'mdp_rate_' . md5($this->ip);
        delete_transient($transient_key);
    }
}

// Initialize plugin
MovieDownloadProUltimate::get_instance();