<?php
/*
Plugin Name: Connection Detector PRO
Description: Full detection (VPN, Mobile Data, WiFi, Country, OS, Device Type) with Bootstrap UI, Logs, Filters & AJAX Delete.
Version: 3.3
Author: A.H.
*/
if (!defined('ABSPATH')) exit;

define('CDP_PATH', plugin_dir_path(__FILE__));
define('CDP_URL', plugin_dir_url(__FILE__));

require_once CDP_PATH."includes/class-activator.php";
require_once CDP_PATH."includes/class-detector.php";
require_once CDP_PATH."includes/class-logger.php";
require_once CDP_PATH."includes/class-admin.php";
require_once CDP_PATH."includes/class-cron.php";

register_activation_hook(__FILE__, ['CDP_Activator','activate']);
add_action('wp', ['CDP_Cron','init']);

new CDP_Admin();
new CDP_Logger();
?>