jQuery(function($){

function render(rows){
    let h = `
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th><input type="checkbox" id="cdp-all"></th>
                <th>ID</th>
                <th>User</th>
                <th>IP</th>
                <th>Country</th>
                <th>ISP</th>
                <th>Type</th>
                <th>Device</th>
                <th>OS</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
    `;

    rows.forEach(r=>{
        let red = (r.conn_type=='VPN') ? 'style="background:#ffdddd"' : '';
        h+=`
        <tr ${red}>
            <td><input class='cdp-row form-check-input' type='checkbox' value='${r.id}'></td>
            <td>${r.id}</td>
            <td>${r.username}</td>
            <td>${r.ip}</td>
            <td>${r.country}</td>
            <td>${r.isp}</td>
            <td>${r.conn_type}</td>
            <td>${r.device_type}</td>
            <td>${r.os}</td>
            <td>${r.created_at}</td>
        </tr>`;
    });

    h+=`</tbody></table>`;
    $("#cdp-table").html(h);

    $("#cdp-all").on("change", function(){
        $(".cdp-row").prop("checked", this.checked);
    });
}

$(".btn[data-filter]").on("click",function(){
    $.post(ajaxurl,{action:"cdp_filter",f:$(this).data("filter")},render);
});

$("#cdp-search").on("keyup",function(){
    $.post(ajaxurl,{action:"cdp_search",q:$(this).val()},render);
});

$("#cdp-delete").on("click",function(){
    let ids=[];
    $(".cdp-row:checked").each(function(){ ids.push($(this).val()); });

    if(ids.length<1){ alert("No rows selected"); return; }

    $.post(ajaxurl,{action:"cdp_bulk_delete",ids:ids},function(){
        $.post(ajaxurl,{action:"cdp_filter",f:"all"},render);
    });
});

$("#cdp-delete-all").on("click",function(){
    if(!confirm("Delete ALL logs?")) return;
    $.post(ajaxurl,{action:"cdp_delete_all"},function(){
        $.post(ajaxurl,{action:"cdp_filter",f:"all"},render);
    });
});

$.post(ajaxurl,{action:"cdp_filter",f:"all"},render);

});