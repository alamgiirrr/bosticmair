(function(){
 let d=navigator.userAgent+screen.width+screen.height+navigator.language+navigator.platform;
 document.cookie='cdp_fp='+btoa(d)+'; path=/;';
})();