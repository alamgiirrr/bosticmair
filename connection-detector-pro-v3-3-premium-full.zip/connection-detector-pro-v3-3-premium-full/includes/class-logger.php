<?php
class CDP_Logger {
    public function __construct(){
        add_action('init',[$this,'log']);
    }

    public function log(){
        if(is_admin()) return;

        $ip=$_SERVER['REMOTE_ADDR'];
        $user=is_user_logged_in()? wp_get_current_user()->user_login : 'Guest';

        $info=CDP_Detector::lookup($ip);
        if(!$info) return;

        $fp=$_COOKIE['cdp_fp']??'';
        $device_hash=hash('sha256',$_SERVER['HTTP_USER_AGENT'].$ip);

        global $wpdb;
        $table=$wpdb->prefix.'cdp_logs';

        $exists=$wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE ip=%s AND device_hash=%s AND username=%s LIMIT 1",
            $ip,$device_hash,$user
        ));

        if($exists){
            $wpdb->update($table,[
                'country'=>$info['country'],
                'conn_type'=>$info['type'],
                'device_type'=>$info['device_type'],
                'os'=>$info['os'],
                'isp'=>$info['isp'],
                'asn'=>$info['asn'],
            ],['id'=>$exists]);
        } else {
            $wpdb->insert($table,[
                'ip'=>$ip,
                'username'=>$user,
                'country'=>$info['country'],
                'conn_type'=>$info['type'],
                'device_type'=>$info['device_type'],
                'os'=>$info['os'],
                'device_hash'=>$device_hash,
                'fingerprint'=>$fp,
                'isp'=>$info['isp'],
                'asn'=>$info['asn'],
                'user_agent'=>$_SERVER['HTTP_USER_AGENT']
            ]);
        }
    }
}
?>