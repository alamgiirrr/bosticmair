<?php
class CDP_Cron {
    public static function init(){
        add_action('cdp_daily_cleanup',[self::class,'clean']);
    }
    public static function clean(){
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->prefix}cdp_logs WHERE created_at < NOW() - INTERVAL 10 DAY");
    }
}
?>