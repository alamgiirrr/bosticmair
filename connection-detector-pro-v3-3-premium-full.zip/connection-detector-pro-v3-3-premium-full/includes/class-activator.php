<?php
class CDP_Activator {
    public static function activate(){
        global $wpdb;
        $table=$wpdb->prefix.'cdp_logs';
        $charset=$wpdb->get_charset_collate();
        $sql="CREATE TABLE $table (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            ip VARCHAR(60),
            username VARCHAR(60),
            country VARCHAR(20),
            conn_type VARCHAR(20),
            device_type VARCHAR(20),
            os VARCHAR(20),
            device_hash VARCHAR(120),
            fingerprint VARCHAR(200),
            isp VARCHAR(200),
            asn VARCHAR(20),
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) $charset;";
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        if(!wp_next_scheduled('cdp_daily_cleanup')){
            wp_schedule_event(time(),'daily','cdp_daily_cleanup');
        }
    }
}
?>