<?php
class CDP_Admin {

    public function __construct(){
        add_action('admin_menu',[$this,'menu']);
        add_action('wp_ajax_cdp_filter',[$this,'filter']);
        add_action('wp_ajax_cdp_search',[$this,'search']);
        add_action('wp_ajax_cdp_bulk_delete',[$this,'delete_selected']);
        add_action('wp_ajax_cdp_delete_all',[$this,'delete_all']);
        add_action('admin_init',[$this,'settings']);
    }

    public function settings(){
        register_setting('cdp_settings','cdp_ipinfo_key');
    }

    public function menu(){
        add_menu_page("Connection Detector PRO","Connection Detector PRO","manage_options","cdp-pro",[$this,'page']);
        add_submenu_page("cdp-pro","Settings","Settings","manage_options","cdp-settings",[$this,'settings_page']);
    }

    public function settings_page(){
        echo '<div class="container"><h2>API Key</h2><form method="post" action="options.php">';
        settings_fields('cdp_settings');
        echo '<label>IPinfo Key</label><input type="text" name="cdp_ipinfo_key" class="form-control" style="max-width:400px" value="'.esc_attr(get_option('cdp_ipinfo_key')).'">
        <br><button class="btn btn-primary">Save</button></form></div>';
    }

    public function page(){
        echo '
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
        <div class="container mt-4">
            <h2>Logs History</h2>
            <input id="cdp-search" type="text" class="form-control mb-3" placeholder="Search IP, Country, Username">

            <div class="d-flex justify-content-between mb-3">
                <div>
                    <button class="btn btn-secondary me-2" data-filter="all">All</button>
                    <button class="btn btn-warning me-2" data-filter="VPN">VPN</button>
                    <button class="btn btn-info me-2" data-filter="WiFi">WiFi</button>
                    <button class="btn btn-success" data-filter="Mobile Data">Mobile Data</button>
                </div>

                <div>
                    <button id="cdp-delete" class="btn btn-danger me-2">Bulk Delete</button>
                    <button id="cdp-delete-all" class="btn btn-dark">Delete All</button>
                </div>
            </div>

            <div id="cdp-table" class="table-responsive"></div>
        </div>
        <script src="'.CDP_URL.'includes/ajax.js"></script>';
    }

    public function delete_selected(){
        global $wpdb;
        $ids=$_POST['ids']??[];
        if(!empty($ids)){
            $in=implode(',',array_map('intval',$ids));
            $wpdb->query("DELETE FROM {$wpdb->prefix}cdp_logs WHERE id IN ($in)");
        }
        wp_send_json_success();
    }

    public function delete_all(){
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}cdp_logs");
        wp_send_json_success();
    }

    public function filter(){
        $f=sanitize_text_field($_POST['f']);
        global $wpdb;
        $table=$wpdb->prefix.'cdp_logs';
        if($f=='all')
            $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 500");
        else
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE conn_type=%s ORDER BY id DESC LIMIT 500",$f));
        wp_send_json($rows);
    }

    public function search(){
        $q='%'.sanitize_text_field($_POST['q']).'%';
        global $wpdb;
        $table=$wpdb->prefix.'cdp_logs';
        $rows=$wpdb->get_results($wpdb->prepare("
            SELECT * FROM $table 
            WHERE ip LIKE %s OR username LIKE %s OR isp LIKE %s OR device_hash LIKE %s",
            $q,$q,$q,$q));
        wp_send_json($rows);
    }
}
?>