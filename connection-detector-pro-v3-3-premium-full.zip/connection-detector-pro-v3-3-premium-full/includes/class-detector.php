<?php
class CDP_Detector {

    public static function free_vpn_check($asn,$isp){
        $vpn_asn=['AS60068','AS202425','AS208091','AS14061','AS16276','AS8100','AS12876','AS29073'];
        $keywords=['hosting','datacenter','colo','server','vps'];

        if(in_array($asn,$vpn_asn)) return true;

        foreach($keywords as $k){
            if(stripos($isp,$k)!==false) return true;
        }
        return false;
    }

    public static function get_device_type(){
        $ua=$_SERVER['HTTP_USER_AGENT'];
        if(preg_match('/Android|iPhone|iPad|iPod/i',$ua)) return 'mobile';
        return 'desktop';
    }

    public static function get_os(){
        $ua=$_SERVER['HTTP_USER_AGENT'];
        if(stripos($ua,'Android')!==false) return 'Android';
        if(stripos($ua,'iPhone')!==false||stripos($ua,'iPad')!==false) return 'iOS';
        if(stripos($ua,'Windows')!==false) return 'Windows';
        if(stripos($ua,'Mac')!==false) return 'MacOS';
        if(stripos($ua,'Linux')!==false) return 'Linux';
        return 'Unknown';
    }

    public static function lookup($ip){
        $key=get_option('cdp_ipinfo_key','');
        $resp=wp_remote_get("https://ipinfo.io/$ip?token=$key");
        if(is_wp_error($resp)) return false;
        $d=json_decode(wp_remote_retrieve_body($resp),true);

        $asn=$d['asn']['asn']??'';
        $isp=$d['org']??'';
        $country=$d['country']??'';

        $mobile_asn=['AS24389','AS24198','AS132602','AS24432'];
        $is_vpn=self::free_vpn_check($asn,$isp);

        if($is_vpn) $type="VPN";
        elseif(in_array($asn,$mobile_asn)) $type="Mobile Data";
        else $type="WiFi";

        return[
            'type'=>$type,
            'asn'=>$asn,
            'isp'=>$isp,
            'country'=>$country,
            'device_type'=>self::get_device_type(),
            'os'=>self::get_os()
        ];
    }
}
?>